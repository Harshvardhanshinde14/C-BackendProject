﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CQPortal
{
    [Serializable]
    public class TBStr
    {
        public string xName;
        public string xColName;
        public string xColType;
        public string xColSize;
        public string xV1;
        public TBStr() { }
        public TBStr(string xxName, string xxColName, string xxColType, string xxColSize, string xxV1 = "-")
        {
            xName = xxName;
            xColName = xxColName;
            xColType = xxColType;
            xColSize = xxColSize;
            xV1 = xxV1;
        }
    }
    [Serializable]
    public class TBSchema
    {
        public string TABLE_CATALOG;
        public string TABLE_SCHEMA;
        public string TABLE_NAME;
        public string COLUMN_NAME;
        public string ORDINAL_POSITION;
        public string COLUMN_DEFAULT;
        public string IS_NULLABLE;
        public string DATA_TYPE;
        public string CHARACTER_MAXIMUM_LENGTH;
        public string CHARACTER_OCTET_LENGTH;
        public string NUMERIC_PRECISION;
        public string NUMERIC_PRECISION_RADIX;
        public string NUMERIC_SCALE;
        public string DATETIME_PRECISION;
        public string DOMAIN_NAME;

    }
    [Serializable]
    public class V1V2V3
    {
        public string xV1;
        public string xV2;
        public string xV3;
        public string xV4;
        public Int32 xSeqNo;
        public bool xStatus;
        public V1V2V3() { }
        public V1V2V3(V1V2V3 xT)
        {
            xV1 = xT.xV1;
            xV2 = xT.xV2;
            xV3 = xT.xV3;
            xV4 = xT.xV4;
            xSeqNo = xT.xSeqNo;
            xStatus = xT.xStatus;
        }

        public V1V2V3(string xxV1, string xxV2, string xxV3, string xxV4, Int32 xxSeqNo, bool xxStatus)
        {
            xV1 = xxV1;
            xV2 = xxV2;
            xV3 = xxV3;
            xV4 = xxV4;
            xSeqNo = xxSeqNo;
            xStatus = xxStatus;
        }
        public V1V2V3(Int32 xxSeqNo, bool xxStatus)
        {
            xV1 = "-";
            xV2 = "-";
            xV3 = "-";
            xV4 = "-";
            xSeqNo = xxSeqNo;
            xStatus = xxStatus;
        }
        public V1V2V3(string xxV1, Int32 xxSeqNo, bool xxStatus)
        {
            xV1 = xxV1;
            xV2 = "-";
            xV3 = "-";
            xV4 = "-";
            xSeqNo = xxSeqNo;
            xStatus = xxStatus;
        }
        public V1V2V3(string xxV1, string xxV2, Int32 xxSeqNo, bool xxStatus)
        {
            xV1 = xxV1;
            xV2 = xxV2;
            xV3 = "-";
            xV4 = "-";
            xSeqNo = xxSeqNo;
            xStatus = xxStatus;
        }
        public V1V2V3(string xxV1, string xxV2, string xxV3, Int32 xxSeqNo, bool xxStatus)
        {
            xV1 = xxV1;
            xV2 = xxV2;
            xV3 = xxV3;
            xV4 = "-";
            xSeqNo = xxSeqNo;
            xStatus = xxStatus;
        }
    }

}