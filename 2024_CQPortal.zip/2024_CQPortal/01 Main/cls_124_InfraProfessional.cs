﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Globalization;
using static System.Windows.Forms.AxHost;
using CQPortal;
using System.Security.Cryptography;
namespace CQPortal
{
    public static class InfraProfessionals
    {

        public static List<InfraProfessional> mLst = new List<InfraProfessional>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<InfraProfessional> xLst)
        {
            //xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xName + "','" + xLst[n].xQualification + "','" + xLst[n].xDesignation + "','" + xLst[n].xCompany + "','" + xLst[n].xExp + "','" + xLst[n].xContactNumber + "','" + xLst[n].xEmail + "','" + xLst[n].xDesc+ "','" + xLst[n].xPhotoName + "','" + xLst[n].xSeqNo + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_InfraProfessional (xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName,xSeqNo) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_InfraProfessional");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            //xEmail,xDepartment,xExeperience
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_InfraProfessional WHERE xID = '" + xID + "' ") == false) return;
                InfraProfessional xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<InfraProfessional> { xT });
            }
            catch { }
        }
        public static List<InfraProfessional> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<InfraProfessional> xRetLst = new List<InfraProfessional>();
                while (oReader.Read())
                {
                    //
                    //xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName
                    InfraProfessional xT = new InfraProfessional();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xName = oReader["xName"].ToString().Trim();
                    xT.xQualification = oReader["xQualification"].ToString().Trim();
                    xT.xDesignation = oReader["xDesignation"].ToString().Trim();
                    xT.xCompany = oReader["xCompany"].ToString().Trim();
                    xT.xExp = oReader["xExp"].ToString().Trim();
                    xT.xContactNumber = oReader["xContactNumber"].ToString().Trim();
                    xT.xEmail = oReader["xEmail"].ToString().Trim();
                    xT.xDesc = oReader["xDesc"].ToString().Trim(); ;
                    xT.xPhotoName = oReader["xPhotoName"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<InfraProfessional>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<InfraProfessional>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_InfraProfessional";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_InfraProfessional WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                InfraProfessionals.xPopTV(TV);
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID()
        {
            try
            {
                List<InfraProfessional> xLst = mLst.FindAll(p => p.xID.Length == 6).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<InfraProfessional> xLst = mLst.OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static InfraProfessional xGetByID(string xID)
        {
            try
            {
                InfraProfessional xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new InfraProfessional();
                return xT;
            }
            catch { return new InfraProfessional(); }
        }
        #endregion

        #region Add Update        
                                                                                        //xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName
        public static void xAdd6(SqlConnection DBConn, TreeView TV, TextBox txtName, TextBox txtQualification, TextBox txtDesignation, TextBox txtCompany, TextBox txtExp, TextBox txtContactNumber, TextBox txtEmail, TextBox txtDesc)
        {
            try
            {
                //xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName
                InfraProfessional xT = new InfraProfessional();
                xT.xID = xGetNewID();
                xT.xSeqNo = xGetNewSeqNo();
                xT.xName = txtName.Text.Trim();
                xT.xQualification = txtQualification.Text.Trim();
                xT.xDesignation = txtDesignation.Text.Trim();
                xT.xCompany = txtCompany.Text.Trim();
                xT.xExp = txtExp.Text.Trim();
                xT.xContactNumber = txtContactNumber.Text.Trim();
                xT.xEmail = txtEmail.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xPhotoName = xT.xID + "_xPhotoName";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static bool xValidate (SqlConnection DBConn, TreeView TV, TextBox txtName, TextBox txtQualification, TextBox txtDesignation, TextBox txtCompany, TextBox txtExp, TextBox txtContactNumber, TextBox txtEmail, TextBox txtDesc, out string ErrorMessage)
        {
            ErrorMessage = string.Empty;
            bool isValid = true;
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                ErrorMessage += "Name is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                ErrorMessage += "Email is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtQualification.Text))
            {
                ErrorMessage += "Qualification is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtCompany.Text))
            {
                ErrorMessage += "Company is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtDesignation.Text))
            {
                ErrorMessage += "Designation is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtExp.Text))
            {
                ErrorMessage += "Experience Company is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtDesc.Text))
            {
                ErrorMessage += "Description Company is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtContactNumber.Text))
            {
                ErrorMessage += "Contact Number is required.\n";
                isValid = false;
            }
            // Validate email format
            if (!IsValidEmail(txtEmail.Text))
            {
                ErrorMessage += "Please enter a valid email address.\n";
                isValid = false;
            }
            // Validate contact number length and numeric content
            if (!IsNumeric(txtContactNumber.Text) || txtContactNumber.Text.Length != 10)
            {
                ErrorMessage += "Contact number must be exactly 10 numeric digits.\n";
                isValid = false;
            }
            // Additional validations can be added here (e.g., date format, numeric fields, etc.)
            return isValid;
        }
        private static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
        private static bool IsNumeric(string value)
        {
            return value.All(char.IsDigit);
        }
        public static void xUpdate(SqlConnection DBConn, TreeView TV, string xID, TextBox txtName, TextBox txtQualification, TextBox txtDesignation, TextBox txtCompany, TextBox txtExp, TextBox txtContactNumber, TextBox txtEmail, TextBox txtDesc, string newPhotoName = null)
        {
            try
            {//xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName,xSeqNo

                InfraProfessional xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xName = txtName.Text.Trim();
                xT.xQualification = txtQualification.Text.Trim();
                xT.xDesignation = txtDesignation.Text.Trim();
                xT.xCompany = txtCompany.Text.Trim();
                xT.xExp = txtExp.Text.Trim();
                xT.xContactNumber = txtContactNumber.Text.Trim();
                xT.xEmail = txtEmail.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                if (!string.IsNullOrEmpty(newPhotoName))
                {
                    xT.xPhotoName = newPhotoName;
                }
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<InfraProfessional> xLst = mLst.OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst.Count; i++)
                {
                    TV.Nodes.Add(xLst[i].xID, xLst[i].xName);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID, TextBox txtName, TextBox txtQualification, TextBox txtDesignation, TextBox txtCompany, TextBox txtExp, TextBox txtContactNumber, TextBox txtEmail, TextBox txtDesc)
        {
            try
            {
                //xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName,xSeqNo

                InfraProfessional xT = xGetByID(xID);
                txtName.Text = xT.xName;
                txtQualification.Text = xT.xQualification;
                txtDesignation.Text = xT.xDesignation;
                txtCompany.Text = xT.xCompany;
                txtExp.Text = xT.xExp;
                txtContactNumber.Text = xT.xContactNumber;
                txtEmail.Text = xT.xEmail;
                txtDesc.Text = xT.xDesc;
            }
            catch { }
        }
        public static void xUpdatePhotoName(SqlConnection DBConn, string xID, string xPhotoName)
        {
            try
            {
                InfraProfessional xT = xGetByID(xID);
                if (CQSQL.ExeNonQuery(DBConn, "UPDATE dbo.CQ_Portal_InfraProfessional SET xPhotoName = '" + xPhotoName + "' WHERE xID = '" + xID + "' ") == true)
                {
                    xT.xPhotoName = xPhotoName;
                }
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown(SqlConnection DBConn, TreeView TV, bool MoveUp)
        {
            try
            {
                if (TV.SelectedNode == null) return;
                string xID = TV.SelectedNode.Name;
                List<InfraProfessional> xLst = new List<InfraProfessional>();
                xLst = mLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xID];
            }
            catch { }
        }
        #endregion
    }
}
