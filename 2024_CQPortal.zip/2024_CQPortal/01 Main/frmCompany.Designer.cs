﻿namespace CQPortal
{
    partial class frmCompany
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCompany));
            this.mOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.tabGovtPortal = new System.Windows.Forms.TabPage();
            this.splitContainer34 = new System.Windows.Forms.SplitContainer();
            this.btnGovPoratlMoveDown = new System.Windows.Forms.Button();
            this.btnGovPoratlMoveUp = new System.Windows.Forms.Button();
            this.btnGovPoratlExit = new System.Windows.Forms.Button();
            this.btnGovPoratlDelete = new System.Windows.Forms.Button();
            this.btnGovPoratlAdd = new System.Windows.Forms.Button();
            this.btnGovPoratlUpdate = new System.Windows.Forms.Button();
            this.splitContainer35 = new System.Windows.Forms.SplitContainer();
            this.TVGovPoratl = new System.Windows.Forms.TreeView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label54 = new System.Windows.Forms.Label();
            this.txtGovPortalName = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtGovPoratlLink = new System.Windows.Forms.TextBox();
            this.chkGovPoratlLinkFlag = new System.Windows.Forms.CheckBox();
            this.tabProfessionals = new System.Windows.Forms.TabPage();
            this.splitContainer16 = new System.Windows.Forms.SplitContainer();
            this.btnProfMoveDown = new System.Windows.Forms.Button();
            this.btnProfMoveUp = new System.Windows.Forms.Button();
            this.btnProfAddGrp = new System.Windows.Forms.Button();
            this.btnProfShowPhoto = new System.Windows.Forms.Button();
            this.btnProfULPhoto = new System.Windows.Forms.Button();
            this.btnProfDefault = new System.Windows.Forms.Button();
            this.btnProfExit = new System.Windows.Forms.Button();
            this.btnProfDelete = new System.Windows.Forms.Button();
            this.btnProfAdd = new System.Windows.Forms.Button();
            this.btnProfUpdate = new System.Windows.Forms.Button();
            this.splitContainer17 = new System.Windows.Forms.SplitContainer();
            this.TVProfessional = new System.Windows.Forms.TreeView();
            this.splitContainer18 = new System.Windows.Forms.SplitContainer();
            this.splitContainer14 = new System.Windows.Forms.SplitContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtProfDesc = new System.Windows.Forms.TextBox();
            this.txtProfDesignation = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtProfName = new System.Windows.Forms.TextBox();
            this.TVProfCompany = new System.Windows.Forms.TreeView();
            this.label14 = new System.Windows.Forms.Label();
            this.PbProfessional = new System.Windows.Forms.PictureBox();
            this.tabCompany = new System.Windows.Forms.TabPage();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.btnCompanyExit = new System.Windows.Forms.Button();
            this.btnCompanyRead = new System.Windows.Forms.Button();
            this.btnCompanyWrite = new System.Windows.Forms.Button();
            this.btnCompanyDown = new System.Windows.Forms.Button();
            this.btnCompanyUp = new System.Windows.Forms.Button();
            this.btnCompanyShowLogo = new System.Windows.Forms.Button();
            this.btnCompanyAddGrp = new System.Windows.Forms.Button();
            this.btnCompanyDefault = new System.Windows.Forms.Button();
            this.btnCompanyUploadLogo = new System.Windows.Forms.Button();
            this.btnCompanyDelete = new System.Windows.Forms.Button();
            this.btnCompanyAdd = new System.Windows.Forms.Button();
            this.btnCompanyUpdate = new System.Windows.Forms.Button();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.TVCompany = new System.Windows.Forms.TreeView();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.label66 = new System.Windows.Forms.Label();
            this.txtCompanyCity = new System.Windows.Forms.TextBox();
            this.ckhCompanyFlag = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCompanyOpeningLinkAdd = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCompanyShortName = new System.Windows.Forms.TextBox();
            this.txtCompanyDesc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCompanyLink = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCompanyName = new System.Windows.Forms.TextBox();
            this.lblCompanyCurrMonth = new System.Windows.Forms.Label();
            this.lblCompanyPrevMonth = new System.Windows.Forms.Label();
            this.webBrowserCompany = new System.Windows.Forms.WebBrowser();
            this.TC = new System.Windows.Forms.TabControl();
            this.tabInfraProfessional = new System.Windows.Forms.TabPage();
            this.splitContainer44 = new System.Windows.Forms.SplitContainer();
            this.btnInfraProfMoveDown = new System.Windows.Forms.Button();
            this.btnInfraProfMoveUp = new System.Windows.Forms.Button();
            this.btnInfraProfShowImg = new System.Windows.Forms.Button();
            this.btnInfraProfExit = new System.Windows.Forms.Button();
            this.btnInfraProfUploadImg = new System.Windows.Forms.Button();
            this.btnInfraProfDelete = new System.Windows.Forms.Button();
            this.btnInfraProfAdd = new System.Windows.Forms.Button();
            this.btnInfraProfUpdate = new System.Windows.Forms.Button();
            this.splitContainer45 = new System.Windows.Forms.SplitContainer();
            this.TVInfraProf = new System.Windows.Forms.TreeView();
            this.splitContainer46 = new System.Windows.Forms.SplitContainer();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.txtInfraProfEmail = new System.Windows.Forms.TextBox();
            this.txtInfraProfcompany = new System.Windows.Forms.TextBox();
            this.txtInfraProfDesignation = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.txtInfraProfContact = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.txtInfraProfQualification = new System.Windows.Forms.TextBox();
            this.txtInfraProfExperience = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.txtInfraProfDescription = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txtInfraProfName = new System.Windows.Forms.TextBox();
            this.tabconsultantcompany = new System.Windows.Forms.TabPage();
            this.splitContainer48 = new System.Windows.Forms.SplitContainer();
            this.btnConsultantCompanyExit = new System.Windows.Forms.Button();
            this.btnConsultantCompanyRead = new System.Windows.Forms.Button();
            this.btnConsultantCompanyWrite = new System.Windows.Forms.Button();
            this.btnConsultantCompanyMoveDown = new System.Windows.Forms.Button();
            this.btnConsultantCompanyMoveUp = new System.Windows.Forms.Button();
            this.btnConsultantCompanyShowLogo = new System.Windows.Forms.Button();
            this.btnConsultantCompanyAddgrp = new System.Windows.Forms.Button();
            this.btnConsultantCompanyUploadLogo = new System.Windows.Forms.Button();
            this.btnConsultantCompanyDelete = new System.Windows.Forms.Button();
            this.btnConsultantCompanyAdd = new System.Windows.Forms.Button();
            this.btnConsultantCompanyUpdate = new System.Windows.Forms.Button();
            this.splitContainer49 = new System.Windows.Forms.SplitContainer();
            this.TVConsultantCompany = new System.Windows.Forms.TreeView();
            this.splitContainer50 = new System.Windows.Forms.SplitContainer();
            this.label83 = new System.Windows.Forms.Label();
            this.txtConsultantCompanyCity = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label85 = new System.Windows.Forms.Label();
            this.txtConsultantCompanyshortname = new System.Windows.Forms.TextBox();
            this.txtConsultantCompanyDescription = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.txtConsultantCompanyLink = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.txtConsultantCompanyClientName = new System.Windows.Forms.TextBox();
            this.lblConsultantCompanyCurrMonth = new System.Windows.Forms.Label();
            this.lblConsultantCompanyPrevMonth = new System.Windows.Forms.Label();
            this.WebBrowserConsultantCompany = new System.Windows.Forms.WebBrowser();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabGovtPortal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer34)).BeginInit();
            this.splitContainer34.Panel1.SuspendLayout();
            this.splitContainer34.Panel2.SuspendLayout();
            this.splitContainer34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer35)).BeginInit();
            this.splitContainer35.Panel1.SuspendLayout();
            this.splitContainer35.Panel2.SuspendLayout();
            this.splitContainer35.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabProfessionals.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer16)).BeginInit();
            this.splitContainer16.Panel1.SuspendLayout();
            this.splitContainer16.Panel2.SuspendLayout();
            this.splitContainer16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer17)).BeginInit();
            this.splitContainer17.Panel1.SuspendLayout();
            this.splitContainer17.Panel2.SuspendLayout();
            this.splitContainer17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer18)).BeginInit();
            this.splitContainer18.Panel1.SuspendLayout();
            this.splitContainer18.Panel2.SuspendLayout();
            this.splitContainer18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).BeginInit();
            this.splitContainer14.Panel1.SuspendLayout();
            this.splitContainer14.Panel2.SuspendLayout();
            this.splitContainer14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbProfessional)).BeginInit();
            this.tabCompany.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            this.TC.SuspendLayout();
            this.tabInfraProfessional.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer44)).BeginInit();
            this.splitContainer44.Panel1.SuspendLayout();
            this.splitContainer44.Panel2.SuspendLayout();
            this.splitContainer44.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer45)).BeginInit();
            this.splitContainer45.Panel1.SuspendLayout();
            this.splitContainer45.Panel2.SuspendLayout();
            this.splitContainer45.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer46)).BeginInit();
            this.splitContainer46.Panel1.SuspendLayout();
            this.splitContainer46.SuspendLayout();
            this.tabconsultantcompany.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer48)).BeginInit();
            this.splitContainer48.Panel1.SuspendLayout();
            this.splitContainer48.Panel2.SuspendLayout();
            this.splitContainer48.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer49)).BeginInit();
            this.splitContainer49.Panel1.SuspendLayout();
            this.splitContainer49.Panel2.SuspendLayout();
            this.splitContainer49.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer50)).BeginInit();
            this.splitContainer50.Panel1.SuspendLayout();
            this.splitContainer50.Panel2.SuspendLayout();
            this.splitContainer50.SuspendLayout();
            this.SuspendLayout();
            // 
            // mOpenFile
            // 
            this.mOpenFile.FileName = "mOpenFile";
            // 
            // tabGovtPortal
            // 
            this.tabGovtPortal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabGovtPortal.Controls.Add(this.splitContainer34);
            this.tabGovtPortal.Location = new System.Drawing.Point(4, 22);
            this.tabGovtPortal.Name = "tabGovtPortal";
            this.tabGovtPortal.Padding = new System.Windows.Forms.Padding(3);
            this.tabGovtPortal.Size = new System.Drawing.Size(1176, 469);
            this.tabGovtPortal.TabIndex = 13;
            this.tabGovtPortal.Text = "Govt Portal";
            this.tabGovtPortal.UseVisualStyleBackColor = true;
            // 
            // splitContainer34
            // 
            this.splitContainer34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer34.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer34.IsSplitterFixed = true;
            this.splitContainer34.Location = new System.Drawing.Point(3, 3);
            this.splitContainer34.Name = "splitContainer34";
            this.splitContainer34.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer34.Panel1
            // 
            this.splitContainer34.Panel1.Controls.Add(this.btnGovPoratlMoveDown);
            this.splitContainer34.Panel1.Controls.Add(this.btnGovPoratlMoveUp);
            this.splitContainer34.Panel1.Controls.Add(this.btnGovPoratlExit);
            this.splitContainer34.Panel1.Controls.Add(this.btnGovPoratlDelete);
            this.splitContainer34.Panel1.Controls.Add(this.btnGovPoratlAdd);
            this.splitContainer34.Panel1.Controls.Add(this.btnGovPoratlUpdate);
            // 
            // splitContainer34.Panel2
            // 
            this.splitContainer34.Panel2.Controls.Add(this.splitContainer35);
            this.splitContainer34.Size = new System.Drawing.Size(1168, 461);
            this.splitContainer34.SplitterDistance = 60;
            this.splitContainer34.TabIndex = 3;
            // 
            // btnGovPoratlMoveDown
            // 
            this.btnGovPoratlMoveDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGovPoratlMoveDown.Location = new System.Drawing.Point(394, 20);
            this.btnGovPoratlMoveDown.Name = "btnGovPoratlMoveDown";
            this.btnGovPoratlMoveDown.Size = new System.Drawing.Size(50, 25);
            this.btnGovPoratlMoveDown.TabIndex = 40;
            this.btnGovPoratlMoveDown.Text = "\\/";
            this.btnGovPoratlMoveDown.UseVisualStyleBackColor = true;
            this.btnGovPoratlMoveDown.Click += new System.EventHandler(this.btnGovPoratlMoveDown_Click);
            // 
            // btnGovPoratlMoveUp
            // 
            this.btnGovPoratlMoveUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGovPoratlMoveUp.Location = new System.Drawing.Point(338, 20);
            this.btnGovPoratlMoveUp.Name = "btnGovPoratlMoveUp";
            this.btnGovPoratlMoveUp.Size = new System.Drawing.Size(50, 25);
            this.btnGovPoratlMoveUp.TabIndex = 39;
            this.btnGovPoratlMoveUp.Text = "/\\";
            this.btnGovPoratlMoveUp.UseVisualStyleBackColor = true;
            this.btnGovPoratlMoveUp.Click += new System.EventHandler(this.btnGovPoratlMoveUp_Click);
            // 
            // btnGovPoratlExit
            // 
            this.btnGovPoratlExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGovPoratlExit.Location = new System.Drawing.Point(1044, 20);
            this.btnGovPoratlExit.Name = "btnGovPoratlExit";
            this.btnGovPoratlExit.Size = new System.Drawing.Size(100, 25);
            this.btnGovPoratlExit.TabIndex = 30;
            this.btnGovPoratlExit.Text = "Exit";
            this.btnGovPoratlExit.UseVisualStyleBackColor = true;
            this.btnGovPoratlExit.Click += new System.EventHandler(this.btnGovPoratlExit_Click);
            // 
            // btnGovPoratlDelete
            // 
            this.btnGovPoratlDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGovPoratlDelete.Location = new System.Drawing.Point(232, 20);
            this.btnGovPoratlDelete.Name = "btnGovPoratlDelete";
            this.btnGovPoratlDelete.Size = new System.Drawing.Size(100, 25);
            this.btnGovPoratlDelete.TabIndex = 28;
            this.btnGovPoratlDelete.Text = "Delete";
            this.btnGovPoratlDelete.UseVisualStyleBackColor = true;
            this.btnGovPoratlDelete.Click += new System.EventHandler(this.btnGovPoratlDelete_Click);
            // 
            // btnGovPoratlAdd
            // 
            this.btnGovPoratlAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGovPoratlAdd.Location = new System.Drawing.Point(20, 20);
            this.btnGovPoratlAdd.Name = "btnGovPoratlAdd";
            this.btnGovPoratlAdd.Size = new System.Drawing.Size(100, 25);
            this.btnGovPoratlAdd.TabIndex = 29;
            this.btnGovPoratlAdd.Text = "Add";
            this.btnGovPoratlAdd.UseVisualStyleBackColor = true;
            this.btnGovPoratlAdd.Click += new System.EventHandler(this.btnGovPoratlAdd_Click);
            // 
            // btnGovPoratlUpdate
            // 
            this.btnGovPoratlUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGovPoratlUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnGovPoratlUpdate.Name = "btnGovPoratlUpdate";
            this.btnGovPoratlUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnGovPoratlUpdate.TabIndex = 27;
            this.btnGovPoratlUpdate.Text = "Update";
            this.btnGovPoratlUpdate.UseVisualStyleBackColor = true;
            this.btnGovPoratlUpdate.Click += new System.EventHandler(this.btnGovPoratlUpdate_Click);
            // 
            // splitContainer35
            // 
            this.splitContainer35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer35.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer35.IsSplitterFixed = true;
            this.splitContainer35.Location = new System.Drawing.Point(0, 0);
            this.splitContainer35.Name = "splitContainer35";
            // 
            // splitContainer35.Panel1
            // 
            this.splitContainer35.Panel1.Controls.Add(this.TVGovPoratl);
            this.splitContainer35.Panel1.Controls.Add(this.label7);
            // 
            // splitContainer35.Panel2
            // 
            this.splitContainer35.Panel2.Controls.Add(this.splitContainer1);
            this.splitContainer35.Panel2.Controls.Add(this.chkGovPoratlLinkFlag);
            this.splitContainer35.Size = new System.Drawing.Size(1168, 397);
            this.splitContainer35.SplitterDistance = 300;
            this.splitContainer35.TabIndex = 0;
            // 
            // TVGovPoratl
            // 
            this.TVGovPoratl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVGovPoratl.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVGovPoratl.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVGovPoratl.FullRowSelect = true;
            this.TVGovPoratl.HideSelection = false;
            this.TVGovPoratl.Location = new System.Drawing.Point(0, 25);
            this.TVGovPoratl.Name = "TVGovPoratl";
            this.TVGovPoratl.Size = new System.Drawing.Size(298, 370);
            this.TVGovPoratl.TabIndex = 28;
            this.TVGovPoratl.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVGovPoratl.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVGovPoratl_MouseDoubleClick);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label54);
            this.splitContainer1.Panel1.Controls.Add(this.txtGovPortalName);
            this.splitContainer1.Panel1.Controls.Add(this.label51);
            this.splitContainer1.Panel1.Controls.Add(this.txtGovPoratlLink);
            this.splitContainer1.Size = new System.Drawing.Size(864, 397);
            this.splitContainer1.SplitterDistance = 275;
            this.splitContainer1.TabIndex = 222;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(22, 15);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(41, 16);
            this.label54.TabIndex = 28;
            this.label54.Text = "Name";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtGovPortalName
            // 
            this.txtGovPortalName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGovPortalName.Location = new System.Drawing.Point(19, 33);
            this.txtGovPortalName.Name = "txtGovPortalName";
            this.txtGovPortalName.Size = new System.Drawing.Size(680, 22);
            this.txtGovPortalName.TabIndex = 29;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(22, 66);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(31, 16);
            this.label51.TabIndex = 38;
            this.label51.Text = "Link";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtGovPoratlLink
            // 
            this.txtGovPoratlLink.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGovPoratlLink.Location = new System.Drawing.Point(19, 84);
            this.txtGovPoratlLink.Name = "txtGovPoratlLink";
            this.txtGovPoratlLink.Size = new System.Drawing.Size(680, 22);
            this.txtGovPoratlLink.TabIndex = 39;
            // 
            // chkGovPoratlLinkFlag
            // 
            this.chkGovPoratlLinkFlag.AutoSize = true;
            this.chkGovPoratlLinkFlag.Location = new System.Drawing.Point(705, 86);
            this.chkGovPoratlLinkFlag.Name = "chkGovPoratlLinkFlag";
            this.chkGovPoratlLinkFlag.Size = new System.Drawing.Size(66, 17);
            this.chkGovPoratlLinkFlag.TabIndex = 221;
            this.chkGovPoratlLinkFlag.Text = "LinkFlag";
            this.chkGovPoratlLinkFlag.UseVisualStyleBackColor = true;
            // 
            // tabProfessionals
            // 
            this.tabProfessionals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabProfessionals.Controls.Add(this.splitContainer16);
            this.tabProfessionals.Location = new System.Drawing.Point(4, 22);
            this.tabProfessionals.Name = "tabProfessionals";
            this.tabProfessionals.Padding = new System.Windows.Forms.Padding(3);
            this.tabProfessionals.Size = new System.Drawing.Size(1176, 469);
            this.tabProfessionals.TabIndex = 6;
            this.tabProfessionals.Text = "Professionals";
            this.tabProfessionals.UseVisualStyleBackColor = true;
            // 
            // splitContainer16
            // 
            this.splitContainer16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer16.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer16.IsSplitterFixed = true;
            this.splitContainer16.Location = new System.Drawing.Point(3, 3);
            this.splitContainer16.Name = "splitContainer16";
            this.splitContainer16.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer16.Panel1
            // 
            this.splitContainer16.Panel1.Controls.Add(this.btnProfMoveDown);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfMoveUp);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfAddGrp);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfShowPhoto);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfULPhoto);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfDefault);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfExit);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfDelete);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfAdd);
            this.splitContainer16.Panel1.Controls.Add(this.btnProfUpdate);
            // 
            // splitContainer16.Panel2
            // 
            this.splitContainer16.Panel2.Controls.Add(this.splitContainer17);
            this.splitContainer16.Size = new System.Drawing.Size(1168, 461);
            this.splitContainer16.SplitterDistance = 60;
            this.splitContainer16.TabIndex = 2;
            // 
            // btnProfMoveDown
            // 
            this.btnProfMoveDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfMoveDown.Location = new System.Drawing.Point(712, 20);
            this.btnProfMoveDown.Name = "btnProfMoveDown";
            this.btnProfMoveDown.Size = new System.Drawing.Size(50, 25);
            this.btnProfMoveDown.TabIndex = 42;
            this.btnProfMoveDown.Text = "\\/";
            this.btnProfMoveDown.UseVisualStyleBackColor = true;
            this.btnProfMoveDown.Click += new System.EventHandler(this.btnProfMoveDown_Click);
            // 
            // btnProfMoveUp
            // 
            this.btnProfMoveUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfMoveUp.Location = new System.Drawing.Point(656, 20);
            this.btnProfMoveUp.Name = "btnProfMoveUp";
            this.btnProfMoveUp.Size = new System.Drawing.Size(50, 25);
            this.btnProfMoveUp.TabIndex = 41;
            this.btnProfMoveUp.Text = "/\\";
            this.btnProfMoveUp.UseVisualStyleBackColor = true;
            this.btnProfMoveUp.Click += new System.EventHandler(this.btnProfMoveUp_Click);
            // 
            // btnProfAddGrp
            // 
            this.btnProfAddGrp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfAddGrp.Location = new System.Drawing.Point(20, 20);
            this.btnProfAddGrp.Name = "btnProfAddGrp";
            this.btnProfAddGrp.Size = new System.Drawing.Size(100, 25);
            this.btnProfAddGrp.TabIndex = 40;
            this.btnProfAddGrp.Text = "Add Group";
            this.btnProfAddGrp.UseVisualStyleBackColor = true;
            this.btnProfAddGrp.Click += new System.EventHandler(this.btnProfAddGrp_Click_1);
            // 
            // btnProfShowPhoto
            // 
            this.btnProfShowPhoto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfShowPhoto.Location = new System.Drawing.Point(550, 20);
            this.btnProfShowPhoto.Name = "btnProfShowPhoto";
            this.btnProfShowPhoto.Size = new System.Drawing.Size(100, 25);
            this.btnProfShowPhoto.TabIndex = 39;
            this.btnProfShowPhoto.Text = "Show Photo";
            this.btnProfShowPhoto.UseVisualStyleBackColor = true;
            this.btnProfShowPhoto.Click += new System.EventHandler(this.btnProfessionalShowLogo_Click);
            // 
            // btnProfULPhoto
            // 
            this.btnProfULPhoto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfULPhoto.Location = new System.Drawing.Point(444, 20);
            this.btnProfULPhoto.Name = "btnProfULPhoto";
            this.btnProfULPhoto.Size = new System.Drawing.Size(100, 25);
            this.btnProfULPhoto.TabIndex = 38;
            this.btnProfULPhoto.Text = "Upload Reviewer Photo";
            this.btnProfULPhoto.UseVisualStyleBackColor = true;
            this.btnProfULPhoto.Click += new System.EventHandler(this.btnProfUploadPhoto_Click);
            // 
            // btnProfDefault
            // 
            this.btnProfDefault.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfDefault.Location = new System.Drawing.Point(938, 20);
            this.btnProfDefault.Name = "btnProfDefault";
            this.btnProfDefault.Size = new System.Drawing.Size(100, 25);
            this.btnProfDefault.TabIndex = 34;
            this.btnProfDefault.Text = "Default";
            this.btnProfDefault.UseVisualStyleBackColor = true;
            this.btnProfDefault.Click += new System.EventHandler(this.btnProfDefault_Click);
            // 
            // btnProfExit
            // 
            this.btnProfExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfExit.Location = new System.Drawing.Point(1044, 20);
            this.btnProfExit.Name = "btnProfExit";
            this.btnProfExit.Size = new System.Drawing.Size(100, 25);
            this.btnProfExit.TabIndex = 30;
            this.btnProfExit.Text = "Exit";
            this.btnProfExit.UseVisualStyleBackColor = true;
            this.btnProfExit.Click += new System.EventHandler(this.btnProfExit_Click);
            // 
            // btnProfDelete
            // 
            this.btnProfDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfDelete.Location = new System.Drawing.Point(338, 20);
            this.btnProfDelete.Name = "btnProfDelete";
            this.btnProfDelete.Size = new System.Drawing.Size(100, 25);
            this.btnProfDelete.TabIndex = 28;
            this.btnProfDelete.Text = "Delete";
            this.btnProfDelete.UseVisualStyleBackColor = true;
            this.btnProfDelete.Click += new System.EventHandler(this.btnProfDelete_Click);
            // 
            // btnProfAdd
            // 
            this.btnProfAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfAdd.Location = new System.Drawing.Point(126, 20);
            this.btnProfAdd.Name = "btnProfAdd";
            this.btnProfAdd.Size = new System.Drawing.Size(100, 25);
            this.btnProfAdd.TabIndex = 29;
            this.btnProfAdd.Text = "Add";
            this.btnProfAdd.UseVisualStyleBackColor = true;
            this.btnProfAdd.Click += new System.EventHandler(this.btnProfAdd_Click);
            // 
            // btnProfUpdate
            // 
            this.btnProfUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfUpdate.Location = new System.Drawing.Point(232, 20);
            this.btnProfUpdate.Name = "btnProfUpdate";
            this.btnProfUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnProfUpdate.TabIndex = 27;
            this.btnProfUpdate.Text = "Update";
            this.btnProfUpdate.UseVisualStyleBackColor = true;
            this.btnProfUpdate.Click += new System.EventHandler(this.btnProfUpdate_Click);
            // 
            // splitContainer17
            // 
            this.splitContainer17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer17.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer17.IsSplitterFixed = true;
            this.splitContainer17.Location = new System.Drawing.Point(0, 0);
            this.splitContainer17.Name = "splitContainer17";
            // 
            // splitContainer17.Panel1
            // 
            this.splitContainer17.Panel1.Controls.Add(this.TVProfessional);
            this.splitContainer17.Panel1.Controls.Add(this.label6);
            // 
            // splitContainer17.Panel2
            // 
            this.splitContainer17.Panel2.Controls.Add(this.splitContainer18);
            this.splitContainer17.Size = new System.Drawing.Size(1168, 397);
            this.splitContainer17.SplitterDistance = 300;
            this.splitContainer17.TabIndex = 0;
            // 
            // TVProfessional
            // 
            this.TVProfessional.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVProfessional.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVProfessional.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVProfessional.FullRowSelect = true;
            this.TVProfessional.HideSelection = false;
            this.TVProfessional.Location = new System.Drawing.Point(0, 25);
            this.TVProfessional.Name = "TVProfessional";
            this.TVProfessional.Size = new System.Drawing.Size(298, 370);
            this.TVProfessional.TabIndex = 28;
            this.TVProfessional.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVProfessional.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVProf_MouseDoubleClick);
            // 
            // splitContainer18
            // 
            this.splitContainer18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer18.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer18.IsSplitterFixed = true;
            this.splitContainer18.Location = new System.Drawing.Point(0, 0);
            this.splitContainer18.Name = "splitContainer18";
            this.splitContainer18.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer18.Panel1
            // 
            this.splitContainer18.Panel1.Controls.Add(this.splitContainer14);
            // 
            // splitContainer18.Panel2
            // 
            this.splitContainer18.Panel2.Controls.Add(this.PbProfessional);
            this.splitContainer18.Size = new System.Drawing.Size(864, 397);
            this.splitContainer18.SplitterDistance = 275;
            this.splitContainer18.TabIndex = 218;
            // 
            // splitContainer14
            // 
            this.splitContainer14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer14.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer14.IsSplitterFixed = true;
            this.splitContainer14.Location = new System.Drawing.Point(0, 0);
            this.splitContainer14.Name = "splitContainer14";
            // 
            // splitContainer14.Panel1
            // 
            this.splitContainer14.Panel1.Controls.Add(this.label5);
            this.splitContainer14.Panel1.Controls.Add(this.label13);
            this.splitContainer14.Panel1.Controls.Add(this.txtProfDesc);
            this.splitContainer14.Panel1.Controls.Add(this.txtProfDesignation);
            this.splitContainer14.Panel1.Controls.Add(this.label4);
            this.splitContainer14.Panel1.Controls.Add(this.txtProfName);
            // 
            // splitContainer14.Panel2
            // 
            this.splitContainer14.Panel2.Controls.Add(this.TVProfCompany);
            this.splitContainer14.Panel2.Controls.Add(this.label14);
            this.splitContainer14.Size = new System.Drawing.Size(864, 275);
            this.splitContainer14.SplitterDistance = 500;
            this.splitContainer14.TabIndex = 43;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 16);
            this.label5.TabIndex = 30;
            this.label5.Text = "Name";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(22, 118);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 16);
            this.label13.TabIndex = 119;
            this.label13.Text = "Designation";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtProfDesc
            // 
            this.txtProfDesc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProfDesc.Location = new System.Drawing.Point(19, 84);
            this.txtProfDesc.Name = "txtProfDesc";
            this.txtProfDesc.Size = new System.Drawing.Size(462, 22);
            this.txtProfDesc.TabIndex = 33;
            // 
            // txtProfDesignation
            // 
            this.txtProfDesignation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProfDesignation.Location = new System.Drawing.Point(19, 136);
            this.txtProfDesignation.Name = "txtProfDesignation";
            this.txtProfDesignation.Size = new System.Drawing.Size(462, 22);
            this.txtProfDesignation.TabIndex = 120;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 32;
            this.label4.Text = "Description";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtProfName
            // 
            this.txtProfName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProfName.Location = new System.Drawing.Point(19, 33);
            this.txtProfName.Name = "txtProfName";
            this.txtProfName.Size = new System.Drawing.Size(462, 22);
            this.txtProfName.TabIndex = 31;
            // 
            // TVProfCompany
            // 
            this.TVProfCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVProfCompany.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVProfCompany.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVProfCompany.FullRowSelect = true;
            this.TVProfCompany.HideSelection = false;
            this.TVProfCompany.Location = new System.Drawing.Point(0, 25);
            this.TVProfCompany.Name = "TVProfCompany";
            this.TVProfCompany.Size = new System.Drawing.Size(358, 248);
            this.TVProfCompany.TabIndex = 29;
            this.TVProfCompany.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            // 
            // label14
            // 
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(358, 25);
            this.label14.TabIndex = 37;
            this.label14.Text = "Company";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PbProfessional
            // 
            this.PbProfessional.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PbProfessional.Location = new System.Drawing.Point(0, 0);
            this.PbProfessional.Name = "PbProfessional";
            this.PbProfessional.Size = new System.Drawing.Size(862, 116);
            this.PbProfessional.TabIndex = 42;
            this.PbProfessional.TabStop = false;
            // 
            // tabCompany
            // 
            this.tabCompany.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabCompany.Controls.Add(this.splitContainer5);
            this.tabCompany.Location = new System.Drawing.Point(4, 22);
            this.tabCompany.Name = "tabCompany";
            this.tabCompany.Padding = new System.Windows.Forms.Padding(3);
            this.tabCompany.Size = new System.Drawing.Size(1176, 469);
            this.tabCompany.TabIndex = 3;
            this.tabCompany.Text = "Company";
            this.tabCompany.UseVisualStyleBackColor = true;
            // 
            // splitContainer5
            // 
            this.splitContainer5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.IsSplitterFixed = true;
            this.splitContainer5.Location = new System.Drawing.Point(3, 3);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyExit);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyRead);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyWrite);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyDown);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyUp);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyShowLogo);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyAddGrp);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyDefault);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyUploadLogo);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyDelete);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyAdd);
            this.splitContainer5.Panel1.Controls.Add(this.btnCompanyUpdate);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer5.Size = new System.Drawing.Size(1168, 461);
            this.splitContainer5.SplitterDistance = 60;
            this.splitContainer5.TabIndex = 1;
            // 
            // btnCompanyExit
            // 
            this.btnCompanyExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyExit.Location = new System.Drawing.Point(1086, 20);
            this.btnCompanyExit.Name = "btnCompanyExit";
            this.btnCompanyExit.Size = new System.Drawing.Size(50, 25);
            this.btnCompanyExit.TabIndex = 43;
            this.btnCompanyExit.Text = "X";
            this.btnCompanyExit.UseVisualStyleBackColor = true;
            this.btnCompanyExit.Click += new System.EventHandler(this.btnCompanyExit_Click);
            // 
            // btnCompanyRead
            // 
            this.btnCompanyRead.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyRead.Location = new System.Drawing.Point(874, 20);
            this.btnCompanyRead.Name = "btnCompanyRead";
            this.btnCompanyRead.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyRead.TabIndex = 42;
            this.btnCompanyRead.Text = "Read";
            this.btnCompanyRead.UseVisualStyleBackColor = true;
            this.btnCompanyRead.Click += new System.EventHandler(this.btnCompanyRead_Click);
            // 
            // btnCompanyWrite
            // 
            this.btnCompanyWrite.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyWrite.Location = new System.Drawing.Point(768, 20);
            this.btnCompanyWrite.Name = "btnCompanyWrite";
            this.btnCompanyWrite.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyWrite.TabIndex = 41;
            this.btnCompanyWrite.Text = "Write";
            this.btnCompanyWrite.UseVisualStyleBackColor = true;
            this.btnCompanyWrite.Click += new System.EventHandler(this.btnCompanyWrite_Click);
            // 
            // btnCompanyDown
            // 
            this.btnCompanyDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyDown.Location = new System.Drawing.Point(712, 20);
            this.btnCompanyDown.Name = "btnCompanyDown";
            this.btnCompanyDown.Size = new System.Drawing.Size(50, 25);
            this.btnCompanyDown.TabIndex = 40;
            this.btnCompanyDown.Text = "\\/";
            this.btnCompanyDown.UseVisualStyleBackColor = true;
            this.btnCompanyDown.Click += new System.EventHandler(this.btnCompanyDown_Click);
            // 
            // btnCompanyUp
            // 
            this.btnCompanyUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyUp.Location = new System.Drawing.Point(656, 20);
            this.btnCompanyUp.Name = "btnCompanyUp";
            this.btnCompanyUp.Size = new System.Drawing.Size(50, 25);
            this.btnCompanyUp.TabIndex = 39;
            this.btnCompanyUp.Text = "/\\";
            this.btnCompanyUp.UseVisualStyleBackColor = true;
            this.btnCompanyUp.Click += new System.EventHandler(this.btnCompanyUp_Click);
            // 
            // btnCompanyShowLogo
            // 
            this.btnCompanyShowLogo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyShowLogo.Location = new System.Drawing.Point(550, 20);
            this.btnCompanyShowLogo.Name = "btnCompanyShowLogo";
            this.btnCompanyShowLogo.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyShowLogo.TabIndex = 37;
            this.btnCompanyShowLogo.Text = "Show Logo";
            this.btnCompanyShowLogo.UseVisualStyleBackColor = true;
            this.btnCompanyShowLogo.Click += new System.EventHandler(this.btnCompanyShowLogo_Click);
            // 
            // btnCompanyAddGrp
            // 
            this.btnCompanyAddGrp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyAddGrp.Location = new System.Drawing.Point(20, 20);
            this.btnCompanyAddGrp.Name = "btnCompanyAddGrp";
            this.btnCompanyAddGrp.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyAddGrp.TabIndex = 36;
            this.btnCompanyAddGrp.Text = "Add Group";
            this.btnCompanyAddGrp.UseVisualStyleBackColor = true;
            this.btnCompanyAddGrp.Click += new System.EventHandler(this.btnCompanyAddGrp_Click);
            // 
            // btnCompanyDefault
            // 
            this.btnCompanyDefault.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyDefault.Location = new System.Drawing.Point(980, 20);
            this.btnCompanyDefault.Name = "btnCompanyDefault";
            this.btnCompanyDefault.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyDefault.TabIndex = 35;
            this.btnCompanyDefault.Text = "Default";
            this.btnCompanyDefault.UseVisualStyleBackColor = true;
            this.btnCompanyDefault.Click += new System.EventHandler(this.btnCompanyDefault_Click);
            // 
            // btnCompanyUploadLogo
            // 
            this.btnCompanyUploadLogo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyUploadLogo.Location = new System.Drawing.Point(444, 20);
            this.btnCompanyUploadLogo.Name = "btnCompanyUploadLogo";
            this.btnCompanyUploadLogo.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyUploadLogo.TabIndex = 31;
            this.btnCompanyUploadLogo.Text = "Upload Logo";
            this.btnCompanyUploadLogo.UseVisualStyleBackColor = true;
            this.btnCompanyUploadLogo.Click += new System.EventHandler(this.btnCompanyUploadLogo_Click);
            // 
            // btnCompanyDelete
            // 
            this.btnCompanyDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyDelete.Location = new System.Drawing.Point(338, 20);
            this.btnCompanyDelete.Name = "btnCompanyDelete";
            this.btnCompanyDelete.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyDelete.TabIndex = 28;
            this.btnCompanyDelete.Text = "Delete";
            this.btnCompanyDelete.UseVisualStyleBackColor = true;
            this.btnCompanyDelete.Click += new System.EventHandler(this.btnCompanyDelete_Click);
            // 
            // btnCompanyAdd
            // 
            this.btnCompanyAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyAdd.Location = new System.Drawing.Point(126, 20);
            this.btnCompanyAdd.Name = "btnCompanyAdd";
            this.btnCompanyAdd.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyAdd.TabIndex = 29;
            this.btnCompanyAdd.Text = "Add";
            this.btnCompanyAdd.UseVisualStyleBackColor = true;
            this.btnCompanyAdd.Click += new System.EventHandler(this.btnCompanyAdd_Click);
            // 
            // btnCompanyUpdate
            // 
            this.btnCompanyUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyUpdate.Location = new System.Drawing.Point(232, 20);
            this.btnCompanyUpdate.Name = "btnCompanyUpdate";
            this.btnCompanyUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnCompanyUpdate.TabIndex = 27;
            this.btnCompanyUpdate.Text = "Update";
            this.btnCompanyUpdate.UseVisualStyleBackColor = true;
            this.btnCompanyUpdate.Click += new System.EventHandler(this.btnCompanyUpdate_Click);
            // 
            // splitContainer6
            // 
            this.splitContainer6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer6.IsSplitterFixed = true;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.TVCompany);
            this.splitContainer6.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.splitContainer11);
            this.splitContainer6.Size = new System.Drawing.Size(1168, 397);
            this.splitContainer6.SplitterDistance = 300;
            this.splitContainer6.TabIndex = 0;
            // 
            // TVCompany
            // 
            this.TVCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVCompany.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVCompany.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVCompany.FullRowSelect = true;
            this.TVCompany.HideSelection = false;
            this.TVCompany.Location = new System.Drawing.Point(0, 25);
            this.TVCompany.Name = "TVCompany";
            this.TVCompany.Size = new System.Drawing.Size(298, 370);
            this.TVCompany.TabIndex = 28;
            this.TVCompany.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVCompany.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVCompany_MouseDoubleClick);
            // 
            // splitContainer11
            // 
            this.splitContainer11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer11.IsSplitterFixed = true;
            this.splitContainer11.Location = new System.Drawing.Point(0, 0);
            this.splitContainer11.Name = "splitContainer11";
            this.splitContainer11.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.label66);
            this.splitContainer11.Panel1.Controls.Add(this.txtCompanyCity);
            this.splitContainer11.Panel1.Controls.Add(this.ckhCompanyFlag);
            this.splitContainer11.Panel1.Controls.Add(this.label16);
            this.splitContainer11.Panel1.Controls.Add(this.txtCompanyOpeningLinkAdd);
            this.splitContainer11.Panel1.Controls.Add(this.label12);
            this.splitContainer11.Panel1.Controls.Add(this.txtCompanyShortName);
            this.splitContainer11.Panel1.Controls.Add(this.txtCompanyDesc);
            this.splitContainer11.Panel1.Controls.Add(this.label2);
            this.splitContainer11.Panel1.Controls.Add(this.label8);
            this.splitContainer11.Panel1.Controls.Add(this.txtCompanyLink);
            this.splitContainer11.Panel1.Controls.Add(this.label3);
            this.splitContainer11.Panel1.Controls.Add(this.txtCompanyName);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.lblCompanyCurrMonth);
            this.splitContainer11.Panel2.Controls.Add(this.lblCompanyPrevMonth);
            this.splitContainer11.Panel2.Controls.Add(this.webBrowserCompany);
            this.splitContainer11.Size = new System.Drawing.Size(864, 397);
            this.splitContainer11.SplitterDistance = 275;
            this.splitContainer11.TabIndex = 34;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(293, 117);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(30, 16);
            this.label66.TabIndex = 222;
            this.label66.Text = "City";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCompanyCity
            // 
            this.txtCompanyCity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyCity.Location = new System.Drawing.Point(290, 136);
            this.txtCompanyCity.Name = "txtCompanyCity";
            this.txtCompanyCity.Size = new System.Drawing.Size(264, 22);
            this.txtCompanyCity.TabIndex = 223;
            // 
            // ckhCompanyFlag
            // 
            this.ckhCompanyFlag.AutoSize = true;
            this.ckhCompanyFlag.Location = new System.Drawing.Point(705, 244);
            this.ckhCompanyFlag.Name = "ckhCompanyFlag";
            this.ckhCompanyFlag.Size = new System.Drawing.Size(66, 17);
            this.ckhCompanyFlag.TabIndex = 221;
            this.ckhCompanyFlag.Text = "LinkFlag";
            this.ckhCompanyFlag.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(22, 222);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(161, 16);
            this.label16.TabIndex = 40;
            this.label16.Text = "Job Openinig Link Address";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCompanyOpeningLinkAdd
            // 
            this.txtCompanyOpeningLinkAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyOpeningLinkAdd.Location = new System.Drawing.Point(19, 240);
            this.txtCompanyOpeningLinkAdd.Name = "txtCompanyOpeningLinkAdd";
            this.txtCompanyOpeningLinkAdd.Size = new System.Drawing.Size(680, 22);
            this.txtCompanyOpeningLinkAdd.TabIndex = 41;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 16);
            this.label12.TabIndex = 38;
            this.label12.Text = "Short Name";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCompanyShortName
            // 
            this.txtCompanyShortName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyShortName.Location = new System.Drawing.Point(19, 84);
            this.txtCompanyShortName.Name = "txtCompanyShortName";
            this.txtCompanyShortName.Size = new System.Drawing.Size(264, 22);
            this.txtCompanyShortName.TabIndex = 39;
            // 
            // txtCompanyDesc
            // 
            this.txtCompanyDesc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyDesc.Location = new System.Drawing.Point(19, 136);
            this.txtCompanyDesc.Name = "txtCompanyDesc";
            this.txtCompanyDesc.Size = new System.Drawing.Size(264, 22);
            this.txtCompanyDesc.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(306, 16);
            this.label2.TabIndex = 36;
            this.label2.Text = "Link Address (double click the link to view the page)";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 118);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 16);
            this.label8.TabIndex = 34;
            this.label8.Text = "Description";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCompanyLink
            // 
            this.txtCompanyLink.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyLink.Location = new System.Drawing.Point(19, 187);
            this.txtCompanyLink.Name = "txtCompanyLink";
            this.txtCompanyLink.Size = new System.Drawing.Size(680, 22);
            this.txtCompanyLink.TabIndex = 37;
            this.txtCompanyLink.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtCompanyLink_MouseDoubleClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "Client Name";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyName.Location = new System.Drawing.Point(19, 33);
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(804, 22);
            this.txtCompanyName.TabIndex = 29;
            // 
            // lblCompanyCurrMonth
            // 
            this.lblCompanyCurrMonth.AutoSize = true;
            this.lblCompanyCurrMonth.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyCurrMonth.Location = new System.Drawing.Point(22, 56);
            this.lblCompanyCurrMonth.Name = "lblCompanyCurrMonth";
            this.lblCompanyCurrMonth.Size = new System.Drawing.Size(127, 16);
            this.lblCompanyCurrMonth.TabIndex = 227;
            this.lblCompanyCurrMonth.Text = "Current Month Count";
            this.lblCompanyCurrMonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCompanyPrevMonth
            // 
            this.lblCompanyPrevMonth.AutoSize = true;
            this.lblCompanyPrevMonth.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyPrevMonth.Location = new System.Drawing.Point(22, 18);
            this.lblCompanyPrevMonth.Name = "lblCompanyPrevMonth";
            this.lblCompanyPrevMonth.Size = new System.Drawing.Size(134, 16);
            this.lblCompanyPrevMonth.TabIndex = 226;
            this.lblCompanyPrevMonth.Text = "Previous Month Count";
            this.lblCompanyPrevMonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // webBrowserCompany
            // 
            this.webBrowserCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserCompany.Location = new System.Drawing.Point(0, 0);
            this.webBrowserCompany.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserCompany.Name = "webBrowserCompany";
            this.webBrowserCompany.Size = new System.Drawing.Size(862, 116);
            this.webBrowserCompany.TabIndex = 46;
            // 
            // TC
            // 
            this.TC.Controls.Add(this.tabCompany);
            this.TC.Controls.Add(this.tabProfessionals);
            this.TC.Controls.Add(this.tabGovtPortal);
            this.TC.Controls.Add(this.tabInfraProfessional);
            this.TC.Controls.Add(this.tabconsultantcompany);
            this.TC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TC.Location = new System.Drawing.Point(0, 0);
            this.TC.Name = "TC";
            this.TC.SelectedIndex = 0;
            this.TC.Size = new System.Drawing.Size(1184, 495);
            this.TC.TabIndex = 0;
            this.TC.SelectedIndexChanged += new System.EventHandler(this.TC_SelectedIndexChanged);
            // 
            // tabInfraProfessional
            // 
            this.tabInfraProfessional.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabInfraProfessional.Controls.Add(this.splitContainer44);
            this.tabInfraProfessional.Location = new System.Drawing.Point(4, 22);
            this.tabInfraProfessional.Name = "tabInfraProfessional";
            this.tabInfraProfessional.Padding = new System.Windows.Forms.Padding(3);
            this.tabInfraProfessional.Size = new System.Drawing.Size(1176, 469);
            this.tabInfraProfessional.TabIndex = 17;
            this.tabInfraProfessional.Text = "InfraProfessional";
            this.tabInfraProfessional.UseVisualStyleBackColor = true;
            // 
            // splitContainer44
            // 
            this.splitContainer44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer44.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer44.IsSplitterFixed = true;
            this.splitContainer44.Location = new System.Drawing.Point(3, 3);
            this.splitContainer44.Name = "splitContainer44";
            this.splitContainer44.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer44.Panel1
            // 
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfMoveDown);
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfMoveUp);
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfShowImg);
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfExit);
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfUploadImg);
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfDelete);
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfAdd);
            this.splitContainer44.Panel1.Controls.Add(this.btnInfraProfUpdate);
            // 
            // splitContainer44.Panel2
            // 
            this.splitContainer44.Panel2.Controls.Add(this.splitContainer45);
            this.splitContainer44.Size = new System.Drawing.Size(1168, 461);
            this.splitContainer44.SplitterDistance = 60;
            this.splitContainer44.TabIndex = 3;
            // 
            // btnInfraProfMoveDown
            // 
            this.btnInfraProfMoveDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfMoveDown.Location = new System.Drawing.Point(607, 20);
            this.btnInfraProfMoveDown.Name = "btnInfraProfMoveDown";
            this.btnInfraProfMoveDown.Size = new System.Drawing.Size(50, 25);
            this.btnInfraProfMoveDown.TabIndex = 40;
            this.btnInfraProfMoveDown.Text = "\\/";
            this.btnInfraProfMoveDown.UseVisualStyleBackColor = true;
            this.btnInfraProfMoveDown.Click += new System.EventHandler(this.btnInfraProfMoveDown_Click);
            // 
            // btnInfraProfMoveUp
            // 
            this.btnInfraProfMoveUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfMoveUp.Location = new System.Drawing.Point(550, 20);
            this.btnInfraProfMoveUp.Name = "btnInfraProfMoveUp";
            this.btnInfraProfMoveUp.Size = new System.Drawing.Size(50, 25);
            this.btnInfraProfMoveUp.TabIndex = 39;
            this.btnInfraProfMoveUp.Text = "/\\";
            this.btnInfraProfMoveUp.UseVisualStyleBackColor = true;
            this.btnInfraProfMoveUp.Click += new System.EventHandler(this.btnInfraProfMoveUp_Click);
            // 
            // btnInfraProfShowImg
            // 
            this.btnInfraProfShowImg.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfShowImg.Location = new System.Drawing.Point(444, 20);
            this.btnInfraProfShowImg.Name = "btnInfraProfShowImg";
            this.btnInfraProfShowImg.Size = new System.Drawing.Size(100, 25);
            this.btnInfraProfShowImg.TabIndex = 37;
            this.btnInfraProfShowImg.Text = "Show Image";
            this.btnInfraProfShowImg.UseVisualStyleBackColor = true;
            this.btnInfraProfShowImg.Click += new System.EventHandler(this.btnInfraProfShowImg_Click);
            // 
            // btnInfraProfExit
            // 
            this.btnInfraProfExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfExit.Location = new System.Drawing.Point(1044, 20);
            this.btnInfraProfExit.Name = "btnInfraProfExit";
            this.btnInfraProfExit.Size = new System.Drawing.Size(100, 25);
            this.btnInfraProfExit.TabIndex = 35;
            this.btnInfraProfExit.Text = "Exit";
            this.btnInfraProfExit.UseVisualStyleBackColor = true;
            this.btnInfraProfExit.Click += new System.EventHandler(this.btnInfraProfExit_Click);
            // 
            // btnInfraProfUploadImg
            // 
            this.btnInfraProfUploadImg.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfUploadImg.Location = new System.Drawing.Point(338, 20);
            this.btnInfraProfUploadImg.Name = "btnInfraProfUploadImg";
            this.btnInfraProfUploadImg.Size = new System.Drawing.Size(100, 25);
            this.btnInfraProfUploadImg.TabIndex = 31;
            this.btnInfraProfUploadImg.Text = "Upload Image";
            this.btnInfraProfUploadImg.UseVisualStyleBackColor = true;
            this.btnInfraProfUploadImg.Click += new System.EventHandler(this.btnInfraProfUploadImg_Click);
            // 
            // btnInfraProfDelete
            // 
            this.btnInfraProfDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfDelete.Location = new System.Drawing.Point(232, 20);
            this.btnInfraProfDelete.Name = "btnInfraProfDelete";
            this.btnInfraProfDelete.Size = new System.Drawing.Size(100, 25);
            this.btnInfraProfDelete.TabIndex = 28;
            this.btnInfraProfDelete.Text = "Delete";
            this.btnInfraProfDelete.UseVisualStyleBackColor = true;
            this.btnInfraProfDelete.Click += new System.EventHandler(this.btnInfraProfDelete_Click);
            // 
            // btnInfraProfAdd
            // 
            this.btnInfraProfAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfAdd.Location = new System.Drawing.Point(20, 20);
            this.btnInfraProfAdd.Name = "btnInfraProfAdd";
            this.btnInfraProfAdd.Size = new System.Drawing.Size(100, 25);
            this.btnInfraProfAdd.TabIndex = 29;
            this.btnInfraProfAdd.Text = "Add";
            this.btnInfraProfAdd.UseVisualStyleBackColor = true;
            this.btnInfraProfAdd.Click += new System.EventHandler(this.btnInfraProfAdd_Click);
            // 
            // btnInfraProfUpdate
            // 
            this.btnInfraProfUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfraProfUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnInfraProfUpdate.Name = "btnInfraProfUpdate";
            this.btnInfraProfUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnInfraProfUpdate.TabIndex = 27;
            this.btnInfraProfUpdate.Text = "Update";
            this.btnInfraProfUpdate.UseVisualStyleBackColor = true;
            this.btnInfraProfUpdate.Click += new System.EventHandler(this.btnInfraProfUpdate_Click);
            // 
            // splitContainer45
            // 
            this.splitContainer45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer45.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer45.IsSplitterFixed = true;
            this.splitContainer45.Location = new System.Drawing.Point(0, 0);
            this.splitContainer45.Name = "splitContainer45";
            // 
            // splitContainer45.Panel1
            // 
            this.splitContainer45.Panel1.Controls.Add(this.TVInfraProf);
            this.splitContainer45.Panel1.Controls.Add(this.label9);
            // 
            // splitContainer45.Panel2
            // 
            this.splitContainer45.Panel2.Controls.Add(this.splitContainer46);
            this.splitContainer45.Size = new System.Drawing.Size(1168, 397);
            this.splitContainer45.SplitterDistance = 300;
            this.splitContainer45.TabIndex = 0;
            // 
            // TVInfraProf
            // 
            this.TVInfraProf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVInfraProf.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVInfraProf.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVInfraProf.FullRowSelect = true;
            this.TVInfraProf.HideSelection = false;
            this.TVInfraProf.Location = new System.Drawing.Point(0, 25);
            this.TVInfraProf.Name = "TVInfraProf";
            this.TVInfraProf.Size = new System.Drawing.Size(298, 370);
            this.TVInfraProf.TabIndex = 28;
            this.TVInfraProf.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVInfraProf.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVInfraProf_MouseDoubleClick);
            // 
            // splitContainer46
            // 
            this.splitContainer46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer46.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer46.IsSplitterFixed = true;
            this.splitContainer46.Location = new System.Drawing.Point(0, 0);
            this.splitContainer46.Name = "splitContainer46";
            this.splitContainer46.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer46.Panel1
            // 
            this.splitContainer46.Panel1.Controls.Add(this.label75);
            this.splitContainer46.Panel1.Controls.Add(this.label76);
            this.splitContainer46.Panel1.Controls.Add(this.label77);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfEmail);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfcompany);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfDesignation);
            this.splitContainer46.Panel1.Controls.Add(this.label78);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfContact);
            this.splitContainer46.Panel1.Controls.Add(this.label79);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfQualification);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfExperience);
            this.splitContainer46.Panel1.Controls.Add(this.label80);
            this.splitContainer46.Panel1.Controls.Add(this.label81);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfDescription);
            this.splitContainer46.Panel1.Controls.Add(this.label82);
            this.splitContainer46.Panel1.Controls.Add(this.txtInfraProfName);
            this.splitContainer46.Size = new System.Drawing.Size(864, 397);
            this.splitContainer46.SplitterDistance = 275;
            this.splitContainer46.TabIndex = 34;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(22, 66);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(40, 16);
            this.label75.TabIndex = 229;
            this.label75.Text = "Email";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(563, 118);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(62, 16);
            this.label76.TabIndex = 228;
            this.label76.Text = "Company";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(563, 66);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(75, 16);
            this.label77.TabIndex = 227;
            this.label77.Text = "Designation";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInfraProfEmail
            // 
            this.txtInfraProfEmail.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfEmail.Location = new System.Drawing.Point(19, 84);
            this.txtInfraProfEmail.Name = "txtInfraProfEmail";
            this.txtInfraProfEmail.Size = new System.Drawing.Size(260, 22);
            this.txtInfraProfEmail.TabIndex = 226;
            // 
            // txtInfraProfcompany
            // 
            this.txtInfraProfcompany.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfcompany.Location = new System.Drawing.Point(560, 135);
            this.txtInfraProfcompany.Name = "txtInfraProfcompany";
            this.txtInfraProfcompany.Size = new System.Drawing.Size(264, 22);
            this.txtInfraProfcompany.TabIndex = 225;
            // 
            // txtInfraProfDesignation
            // 
            this.txtInfraProfDesignation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfDesignation.Location = new System.Drawing.Point(560, 84);
            this.txtInfraProfDesignation.Name = "txtInfraProfDesignation";
            this.txtInfraProfDesignation.Size = new System.Drawing.Size(264, 22);
            this.txtInfraProfDesignation.TabIndex = 224;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(291, 118);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(101, 16);
            this.label78.TabIndex = 222;
            this.label78.Text = "Contact Number";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInfraProfContact
            // 
            this.txtInfraProfContact.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfContact.Location = new System.Drawing.Point(288, 136);
            this.txtInfraProfContact.Name = "txtInfraProfContact";
            this.txtInfraProfContact.Size = new System.Drawing.Size(265, 22);
            this.txtInfraProfContact.TabIndex = 223;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(291, 66);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(78, 16);
            this.label79.TabIndex = 38;
            this.label79.Text = "Qualification";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInfraProfQualification
            // 
            this.txtInfraProfQualification.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfQualification.Location = new System.Drawing.Point(288, 84);
            this.txtInfraProfQualification.Name = "txtInfraProfQualification";
            this.txtInfraProfQualification.Size = new System.Drawing.Size(265, 22);
            this.txtInfraProfQualification.TabIndex = 39;
            // 
            // txtInfraProfExperience
            // 
            this.txtInfraProfExperience.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfExperience.Location = new System.Drawing.Point(19, 136);
            this.txtInfraProfExperience.Name = "txtInfraProfExperience";
            this.txtInfraProfExperience.Size = new System.Drawing.Size(260, 22);
            this.txtInfraProfExperience.TabIndex = 35;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(22, 169);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(72, 16);
            this.label80.TabIndex = 36;
            this.label80.Text = "Description";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(22, 119);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(72, 16);
            this.label81.TabIndex = 34;
            this.label81.Text = "Experience";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInfraProfDescription
            // 
            this.txtInfraProfDescription.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfDescription.Location = new System.Drawing.Point(19, 187);
            this.txtInfraProfDescription.Multiline = true;
            this.txtInfraProfDescription.Name = "txtInfraProfDescription";
            this.txtInfraProfDescription.Size = new System.Drawing.Size(589, 53);
            this.txtInfraProfDescription.TabIndex = 37;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(22, 15);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(41, 16);
            this.label82.TabIndex = 28;
            this.label82.Text = "Name";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInfraProfName
            // 
            this.txtInfraProfName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInfraProfName.Location = new System.Drawing.Point(19, 33);
            this.txtInfraProfName.Name = "txtInfraProfName";
            this.txtInfraProfName.Size = new System.Drawing.Size(800, 22);
            this.txtInfraProfName.TabIndex = 29;
            // 
            // tabconsultantcompany
            // 
            this.tabconsultantcompany.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabconsultantcompany.Controls.Add(this.splitContainer48);
            this.tabconsultantcompany.Location = new System.Drawing.Point(4, 22);
            this.tabconsultantcompany.Name = "tabconsultantcompany";
            this.tabconsultantcompany.Padding = new System.Windows.Forms.Padding(3);
            this.tabconsultantcompany.Size = new System.Drawing.Size(1176, 469);
            this.tabconsultantcompany.TabIndex = 18;
            this.tabconsultantcompany.Text = "ConsultantCompany";
            this.tabconsultantcompany.UseVisualStyleBackColor = true;
            // 
            // splitContainer48
            // 
            this.splitContainer48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer48.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer48.IsSplitterFixed = true;
            this.splitContainer48.Location = new System.Drawing.Point(3, 3);
            this.splitContainer48.Name = "splitContainer48";
            this.splitContainer48.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer48.Panel1
            // 
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyExit);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyRead);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyWrite);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyMoveDown);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyMoveUp);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyShowLogo);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyAddgrp);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyUploadLogo);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyDelete);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyAdd);
            this.splitContainer48.Panel1.Controls.Add(this.btnConsultantCompanyUpdate);
            // 
            // splitContainer48.Panel2
            // 
            this.splitContainer48.Panel2.Controls.Add(this.splitContainer49);
            this.splitContainer48.Size = new System.Drawing.Size(1168, 461);
            this.splitContainer48.SplitterDistance = 60;
            this.splitContainer48.TabIndex = 2;
            // 
            // btnConsultantCompanyExit
            // 
            this.btnConsultantCompanyExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyExit.Location = new System.Drawing.Point(1044, 20);
            this.btnConsultantCompanyExit.Name = "btnConsultantCompanyExit";
            this.btnConsultantCompanyExit.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyExit.TabIndex = 43;
            this.btnConsultantCompanyExit.Text = "Exit";
            this.btnConsultantCompanyExit.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyExit.Click += new System.EventHandler(this.btnConsultantCompanyExit_Click);
            // 
            // btnConsultantCompanyRead
            // 
            this.btnConsultantCompanyRead.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyRead.Location = new System.Drawing.Point(874, 19);
            this.btnConsultantCompanyRead.Name = "btnConsultantCompanyRead";
            this.btnConsultantCompanyRead.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyRead.TabIndex = 42;
            this.btnConsultantCompanyRead.Text = "Read";
            this.btnConsultantCompanyRead.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyRead.Click += new System.EventHandler(this.btnConsultantCompanyRead_Click);
            // 
            // btnConsultantCompanyWrite
            // 
            this.btnConsultantCompanyWrite.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyWrite.Location = new System.Drawing.Point(768, 20);
            this.btnConsultantCompanyWrite.Name = "btnConsultantCompanyWrite";
            this.btnConsultantCompanyWrite.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyWrite.TabIndex = 41;
            this.btnConsultantCompanyWrite.Text = "Write";
            this.btnConsultantCompanyWrite.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyWrite.Click += new System.EventHandler(this.btnConsultantCompanyWrite_Click);
            // 
            // btnConsultantCompanyMoveDown
            // 
            this.btnConsultantCompanyMoveDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyMoveDown.Location = new System.Drawing.Point(712, 20);
            this.btnConsultantCompanyMoveDown.Name = "btnConsultantCompanyMoveDown";
            this.btnConsultantCompanyMoveDown.Size = new System.Drawing.Size(50, 25);
            this.btnConsultantCompanyMoveDown.TabIndex = 40;
            this.btnConsultantCompanyMoveDown.Text = "\\/";
            this.btnConsultantCompanyMoveDown.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyMoveDown.Click += new System.EventHandler(this.btnConsultantCompanyMoveDown_Click);
            // 
            // btnConsultantCompanyMoveUp
            // 
            this.btnConsultantCompanyMoveUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyMoveUp.Location = new System.Drawing.Point(656, 20);
            this.btnConsultantCompanyMoveUp.Name = "btnConsultantCompanyMoveUp";
            this.btnConsultantCompanyMoveUp.Size = new System.Drawing.Size(50, 25);
            this.btnConsultantCompanyMoveUp.TabIndex = 39;
            this.btnConsultantCompanyMoveUp.Text = "/\\";
            this.btnConsultantCompanyMoveUp.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyMoveUp.Click += new System.EventHandler(this.btnConsultantCompanyMoveUp_Click);
            // 
            // btnConsultantCompanyShowLogo
            // 
            this.btnConsultantCompanyShowLogo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyShowLogo.Location = new System.Drawing.Point(550, 19);
            this.btnConsultantCompanyShowLogo.Name = "btnConsultantCompanyShowLogo";
            this.btnConsultantCompanyShowLogo.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyShowLogo.TabIndex = 37;
            this.btnConsultantCompanyShowLogo.Text = "Show Logo";
            this.btnConsultantCompanyShowLogo.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyShowLogo.Click += new System.EventHandler(this.btnConsultantCompanyShowLogo_Click);
            // 
            // btnConsultantCompanyAddgrp
            // 
            this.btnConsultantCompanyAddgrp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyAddgrp.Location = new System.Drawing.Point(20, 20);
            this.btnConsultantCompanyAddgrp.Name = "btnConsultantCompanyAddgrp";
            this.btnConsultantCompanyAddgrp.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyAddgrp.TabIndex = 36;
            this.btnConsultantCompanyAddgrp.Text = "Add Group";
            this.btnConsultantCompanyAddgrp.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyAddgrp.Click += new System.EventHandler(this.btnConsultantCompanyAddgrp_Click);
            // 
            // btnConsultantCompanyUploadLogo
            // 
            this.btnConsultantCompanyUploadLogo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyUploadLogo.Location = new System.Drawing.Point(444, 19);
            this.btnConsultantCompanyUploadLogo.Name = "btnConsultantCompanyUploadLogo";
            this.btnConsultantCompanyUploadLogo.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyUploadLogo.TabIndex = 31;
            this.btnConsultantCompanyUploadLogo.Text = "Upload Logo";
            this.btnConsultantCompanyUploadLogo.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyUploadLogo.Click += new System.EventHandler(this.btnConsultantCompanyUploadLogo_Click);
            // 
            // btnConsultantCompanyDelete
            // 
            this.btnConsultantCompanyDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyDelete.Location = new System.Drawing.Point(338, 20);
            this.btnConsultantCompanyDelete.Name = "btnConsultantCompanyDelete";
            this.btnConsultantCompanyDelete.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyDelete.TabIndex = 28;
            this.btnConsultantCompanyDelete.Text = "Delete";
            this.btnConsultantCompanyDelete.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyDelete.Click += new System.EventHandler(this.btnConsultantCompanyDelete_Click);
            // 
            // btnConsultantCompanyAdd
            // 
            this.btnConsultantCompanyAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyAdd.Location = new System.Drawing.Point(126, 20);
            this.btnConsultantCompanyAdd.Name = "btnConsultantCompanyAdd";
            this.btnConsultantCompanyAdd.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyAdd.TabIndex = 29;
            this.btnConsultantCompanyAdd.Text = "Add";
            this.btnConsultantCompanyAdd.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyAdd.Click += new System.EventHandler(this.btnConsultantCompanyAdd_Click);
            // 
            // btnConsultantCompanyUpdate
            // 
            this.btnConsultantCompanyUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultantCompanyUpdate.Location = new System.Drawing.Point(232, 20);
            this.btnConsultantCompanyUpdate.Name = "btnConsultantCompanyUpdate";
            this.btnConsultantCompanyUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnConsultantCompanyUpdate.TabIndex = 27;
            this.btnConsultantCompanyUpdate.Text = "Update";
            this.btnConsultantCompanyUpdate.UseVisualStyleBackColor = true;
            this.btnConsultantCompanyUpdate.Click += new System.EventHandler(this.btnConsultantCompanyUpdate_Click);
            // 
            // splitContainer49
            // 
            this.splitContainer49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer49.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer49.IsSplitterFixed = true;
            this.splitContainer49.Location = new System.Drawing.Point(0, 0);
            this.splitContainer49.Name = "splitContainer49";
            // 
            // splitContainer49.Panel1
            // 
            this.splitContainer49.Panel1.Controls.Add(this.TVConsultantCompany);
            this.splitContainer49.Panel1.Controls.Add(this.label10);
            // 
            // splitContainer49.Panel2
            // 
            this.splitContainer49.Panel2.Controls.Add(this.splitContainer50);
            this.splitContainer49.Size = new System.Drawing.Size(1168, 397);
            this.splitContainer49.SplitterDistance = 300;
            this.splitContainer49.TabIndex = 0;
            // 
            // TVConsultantCompany
            // 
            this.TVConsultantCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVConsultantCompany.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVConsultantCompany.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVConsultantCompany.FullRowSelect = true;
            this.TVConsultantCompany.HideSelection = false;
            this.TVConsultantCompany.Location = new System.Drawing.Point(0, 25);
            this.TVConsultantCompany.Name = "TVConsultantCompany";
            this.TVConsultantCompany.Size = new System.Drawing.Size(298, 370);
            this.TVConsultantCompany.TabIndex = 28;
            this.TVConsultantCompany.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVConsultantCompany.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVConsultantCompany_MouseDoubleClick);
            // 
            // splitContainer50
            // 
            this.splitContainer50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer50.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer50.IsSplitterFixed = true;
            this.splitContainer50.Location = new System.Drawing.Point(0, 0);
            this.splitContainer50.Name = "splitContainer50";
            this.splitContainer50.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer50.Panel1
            // 
            this.splitContainer50.Panel1.AutoScroll = true;
            this.splitContainer50.Panel1.Controls.Add(this.label83);
            this.splitContainer50.Panel1.Controls.Add(this.txtConsultantCompanyCity);
            this.splitContainer50.Panel1.Controls.Add(this.checkBox3);
            this.splitContainer50.Panel1.Controls.Add(this.label85);
            this.splitContainer50.Panel1.Controls.Add(this.txtConsultantCompanyshortname);
            this.splitContainer50.Panel1.Controls.Add(this.txtConsultantCompanyDescription);
            this.splitContainer50.Panel1.Controls.Add(this.label86);
            this.splitContainer50.Panel1.Controls.Add(this.label87);
            this.splitContainer50.Panel1.Controls.Add(this.txtConsultantCompanyLink);
            this.splitContainer50.Panel1.Controls.Add(this.label88);
            this.splitContainer50.Panel1.Controls.Add(this.txtConsultantCompanyClientName);
            // 
            // splitContainer50.Panel2
            // 
            this.splitContainer50.Panel2.Controls.Add(this.lblConsultantCompanyCurrMonth);
            this.splitContainer50.Panel2.Controls.Add(this.lblConsultantCompanyPrevMonth);
            this.splitContainer50.Panel2.Controls.Add(this.WebBrowserConsultantCompany);
            this.splitContainer50.Size = new System.Drawing.Size(864, 397);
            this.splitContainer50.SplitterDistance = 275;
            this.splitContainer50.TabIndex = 34;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(291, 119);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(30, 16);
            this.label83.TabIndex = 222;
            this.label83.Text = "City";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtConsultantCompanyCity
            // 
            this.txtConsultantCompanyCity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConsultantCompanyCity.Location = new System.Drawing.Point(288, 137);
            this.txtConsultantCompanyCity.Name = "txtConsultantCompanyCity";
            this.txtConsultantCompanyCity.Size = new System.Drawing.Size(264, 22);
            this.txtConsultantCompanyCity.TabIndex = 223;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(707, 190);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(66, 17);
            this.checkBox3.TabIndex = 221;
            this.checkBox3.Text = "LinkFlag";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(22, 66);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(76, 16);
            this.label85.TabIndex = 38;
            this.label85.Text = "Short Name";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtConsultantCompanyshortname
            // 
            this.txtConsultantCompanyshortname.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConsultantCompanyshortname.Location = new System.Drawing.Point(19, 84);
            this.txtConsultantCompanyshortname.Name = "txtConsultantCompanyshortname";
            this.txtConsultantCompanyshortname.Size = new System.Drawing.Size(264, 22);
            this.txtConsultantCompanyshortname.TabIndex = 39;
            // 
            // txtConsultantCompanyDescription
            // 
            this.txtConsultantCompanyDescription.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConsultantCompanyDescription.Location = new System.Drawing.Point(19, 136);
            this.txtConsultantCompanyDescription.Name = "txtConsultantCompanyDescription";
            this.txtConsultantCompanyDescription.Size = new System.Drawing.Size(264, 22);
            this.txtConsultantCompanyDescription.TabIndex = 35;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(22, 169);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(306, 16);
            this.label86.TabIndex = 36;
            this.label86.Text = "Link Address (double click the link to view the page)";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(22, 119);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(72, 16);
            this.label87.TabIndex = 34;
            this.label87.Text = "Description";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtConsultantCompanyLink
            // 
            this.txtConsultantCompanyLink.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConsultantCompanyLink.Location = new System.Drawing.Point(19, 188);
            this.txtConsultantCompanyLink.Name = "txtConsultantCompanyLink";
            this.txtConsultantCompanyLink.Size = new System.Drawing.Size(680, 22);
            this.txtConsultantCompanyLink.TabIndex = 37;
            this.txtConsultantCompanyLink.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtConsultantCompanyLink_MouseDoubleClick);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(22, 15);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(78, 16);
            this.label88.TabIndex = 28;
            this.label88.Text = "Client Name";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtConsultantCompanyClientName
            // 
            this.txtConsultantCompanyClientName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConsultantCompanyClientName.Location = new System.Drawing.Point(19, 33);
            this.txtConsultantCompanyClientName.Name = "txtConsultantCompanyClientName";
            this.txtConsultantCompanyClientName.Size = new System.Drawing.Size(799, 22);
            this.txtConsultantCompanyClientName.TabIndex = 29;
            // 
            // lblConsultantCompanyCurrMonth
            // 
            this.lblConsultantCompanyCurrMonth.AutoSize = true;
            this.lblConsultantCompanyCurrMonth.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsultantCompanyCurrMonth.Location = new System.Drawing.Point(22, 58);
            this.lblConsultantCompanyCurrMonth.Name = "lblConsultantCompanyCurrMonth";
            this.lblConsultantCompanyCurrMonth.Size = new System.Drawing.Size(127, 16);
            this.lblConsultantCompanyCurrMonth.TabIndex = 229;
            this.lblConsultantCompanyCurrMonth.Text = "Current Month Count";
            this.lblConsultantCompanyCurrMonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblConsultantCompanyPrevMonth
            // 
            this.lblConsultantCompanyPrevMonth.AutoSize = true;
            this.lblConsultantCompanyPrevMonth.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsultantCompanyPrevMonth.Location = new System.Drawing.Point(22, 20);
            this.lblConsultantCompanyPrevMonth.Name = "lblConsultantCompanyPrevMonth";
            this.lblConsultantCompanyPrevMonth.Size = new System.Drawing.Size(134, 16);
            this.lblConsultantCompanyPrevMonth.TabIndex = 228;
            this.lblConsultantCompanyPrevMonth.Text = "Previous Month Count";
            this.lblConsultantCompanyPrevMonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WebBrowserConsultantCompany
            // 
            this.WebBrowserConsultantCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WebBrowserConsultantCompany.Location = new System.Drawing.Point(0, 0);
            this.WebBrowserConsultantCompany.MinimumSize = new System.Drawing.Size(20, 20);
            this.WebBrowserConsultantCompany.Name = "WebBrowserConsultantCompany";
            this.WebBrowserConsultantCompany.Size = new System.Drawing.Size(862, 116);
            this.WebBrowserConsultantCompany.TabIndex = 46;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 25);
            this.label1.TabIndex = 44;
            this.label1.Text = "Companies";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(298, 25);
            this.label6.TabIndex = 45;
            this.label6.Text = "Professionals";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(298, 25);
            this.label7.TabIndex = 46;
            this.label7.Text = "Goverment Portals";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(298, 25);
            this.label9.TabIndex = 47;
            this.label9.Text = "Infra Professionals";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Dock = System.Windows.Forms.DockStyle.Top;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(298, 25);
            this.label10.TabIndex = 48;
            this.label10.Text = "Consultant Companies";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmCompany
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1184, 495);
            this.Controls.Add(this.TC);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCompany";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CQ_Portal";
            this.Load += new System.EventHandler(this.frmCompany_Load);
            this.tabGovtPortal.ResumeLayout(false);
            this.splitContainer34.Panel1.ResumeLayout(false);
            this.splitContainer34.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer34)).EndInit();
            this.splitContainer34.ResumeLayout(false);
            this.splitContainer35.Panel1.ResumeLayout(false);
            this.splitContainer35.Panel2.ResumeLayout(false);
            this.splitContainer35.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer35)).EndInit();
            this.splitContainer35.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabProfessionals.ResumeLayout(false);
            this.splitContainer16.Panel1.ResumeLayout(false);
            this.splitContainer16.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer16)).EndInit();
            this.splitContainer16.ResumeLayout(false);
            this.splitContainer17.Panel1.ResumeLayout(false);
            this.splitContainer17.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer17)).EndInit();
            this.splitContainer17.ResumeLayout(false);
            this.splitContainer18.Panel1.ResumeLayout(false);
            this.splitContainer18.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer18)).EndInit();
            this.splitContainer18.ResumeLayout(false);
            this.splitContainer14.Panel1.ResumeLayout(false);
            this.splitContainer14.Panel1.PerformLayout();
            this.splitContainer14.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).EndInit();
            this.splitContainer14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PbProfessional)).EndInit();
            this.tabCompany.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel1.PerformLayout();
            this.splitContainer11.Panel2.ResumeLayout(false);
            this.splitContainer11.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.TC.ResumeLayout(false);
            this.tabInfraProfessional.ResumeLayout(false);
            this.splitContainer44.Panel1.ResumeLayout(false);
            this.splitContainer44.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer44)).EndInit();
            this.splitContainer44.ResumeLayout(false);
            this.splitContainer45.Panel1.ResumeLayout(false);
            this.splitContainer45.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer45)).EndInit();
            this.splitContainer45.ResumeLayout(false);
            this.splitContainer46.Panel1.ResumeLayout(false);
            this.splitContainer46.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer46)).EndInit();
            this.splitContainer46.ResumeLayout(false);
            this.tabconsultantcompany.ResumeLayout(false);
            this.splitContainer48.Panel1.ResumeLayout(false);
            this.splitContainer48.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer48)).EndInit();
            this.splitContainer48.ResumeLayout(false);
            this.splitContainer49.Panel1.ResumeLayout(false);
            this.splitContainer49.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer49)).EndInit();
            this.splitContainer49.ResumeLayout(false);
            this.splitContainer50.Panel1.ResumeLayout(false);
            this.splitContainer50.Panel1.PerformLayout();
            this.splitContainer50.Panel2.ResumeLayout(false);
            this.splitContainer50.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer50)).EndInit();
            this.splitContainer50.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog mOpenFile;
        private System.Windows.Forms.TabPage tabGovtPortal;
        private System.Windows.Forms.SplitContainer splitContainer34;
        private System.Windows.Forms.Button btnGovPoratlMoveDown;
        private System.Windows.Forms.Button btnGovPoratlMoveUp;
        private System.Windows.Forms.Button btnGovPoratlExit;
        private System.Windows.Forms.Button btnGovPoratlDelete;
        private System.Windows.Forms.Button btnGovPoratlAdd;
        private System.Windows.Forms.Button btnGovPoratlUpdate;
        private System.Windows.Forms.SplitContainer splitContainer35;
        private System.Windows.Forms.TreeView TVGovPoratl;
        private System.Windows.Forms.CheckBox chkGovPoratlLinkFlag;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtGovPoratlLink;
        private System.Windows.Forms.TextBox txtGovPortalName;
        private System.Windows.Forms.TabPage tabProfessionals;
        private System.Windows.Forms.SplitContainer splitContainer16;
        private System.Windows.Forms.Button btnProfMoveDown;
        private System.Windows.Forms.Button btnProfMoveUp;
        private System.Windows.Forms.Button btnProfAddGrp;
        private System.Windows.Forms.Button btnProfShowPhoto;
        private System.Windows.Forms.Button btnProfULPhoto;
        private System.Windows.Forms.Button btnProfDefault;
        private System.Windows.Forms.Button btnProfExit;
        private System.Windows.Forms.Button btnProfDelete;
        private System.Windows.Forms.Button btnProfAdd;
        private System.Windows.Forms.Button btnProfUpdate;
        private System.Windows.Forms.SplitContainer splitContainer17;
        private System.Windows.Forms.TreeView TVProfessional;
        private System.Windows.Forms.SplitContainer splitContainer18;
        private System.Windows.Forms.SplitContainer splitContainer14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtProfDesc;
        private System.Windows.Forms.TextBox txtProfDesignation;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtProfName;
        private System.Windows.Forms.TreeView TVProfCompany;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox PbProfessional;
        private System.Windows.Forms.TabPage tabCompany;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.Button btnCompanyRead;
        private System.Windows.Forms.Button btnCompanyWrite;
        private System.Windows.Forms.Button btnCompanyDown;
        private System.Windows.Forms.Button btnCompanyUp;
        private System.Windows.Forms.Button btnCompanyShowLogo;
        private System.Windows.Forms.Button btnCompanyAddGrp;
        private System.Windows.Forms.Button btnCompanyDefault;
        private System.Windows.Forms.Button btnCompanyUploadLogo;
        private System.Windows.Forms.Button btnCompanyDelete;
        private System.Windows.Forms.Button btnCompanyAdd;
        private System.Windows.Forms.Button btnCompanyUpdate;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.TreeView TVCompany;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtCompanyCity;
        private System.Windows.Forms.CheckBox ckhCompanyFlag;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCompanyOpeningLinkAdd;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCompanyShortName;
        private System.Windows.Forms.TextBox txtCompanyDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCompanyLink;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCompanyName;
        private System.Windows.Forms.TabControl TC;
        private System.Windows.Forms.TabPage tabInfraProfessional;
        private System.Windows.Forms.SplitContainer splitContainer44;
        private System.Windows.Forms.Button btnInfraProfMoveDown;
        private System.Windows.Forms.Button btnInfraProfMoveUp;
        private System.Windows.Forms.Button btnInfraProfShowImg;
        private System.Windows.Forms.Button btnInfraProfExit;
        private System.Windows.Forms.Button btnInfraProfUploadImg;
        private System.Windows.Forms.Button btnInfraProfDelete;
        private System.Windows.Forms.Button btnInfraProfAdd;
        private System.Windows.Forms.Button btnInfraProfUpdate;
        private System.Windows.Forms.SplitContainer splitContainer45;
        private System.Windows.Forms.TreeView TVInfraProf;
        private System.Windows.Forms.SplitContainer splitContainer46;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txtInfraProfEmail;
        private System.Windows.Forms.TextBox txtInfraProfcompany;
        private System.Windows.Forms.TextBox txtInfraProfDesignation;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox txtInfraProfContact;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox txtInfraProfQualification;
        private System.Windows.Forms.TextBox txtInfraProfExperience;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtInfraProfDescription;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txtInfraProfName;
        private System.Windows.Forms.TabPage tabconsultantcompany;
        private System.Windows.Forms.SplitContainer splitContainer48;
        private System.Windows.Forms.Button btnConsultantCompanyRead;
        private System.Windows.Forms.Button btnConsultantCompanyWrite;
        private System.Windows.Forms.Button btnConsultantCompanyMoveDown;
        private System.Windows.Forms.Button btnConsultantCompanyMoveUp;
        private System.Windows.Forms.Button btnConsultantCompanyShowLogo;
        private System.Windows.Forms.Button btnConsultantCompanyAddgrp;
        private System.Windows.Forms.Button btnConsultantCompanyUploadLogo;
        private System.Windows.Forms.Button btnConsultantCompanyDelete;
        private System.Windows.Forms.Button btnConsultantCompanyAdd;
        private System.Windows.Forms.Button btnConsultantCompanyUpdate;
        private System.Windows.Forms.SplitContainer splitContainer49;
        private System.Windows.Forms.TreeView TVConsultantCompany;
        private System.Windows.Forms.SplitContainer splitContainer50;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txtConsultantCompanyCity;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txtConsultantCompanyshortname;
        private System.Windows.Forms.TextBox txtConsultantCompanyDescription;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox txtConsultantCompanyClientName;
        private System.Windows.Forms.TextBox txtConsultantCompanyLink;
        private System.Windows.Forms.Button btnConsultantCompanyExit;
        private System.Windows.Forms.Label lblCompanyCurrMonth;
        private System.Windows.Forms.Label lblCompanyPrevMonth;
        private System.Windows.Forms.WebBrowser webBrowserCompany;
        public System.Windows.Forms.Button btnCompanyExit;
        private System.Windows.Forms.WebBrowser WebBrowserConsultantCompany;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label lblConsultantCompanyCurrMonth;
        private System.Windows.Forms.Label lblConsultantCompanyPrevMonth;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

