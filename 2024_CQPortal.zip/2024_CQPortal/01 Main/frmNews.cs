﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using static System.Windows.Forms.AxHost;

namespace CQPortal
{
    public partial class frmNews : Form
    {
        public DateTime mDate = DateTime.Now;
        public DateTime mShowDate = DateTime.Now;
        string mCaller = "1";

        #region Form
        public frmNews()
        {
            InitializeComponent();
        }
        private void frmNews_Load(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.UseWaitCursor = true;
            try
            {
                DBConn.Open();
                Download(DBConn);
                SuccessFulStoriess.xPopTV(TVSuccessFulStories);
                txtNewsDate.Text = mDate.ToString("dd.MM.yyyy");
                txtReviewDate.Text = mDate.ToString("dd.MM.yyyy");
                txtNewsShowByDate.Text = mShowDate.ToString("dd.MM.yyyy");
                txtTenderDate.Text = mDate.ToString("dd.MM.yyyy");
                txtTenderBiddersDate.Text = mDate.ToString("dd.MM.yyyy");
                
               
                this.Text = "CQ_Portal_" + CQBVar.Version;
                Newss.xPopTV(TVNews);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { this.UseWaitCursor = false; DBConn.Close(); }
        }
        private void Download(SqlConnection DBConn)
        {
            try
            {
                Companys.DownLoad(DBConn);
                Professionalss.DownLoad(DBConn);
                Newss.DownLoad(DBConn);
                Reviews.DownLoad(DBConn);
                Tenders.DownLoad(DBConn);
                Bidders.DownLoad(DBConn);
                SuccessFulStoriess.DownLoad(DBConn);

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { }
        }
        #endregion

        #region Other
        private void TV_DrawNode(object sender, DrawTreeNodeEventArgs e)
        {
            try
            {
                Functions.TVDrawNode(sender, e);
            }
            catch { }
        }
        private void TC_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection dbCQPrjConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TC.SelectedTab == tabNews)
                {
                    txtNewsDate.Text = mDate.ToString("dd.MM.yyyy");
                    Newss.xPopTV(TVNews);
                }
                else if (TC.SelectedTab == tabReview)
                {
                    Reviews.xPopTV(TVReview);
                }
                else if (TC.SelectedTab == tabTender)
                {
                    Tenders.xPopTV(TVTender);
                }
                else if (TC.SelectedTab == tabTenderBidders)
                {
                    Bidders.xPopTV(TVTenderBiddersTender);
                    Companys.xPopTV(TVTenderBiddersCompany);
                }
                else if (TC.SelectedTab == tabSuccessFulStories ) ;
                { 
                    SuccessFulStoriess.xPopTV(TVSuccessFulStories);
                }

            }
            catch { }
            finally { }
        }

        #endregion

        #region News
        private void btnNewsExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {

            }
        }
        private void txtNewsDate_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                mDate = xCalNews.SelectionStart;
                xCalNews.Visible = true;
                mCaller = "1";
            }
            catch { }
        }
        private void xCalNews_DateSelected(object sender, DateRangeEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                xCalNews.Visible = false;
                mDate = xCalNews.SelectionStart;

                string xDate = "";
                if (mCaller == "1")
                {
                    mDate = xCalNews.SelectionStart;
                    txtNewsDate.Text = mDate.ToString("dd.MM.yyyy");
                    xDate = mDate.ToString("yyyyMMdd");
                }
                else if (mCaller == "2")
                {
                    mShowDate = xCalNews.SelectionStart;
                    txtNewsShowByDate.Text = mShowDate.ToString("dd.MM.yyyy");
                    xDate = mShowDate.ToString("yyyyMMdd");
                }
            }
            catch { }
            finally
            {
                this.Cursor = Cursors.Default; DBConn.Close();
            }
        }
        private void btnNewsAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string errorMessage;
                bool isValid = Newss.xValidate(DBConn, TVNews, txtNewsTitle, txtNewsSubTitle, txtNewsSource, txtNewsLinkAddress, mDate.ToString("yyyyMMdd"), chkNewsLinkFlag, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                DBConn.Open();
                Newss.xAdd6(DBConn, TVNews, txtNewsTitle, txtNewsSubTitle, txtNewsSource, txtNewsLinkAddress, mDate.ToString("yyyyMMdd"), chkNewsLinkFlag);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnNewsUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string errorMessage;
                bool isValid = Newss.xValidate(DBConn, TVNews, txtNewsTitle, txtNewsSubTitle, txtNewsSource, txtNewsLinkAddress, mDate.ToString("yyyyMMdd"), chkNewsLinkFlag, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                DBConn.Open();
                if (TVNews.SelectedNode == null || TVNews.SelectedNode.Level == 0) return;
                string xID = TVNews.SelectedNode.Name;
                Newss.xUpdate6(DBConn, TVNews, xID, txtNewsTitle, txtNewsSubTitle, txtNewsSource, txtNewsLinkAddress, mDate.ToString("yyyyMMdd"), chkNewsLinkFlag);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnNewsDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                MessageBox.Show("selected entry will be deleted");
                DBConn.Open();
                if (TVNews.SelectedNode == null || TVNews.SelectedNode.Level == 0) return;
                string xID = TVNews.SelectedNode.Name;
                Newss.xDelete(DBConn, TVNews, xID);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void TVNews_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVNews.SelectedNode == null) return;
                string xID = TVNews.SelectedNode.Name;
                Newss.xPopInRev(xID, txtNewsTitle, txtNewsSubTitle, txtNewsSource, txtNewsLinkAddress, txtNewsDate, chkNewsLinkFlag);
            }
            catch { }
        }
        private void btnNewsDefault_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string xIn1 = "Data Will Be moved , Do You Wish To move";
                string xIn2 = "";
                frmSel_Confirmation frm = new frmSel_Confirmation(xIn1, out xIn2);
                frm.ShowDialog();
                frm.Dispose();
                if (xIn2 != CQBVar.Portal.Sel.Confirmation)
                {
                    MessageBox.Show("InValid Key.");
                    return;
                }
                DBConn.Open();
                Newss.xAddDefault(DBConn);
                Newss.xPopTV(TVNews);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void txtNewsShowByDate_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                mShowDate = xCalNews.SelectionStart;
                xCalNews.Visible = true;
                mCaller = "2";
            }
            catch { }
        }
        private void btnNewsShowByDate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                webBrowserNews.Visible = false;
                NewsDGV.Visible = true;
                DBConn.Open();
                Newss.PopDGV(DBConn, NewsDGV, mShowDate.ToString("yyyyMMdd"));
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void txtNewsLinkAddress_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                NewsDGV.Visible = false;
                if (txtNewsLinkAddress.Text == "") return;
                webBrowserNews.Visible = true;
                webBrowserNews.ScriptErrorsSuppressed = true;
                webBrowserNews.Navigate(txtNewsLinkAddress.Text);
            }
            catch { }
        }
        #endregion

        #region Review
        private void btnReviewExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void btnReviewAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string errorMessage;
                bool isValid = Reviews.xValidate(DBConn, TVReview, mDate.ToString("yyyyMMdd"), txtReviewTitle, txtReviewSubTitle, txtReviewDesc, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                DBConn.Open();
                Reviews.xAdd(DBConn, TVReview, mDate.ToString("yyyyMMdd"), txtReviewTitle, txtReviewSubTitle, txtReviewDesc);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }
        private void btnReviewUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string errorMessage;
                bool isValid = Reviews.xValidate(DBConn, TVReview, mDate.ToString("yyyyMMdd"), txtReviewTitle, txtReviewSubTitle, txtReviewDesc, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                if (TVReview.SelectedNode == null || TVReview.SelectedNode.Level != 2) { MessageBox.Show("Select Review"); return; }
                string xID = TVReview.SelectedNode.Name;
                DBConn.Open();
                Reviews.xUpdate(DBConn, xID, TVReview, mDate.ToString("yyyyMMdd"), txtReviewTitle, txtReviewSubTitle, txtReviewDesc);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnReviewDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                MessageBox.Show("selected entry will be deleted");
                if (TVReview.SelectedNode == null || TVReview.SelectedNode.Level != 2) { MessageBox.Show("Select Review"); return; }
                string xID = TVReview.SelectedNode.Name;
                DBConn.Open();
                Reviews.xDelete(DBConn, xID);
                Reviews.xPopTV(TVReview);
                TVReview.SelectedNode = TVReview.Nodes[xID.Substring(0, 3)].Nodes[xID.Substring(0, 6)];
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void TVReview_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVReview.SelectedNode == null || TVReview.SelectedNode.Level != 2) return;
                string xID = TVReview.SelectedNode.Name;
                DBConn.Open();
                Reviews.xPopInRev(xID, txtReviewDate, txtReviewTitle, txtReviewSubTitle, txtReviewDesc);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void txtReviewDate_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                mDate = CalReview.SelectionStart;
                CalReview.Visible = true;
                mCaller = "1";
            }
            catch { }
        }
        private void CalReview_DateSelected(object sender, DateRangeEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                CalReview.Visible = false;
                mDate = CalReview.SelectionStart;
                string xDate = "";
                if (mCaller == "1")
                {
                    mDate = CalReview.SelectionStart;
                    txtReviewDate.Text = mDate.ToString("dd.MM.yyyy");
                    xDate = mDate.ToString("yyyyMMdd");
                }
            }
            catch { }
            finally
            {
                this.Cursor = Cursors.Default; DBConn.Close();
            }
        }
        private void btnReviewUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVReview.SelectedNode == null || TVReview.SelectedNode.Level != 2) return;
                DBCQConn.Open();
                Reviews.UpOrDown9(DBCQConn, TVReview, true);
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnReviewDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVReview.SelectedNode == null || TVReview.SelectedNode.Level != 2) return;
                DBCQConn.Open();
                Reviews.UpOrDown9(DBCQConn, TVReview, false);
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        #endregion

        #region Tender
        private void btnTenderAddGrp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                Tenders.xAdd3(DBConn, TVTender, mDate.ToString("yyyyMMdd"), txtTenderPrjName, txtTenderDepName, txtTenderPrjCoast, txtTenderDesc);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnTenderAdd_Click(object sender, EventArgs e)
        {
            string connectionString = CQBVar.ConnString.CQ;
            this.Cursor = Cursors.WaitCursor;
            using (SqlConnection DBConn = new SqlConnection(connectionString))
            {
                try
                {
                    string errorMessage;

                    bool isValid = Tenders.xValidate(DBConn, TVTender, mDate.ToString("yyyyMMdd"), txtTenderPrjName, txtTenderDepName, txtTenderPrjCoast, txtTenderDesc, out errorMessage);
                    if (!isValid)
                    {
                        MessageBox.Show(errorMessage);
                        return;
                    }

                    DBConn.Open();

                    if (TVTender.SelectedNode == null)
                    {
                        MessageBox.Show("Please select a node.");
                        return;
                    }

                    if (TVTender.SelectedNode.Level == 0)
                    {
                        Tenders.xAdd6(DBConn, TVTender, mDate.ToString("yyyyMMdd"), txtTenderPrjName, txtTenderDepName, txtTenderPrjCoast, txtTenderDesc);
                    }
                    else
                    {
                        Tenders.xAdd9(DBConn, TVTender, mDate.ToString("yyyyMMdd"), txtTenderPrjName, txtTenderDepName, txtTenderPrjCoast, txtTenderDesc);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
                finally
                {
                    this.Cursor = Cursors.Default;
                }
            }
        }
        private void CalTender_DateSelected(object sender, DateRangeEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                CalTender.Visible = false;
                mDate = CalTender.SelectionStart;

                string xDate = "";
                if (mCaller == "1")
                {
                    mDate = CalTender.SelectionStart;
                    txtTenderDate.Text = mDate.ToString("dd.MM.yyyy");
                    xDate = mDate.ToString("yyyyMMdd");
                }
            }
            catch { }
            finally
            {
                this.Cursor = Cursors.Default; DBConn.Close();
            }
        }
        private void txtTenderDate_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                mDate = CalTender.SelectionStart;
                CalTender.Visible = true;
                mCaller = "1";
            }
            catch { }
        }
        private void btnTenderUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string errorMessage;
                bool isValid = Tenders.xValidate(DBConn, TVTender, mDate.ToString("yyyyMMdd"), txtTenderPrjName, txtTenderDepName, txtTenderPrjCoast, txtTenderDesc, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                if (TVTender.SelectedNode == null) return;
                string xID = TVTender.SelectedNode.Name;
                DBConn.Open();
                Tenders.xUpdate(DBConn, xID, TVTender, mDate.ToString("yyyyMMdd"), txtTenderPrjName, txtTenderDepName, txtTenderPrjCoast, txtTenderDesc);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnTenderDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVTender.SelectedNode == null) return;
                string xID = TVTender.SelectedNode.Name;
                DBConn.Open();
                Tenders.xDelete(DBConn, TVTender, xID);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        async private void btnTenderULImage1_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVTender.SelectedNode == null) return;
                string xID = TVTender.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoadImageWithNAme("Tender", xID + "_Image1", xFileName);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnTenderDefault_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (MessageBox.Show("All data will be deleted. Do you wish to delete", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                DBConn.Open();
                Tenders.xAddDefault(DBConn);
                Tenders.xPopTV(TVTender);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void btnTenderExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void btnTenderShowImage1_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVTender.SelectedNode == null) return;
                string xImage = TVTender.SelectedNode.Name + "_Image1";
                if (xImage.ToLower().EndsWith(".JPEG")) xImage = xImage.Substring(0, xImage.Length - 5);

                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/Tender/" + xImage;
                UpDLLoadImage.DownloadImage(xImage, MyURL);
            }
            catch
            {

            }
        }
        async private void btnTenderULImage2_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVTender.SelectedNode == null) return;
                string xID = TVTender.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoadImageWithNAme("Tender", xID + "_Image2", xFileName);

            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnTenderShowImage2_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVTender.SelectedNode == null) return;
                string xImage = TVTender.SelectedNode.Name + "_Image2";
                if (xImage.ToLower().EndsWith(".JPEG")) xImage = xImage.Substring(0, xImage.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/Tender/" + xImage;
                UpDLLoadImage.DownloadImage(xImage, MyURL);
            }
            catch
            {
            }
        }
        private void TVTender_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVTender.SelectedNode == null) return;

                string xID = TVTender.SelectedNode.Name;
                Tenders.xPopInRev(xID, txtTenderDate, txtTenderPrjName, txtTenderDepName, txtTenderPrjCoast, txtTenderDesc);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; }
        }
        #endregion

        #region Bidder List
        private void TxtTenderBidderDate_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                mDate = CalTenderBidders.SelectionStart;
                CalTenderBidders.Visible = true;
                mCaller = "1";
            }
            catch { }
        }
        private void CalTenderBindder_DateSelected(object sender, DateRangeEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                CalTenderBidders.Visible = false;
                mDate = CalTenderBidders.SelectionStart;

                string xDate = "";
                if (mCaller == "1")
                {
                    mDate = CalTenderBidders.SelectionStart;
                    txtTenderBiddersDate.Text = mDate.ToString("dd.MM.yyyy");
                    xDate = mDate.ToString("yyyyMMdd");
                }

            }
            catch { }
            finally
            {
                this.Cursor = Cursors.Default; DBConn.Close();
            }
        }
        private void btnTenderBiddersAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVTenderBiddersTender.SelectedNode == null || TVTenderBiddersTender.SelectedNode.Level < 2) return;
                if (TVTenderBiddersCompany.SelectedNode == null || TVTenderBiddersCompany.SelectedNode.Level != 1) return;
                string xCompanyID = TVTenderBiddersCompany.SelectedNode.Name;
                Bidders.xAdd(DBConn, TVTenderBiddersTender, xCompanyID, mDate.ToString("yyyyMMdd"), txtTenderBiddersBidValue, txtTenderBiddersPerVari);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnTenderBiddersUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVTenderBiddersTender.SelectedNode == null || TVTenderBiddersTender.SelectedNode.Level != 3) return;
                if (TVTenderBiddersCompany.SelectedNode == null || TVTenderBiddersCompany.SelectedNode.Level != 1) return;
                string xID = TVTenderBiddersTender.SelectedNode.Name;
                string xCompanyID = TVTenderBiddersCompany.SelectedNode.Name;
                Bidders.xUpdate(DBConn, xID, TVTenderBiddersTender, xCompanyID, mDate.ToString("yyyyMMdd"), txtTenderBiddersBidValue, txtTenderBiddersPerVari);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }

        }
        private void btnTenderBiddersDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVTenderBiddersTender.SelectedNode == null || TVTenderBiddersTender.SelectedNode.Level != 3) return;
                if (TVTenderBiddersCompany.SelectedNode == null || TVTenderBiddersCompany.SelectedNode.Level != 1) return;
                string xID = TVTenderBiddersTender.SelectedNode.Name;
                string xCompanyID = TVTenderBiddersCompany.SelectedNode.Name;
                Bidders.xDelete(DBConn, TVTenderBiddersTender, xID);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void TVTenderBiddersTender_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVTenderBiddersTender.SelectedNode == null || TVTenderBiddersTender.SelectedNode.Level != 3) return;
                string xID = TVTenderBiddersTender.SelectedNode.Name;
                Bidders.xPopInRev(xID, TVTenderBiddersCompany, txtTenderBiddersDate, txtTenderBiddersBidValue, txtTenderBiddersPerVari);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnTenderBiddersDefault_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string xIn1 = "Data Will Be moved , Do You Wish To move";
                string xIn2 = "";
                frmSel_Confirmation frm = new frmSel_Confirmation(xIn1, out xIn2);
                frm.ShowDialog();
                frm.Dispose();
                if (xIn2 != CQBVar.Portal.Sel.Confirmation)
                {
                    MessageBox.Show("InValid Key.");
                    return;
                }
                DBConn.Open();
                Bidders.xAddDefault(DBConn);
                Bidders.xPopTV(TVTenderBiddersTender);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void btnTenderBiddersExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        #endregion

        #region SuccessFullStories

        private void btnSuccessFulStoriesAddGrp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                SuccessFulStoriess.xAdd3(DBConn, TVSuccessFulStories, txtSuccessFulStoriesTiltle, txtSuccessFulStoriesSubTitle);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }

        private void btnSuccessFulStoriesAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                SuccessFulStoriess.xAdd6(DBConn, TVSuccessFulStories, txtSuccessFulStoriesTiltle, txtSuccessFulStoriesSubTitle, txtSuccessFulStoriesDesc, txtSuccessFulStoriesCompanyName);

            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }

        private void btnSuccessFulStoriesUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVSuccessFulStories.SelectedNode == null) return;
                if (TVSuccessFulStories.SelectedNode.Level == 0)
                {
                    string xID = TVSuccessFulStories.SelectedNode.Name;
                    SuccessFulStoriess.xUpdate3(DBConn, TVSuccessFulStories, xID, txtSuccessFulStoriesTiltle, txtSuccessFulStoriesSubTitle);
                }
                else
                {
                    if (TVSuccessFulStories.SelectedNode == null) return;
                    string xID = TVSuccessFulStories.SelectedNode.Name;
                    SuccessFulStoriess.xUpdate6(DBConn, TVSuccessFulStories, xID, txtSuccessFulStoriesTiltle, txtSuccessFulStoriesSubTitle, txtSuccessFulStoriesDesc, txtSuccessFulStoriesCompanyName);
                }
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }

        private void btnSuccessFulStoriesDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                MessageBox.Show("selected entry will be deleted");
                DBConn.Open();
                if (TVSuccessFulStories.SelectedNode == null) return;
                string xID = TVSuccessFulStories.SelectedNode.Name;
                SuccessFulStoriess.xDelete(DBConn, TVSuccessFulStories, xID);

            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }

        async private void btnSuccessFulStoriesUploadLogo_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVSuccessFulStories.SelectedNode == null || TVSuccessFulStories.SelectedNode.Level == 0) return;
                string xID = TVSuccessFulStories.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("CompanyLogo", xFileName);
                DBConn.Open();
                SuccessFulStoriess.xUpdateLogo(DBConn, xID, Path.GetFileNameWithoutExtension(xFileName));
                SuccessFulStoriess.xPopInRev(xID, txtSuccessFulStoriesTiltle, txtSuccessFulStoriesSubTitle, txtSuccessFulStoriesDesc, txtSuccessFulStoriesCompanyName);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }

       async private void btnSuccessFulStoriesUploadImage_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVSuccessFulStories.SelectedNode == null || TVSuccessFulStories.SelectedNode.Level == 0) return;
                string xID = TVSuccessFulStories.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("StoriesPhoto", xFileName);
                DBConn.Open();
                SuccessFulStoriess.xUpdatePhoto(DBConn, xID, Path.GetFileNameWithoutExtension(xFileName));
                SuccessFulStoriess.xPopInRev(xID, txtSuccessFulStoriesTiltle, txtSuccessFulStoriesSubTitle, txtSuccessFulStoriesDesc, txtSuccessFulStoriesCompanyName);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }

        }

        private void btnSuccessFulStoriesShowLogo_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVSuccessFulStories.SelectedNode == null || TVSuccessFulStories.SelectedNode.Level == 0) return;
                string xID = TVSuccessFulStories.SelectedNode.Name;
                SuccessFulStories xT = SuccessFulStoriess.xGetByID(xID);
                string xLogo = xT.xLogoName;
                if (xLogo.ToLower().EndsWith(".JPEG")) xLogo = xLogo.Substring(0, xLogo.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/CompanyLogo/" + xLogo;
                UpDLLoadImage.DownloadImage(xLogo, MyURL);
            }
            catch
            {
            }
        }

        private void btnSuccessFulStoriesShowImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVSuccessFulStories.SelectedNode == null || TVSuccessFulStories.SelectedNode.Level == 0) return;
                string xID = TVSuccessFulStories.SelectedNode.Name;
                SuccessFulStories xT = SuccessFulStoriess.xGetByID(xID);
                string xPhoto = xT.xPhotoName;
                if (xPhoto.ToLower().EndsWith(".JPEG")) xPhoto = xPhoto.Substring(0, xPhoto.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/StoriesPhoto/" + xPhoto;
                UpDLLoadImage.DownloadImage(xPhoto, MyURL);
            }
            catch
            {
            }

        }

        private void btnSuccessFulStoriesUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVSuccessFulStories.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVSuccessFulStories.SelectedNode.Level == 0)
                {
                    SuccessFulStoriess.UpOrDown3(DBCQConn, TVSuccessFulStories, true);
                }
                else if (TVSuccessFulStories.SelectedNode.Level == 1)
                {
                    SuccessFulStoriess.UpOrDown6(DBCQConn, TVSuccessFulStories, true);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }

        private void btnSuccessFulStoriesDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVSuccessFulStories.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVSuccessFulStories.SelectedNode.Level == 0)
                {
                    SuccessFulStoriess.UpOrDown3(DBCQConn, TVSuccessFulStories, false);
                }
                else if (TVSuccessFulStories.SelectedNode.Level == 1)
                {
                    SuccessFulStoriess.UpOrDown6(DBCQConn, TVSuccessFulStories, false);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }

        private void TVSuccessFulStories_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVSuccessFulStories.SelectedNode == null) return;
                string xID = TVSuccessFulStories.SelectedNode.Name;
                SuccessFulStoriess.xPopInRev(xID, txtSuccessFulStoriesTiltle, txtSuccessFulStoriesSubTitle, txtSuccessFulStoriesDesc, txtSuccessFulStoriesCompanyName);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnSuccessFulStoriesExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
    }
}


#endregion
