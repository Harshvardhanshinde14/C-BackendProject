﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace CQPortal
{
    public   partial class frmSel_Confirmation : Form
    {
        string mIn1 = "";
        string mIn2 = "";
        public frmSel_Confirmation()
        {
            InitializeComponent();
        }
        public static string xCreateIn()
        {
            try
            {
                string xStrRet = "";
                Application.DoEvents();
                System.Threading.Thread.Sleep(1);
                Random xRmd = new Random(Convert.ToInt32(DateTime.Now.ToString("ffff")));
                do
                {
                    Int32 n = xRmd.Next(1, 9);
                    xStrRet = xStrRet + n.ToString();

                } while (xStrRet.Length < 4);
                return xStrRet;
            }
            catch { return ""; }
        }
        public frmSel_Confirmation(string xIn1, out string xIn2)
        {
            InitializeComponent();
            mIn1 = xIn1;
            xIn2 = xCreateIn();
            mIn2 = xIn2;
            CQBVar.Portal.Sel.Confirmation = "";
        }
        public frmSel_Confirmation(string xIn1,string xPreSetKey, out string xIn2) // xIN2 will returm xpresetkey
        {

            InitializeComponent();
            mIn1 = xIn1;
            xIn2 = xPreSetKey;
            mIn2 = xIn2;
            CQBVar.Portal.Sel.Confirmation = "";

        }
        private void frmPTMSel_Confirmation_Load(object sender, EventArgs e)
        {
            lblIn1.Text = mIn1;
            lblIn2.Text = mIn2;

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                CQBVar.Portal.Sel.Confirmation  = txtOut.Text;
                this.Close();
            }
            catch { }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
