﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using static System.Windows.Forms.AxHost;

namespace CQPortal
{

    public partial class frmContactUs : Form
    {
        public DateTime mDate = DateTime.Now;
        public DateTime mShowDate = DateTime.Now;
        string mCaller = "1";

        List<double> mLstHighliteRows = new List<double>();
        private Point mStartingPoint = Point.Empty;
        private Point mCompanyMovingPoint = Point.Empty;
        private bool mCompanyPanning = false;
        private Point mProfStartingPoint = Point.Empty;
        private Point mProfMovingPoint = Point.Empty;
        private bool mProfPanning = false;

        //string xGetQuot="1"
        //string xContactUs="0"
        public frmContactUs()
        {
            InitializeComponent();
        }

        #region Form
        private void frmContactUs_Load(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                Download(DBConn);
                this.Text = "CQ_Portal_" + CQBVar.Version;
                btnContactUsShow_Click(sender, e);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void Download(SqlConnection DBConn)
        {
           
            try
            {
                ContactUss.DownLoad(DBConn);
            }
            catch { }
            finally { }
        }
        #endregion

        #region Other
        private void TV_DrawNode(object sender, DrawTreeNodeEventArgs e)
        {
            try
            {
                Functions.TVDrawNode(sender, e);
            }
            catch { }
        }
        #endregion

        #region Conttact
        private void btnContactExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void TVContact_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVContact.SelectedNode == null) return;
                string xID = TVContact.SelectedNode.Name;
                DBConn.Open();
                ContactUss.xPopInRev(xID, txtContactName, txtContactCompany, txtContactCity, txtContactEmail, txtContactPhno, txtContactSubject, txtContactMessage);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnContactUsShow_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                ContactUss.xPopTV(DBConn, TVContact, "0");
                lblTVTitle.Text = "ContactUS";
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void btnGetQuot_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                ContactUss.xPopTV(DBConn, TVContact, "1");
                lblTVTitle.Text = "Get Quotation";
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        #endregion


    }
}





