﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CQPortal
{
    public static class Reviews
    {
        public static List<Review> mLst = new List<Review>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<Review> xLst)
        {
            //xID,xProfessionalID,xDate,xTitle,xSubTitle,xDescription
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xProfessionalID + "','" + xLst[n].xDate + "','" + xLst[n].xTitle + "','" + xLst[n].xSubTitle + "','" + xLst[n].xDescription + "'," + xLst[n].xSeqNo + ",'" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_Review (xID,xProfessionalID,xDate,xTitle,xSubTitle,xDescription,xSeqNo,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Review");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Review WHERE xID = '" + xID + "' ") == false) return;
                Review xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<Review> { xT });
            }
            catch { }
        }
        public static List<Review> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<Review> xRetLst = new List<Review>();
                while (oReader.Read())
                {
                    //xID,xProfessionalID,xDate,xTitle,xSubTitle,xDescription
                    Review xT = new Review();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xProfessionalID = oReader["xProfessionalID"].ToString().Trim();
                    xT.xDate = oReader["xDate"].ToString().Trim();
                    xT.xTitle = oReader["xTitle"].ToString().Trim();
                    xT.xSubTitle = oReader["xSubTitle"].ToString().Trim();
                    xT.xDescription = oReader["xDescription"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<Review>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<Review>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_Review";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Review WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
       
        #endregion

        #region Get
        private static string xGetNewID9(string xReviewerID)
        {
            try
            {
                List<Review> xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xReviewerID).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return xReviewerID + "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo9(string xID6)
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<Review> xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xID6).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static Review xGetByID(string xID)
        {
            try
            {
                Review xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new Review();
                return xT;
            }
            catch { return new Review(); }
        }
       
      
        #endregion

        #region Add Update
        public static void xAdd(SqlConnection DBConn, TreeView TV, string xDate, TextBox txtTitle,TextBox txtSubTitle,TextBox txtDesc)
        {
            try
            {
                //xID,xProfessionalID,xDate,xTitle,xSubTitle,xDescription
                if (TV.SelectedNode == null || TV.SelectedNode.Level == 0) return;
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Title");
                    return;
                }
                string xPID = TV.SelectedNode.Name;
                if(TV.SelectedNode.Level==2)xPID = TV.SelectedNode.Parent.Name;
                Review xT = new Review();
                xT.xProfessionalID = xPID;
                xT.xID = xGetNewID9(xPID);
                xT.xSeqNo = xGetNewSeqNo9(xPID);
                xT.xDate = xDate    ;
                xT.xTitle = txtTitle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xDescription = txtDesc.Text.Trim();
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID.Substring(0,6)].Nodes[xT.xID];
            }
            catch { }
        }

        public static bool xValidate(SqlConnection DBConn, TreeView TV, string xDate, TextBox txtTitle, TextBox txtSubTitle, TextBox txtDesc,
        out string ErrorMessage)
        {
            ErrorMessage = string.Empty;
            bool isValid = true;
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                ErrorMessage += "Title is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtSubTitle.Text))
            {
                ErrorMessage += "SubTitle is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtDesc.Text))
            {
                ErrorMessage += "Description is required.\n";
                isValid = false;
            }
            return isValid;
        }
        public static void xUpdate(SqlConnection DBConn, string xID, TreeView TV, string xDate, TextBox txtTitle, TextBox txtSubTitle, TextBox txtDesc)
        {
            try
            {
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                    {
                        MessageBox.Show("Invalid Title");
                        return;
                    }
                Review xT = xGetByID(xID);
                if (xT == null) { return; }
                string xPID = xID.Substring(0, 6);
                xT.xProfessionalID = xPID;
                xT.xDate = xDate;
                xT.xTitle = txtTitle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xDescription = txtDesc.Text.Trim();
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID.Substring(0, 6)].Nodes[xT.xID];
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<Professionals> xLst3 = Professionalss.xGetList().FindAll(p => p.xID.Length == 3).OrderBy(p=>p.xSeqNo).ToList();
                for (int i = 0; i < xLst3.Count; i++)
                {
                    TreeNode xNode3 = TV.Nodes.Add(xLst3[i].xID, xLst3[i].xName);
                    List<Professionals> xLst6 = Professionalss.xGetList().FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xLst3[i].xID).OrderBy(p => p.xSeqNo).ToList(); ;

                    for (int j = 0; j < xLst6.Count; j++)
                    {
                        TreeNode xNode6 = xNode3.Nodes.Add(xLst6[j].xID, xLst6[j].xName);

                        List<Review> xLst9 = mLst.FindAll(p => p.xID.Substring(0, 6) == xLst6[j].xID).OrderBy(p => p.xSeqNo).ToList();
                        for (int k = 0; k < xLst9.Count; k++)
                        {
                            xNode6.Nodes.Add(xLst9[k].xID, xLst9[k].xTitle);
                        }
                    }
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }

        public static void xPopInRev(string xID,TextBox txtDate, TextBox txtTitle, TextBox txtSubTitle, TextBox txtdesc)
        {
            try
            {
                Review xT = xGetByID(xID); 
                txtDate.Text =Functions.DBToDotDate(xT.xDate);
                txtTitle.Text = xT.xTitle;
                txtSubTitle.Text = xT.xSubTitle;
                txtdesc.Text = xT.xDescription;
                txtDate.Text = Functions.DBToDotDate(xT.xDate);
            }
            catch { }
        }
        #endregion
        #region MoveupDown
     
        public static void UpOrDown9(SqlConnection DBConn, TreeView TV, bool MoveUp) //xSeqNo
        {
            try
            {
                if (TV.SelectedNode == null) return;
                string xID = TV.SelectedNode.Name;
                List<Review> xLst = new List<Review>();
                if (xID.Length != 9) return;
                xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xID.Substring(0, 6)).OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID);
            }
            catch { }
        }
        #endregion
    }
}

