﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Globalization;
using static System.Windows.Forms.AxHost;
using CQPortal;
using System.Security.Cryptography;


namespace CQPortal
{
    public static class TrainingPrograms
    {
        public static List<TrainingProgram> mLst = new List<TrainingProgram>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<TrainingProgram> xLst)
        {
           // xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
         try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xTitle + "','" + xLst[n].xShortDesc + "','" + xLst[n].xStartDate + "','" + xLst[n].xDesc + "','" + xLst[n].xDuration + "','" + xLst[n].xLocation + "','" + xLst[n].xTimings + "','" + xLst[n].xContactNo + "','" + xLst[n].xCity + "','" + xLst[n].xSeqNo + "','" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_TrainingProgram (xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_TrainingProgram");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_TrainingProgram WHERE xID = '" + xID + "' ") == false) return;
                TrainingProgram xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<TrainingProgram> { xT });
            }
            catch { }
        }
        public static List<TrainingProgram> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<TrainingProgram> xRetLst = new List<TrainingProgram>();
                while (oReader.Read())
                {
                    //xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
                    TrainingProgram xT = new TrainingProgram();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xTitle = oReader["xTitle"].ToString().Trim();
                    xT.xShortDesc = oReader["xShortDesc"].ToString().Trim();
                    xT.xStartDate = oReader["xStartDate"].ToString().Trim();
                    xT.xDesc = oReader["xDesc"].ToString().Trim(); ;
                    xT.xDuration = oReader["xDuration"].ToString().Trim();
                    xT.xLocation = oReader["xLocation"].ToString().Trim();
                    xT.xTimings = oReader["xTimings"].ToString().Trim();
                    xT.xContactNo = oReader["xContactNo"].ToString().Trim();
                    xT.xCity = oReader["xCity"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xT.xDateTimeStamp = oReader["xDateTimeStamp"].ToString().Trim();
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<TrainingProgram>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<TrainingProgram>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_TrainingProgram";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_TrainingProgram WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                TrainingPrograms.xPopTV(TV);
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID()
        {
            try
            {
                List<TrainingProgram> xLst = mLst.FindAll(p => p.xID.Length == 6).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<TrainingProgram> xLst = mLst.OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static TrainingProgram xGetByID(string xID)
        {
            try
            {
                TrainingProgram xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new TrainingProgram();
                return xT;
            }
            catch { return new TrainingProgram(); }
        }
        #endregion

        #region Add Update        
        //xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
        public static void xAdd(SqlConnection DBConn, TreeView TV, TextBox txtTitle, TextBox txtShortDesc, string xStartDate, TextBox txtDesc, TextBox txtDuration, TextBox txtLocation, TextBox txtTimings, TextBox txtContactNo, TextBox txtCity)
        {
            try
            {
                //xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
                TrainingProgram xT = new TrainingProgram();
                xT.xID = xGetNewID();
                xT.xSeqNo = xGetNewSeqNo();
                xT.xTitle = txtTitle.Text.Trim();
                xT.xShortDesc = txtShortDesc.Text.Trim();
                xT.xStartDate = xStartDate;
                xT.xDesc = txtDesc.Text.Trim();
                xT.xDuration = txtDuration.Text.Trim();
                xT.xLocation = txtLocation.Text.Trim();
                xT.xTimings = txtTimings.Text.Trim();
                xT.xContactNo = txtContactNo.Text.Trim();
                xT.xCity = txtCity.Text.Trim();
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static bool xValidate(SqlConnection DBConn, TreeView TV, TextBox txtTitle, TextBox txtShortDesc, string xStartDate, TextBox txtDesc, TextBox txtDuration, TextBox txtLocation, TextBox txtTimings, TextBox txtContactNo, TextBox txtCity, out string ErrorMessage)
        {
            ErrorMessage = string.Empty;
            try
            {
                bool isValid = true;
                if (string.IsNullOrWhiteSpace(txtTitle.Text))
                {
                    ErrorMessage += "Name is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtShortDesc.Text))
                {
                    ErrorMessage += "ShortDesc is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtDesc.Text))
                {
                    ErrorMessage += "Description is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtDuration.Text))
                {
                    ErrorMessage += "Duration is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtLocation.Text))
                {
                    ErrorMessage += "Location is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtTimings.Text))
                {
                    ErrorMessage += "Timing is required.\n";
                    isValid = false;
                }

                if (string.IsNullOrWhiteSpace(txtCity.Text))
                {
                    ErrorMessage += "City is required.\n";
                    isValid = false;
                }
                // Validate contact number length and numeric content
                if (!IsNumeric(txtContactNo.Text) || txtContactNo.Text.Length != 10)
                {
                    ErrorMessage += "Contact number must be exactly 10 numeric digits.\n";
                    isValid = false;
                }

                // Additional validations can be added here (e.g., date format, numeric fields, etc.)

                return isValid;
            }
            catch { return  false; }
        }
        private static bool IsNumeric(string value)
        {
            try
            {
                return value.All(char.IsDigit);
            }
            catch { return false; }
        }
        public static void xUpdate(SqlConnection DBConn, TreeView TV, string xID, TextBox txtTitle, TextBox txtShortDesc, string xStartDate,TextBox txtDesc, TextBox txtDuration, TextBox txtLocation, TextBox txtTimings , TextBox txtContactNo, TextBox txtCity)
        {
            try
            {//xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
                TrainingProgram xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xTitle = txtTitle.Text.Trim();
                xT.xShortDesc = txtShortDesc.Text.Trim();
                xT.xStartDate = xStartDate;
                xT.xDesc = txtDesc.Text.Trim();
                xT.xDuration = txtDuration.Text.Trim();
                xT.xLocation = txtLocation.Text.Trim();
                xT.xTimings = txtTimings.Text.Trim();
                xT.xContactNo = txtContactNo.Text.Trim();
                xT.xCity = txtCity.Text.Trim();
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<TrainingProgram> xLst = mLst.OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst.Count; i++)
                {
                    TV.Nodes.Add(xLst[i].xID, xLst[i].xShortDesc);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID, TextBox txtTitle, TextBox txtShortDesc, TextBox txtDate, TextBox txtDesc, TextBox txtDuration, TextBox txtLocation, TextBox txtTimings, TextBox txtContactNo, TextBox txtCity)
        {
            try
            {//xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
                TrainingProgram xT = xGetByID(xID);
                txtTitle.Text = xT.xTitle;
                txtShortDesc.Text = xT.xShortDesc;
                txtDate.Text = xT.xStartDate;
                txtDesc.Text = xT.xDesc;
                txtDuration.Text = xT.xDuration;
                txtLocation.Text = xT.xLocation;
                txtTimings.Text = xT.xTimings;
                txtContactNo.Text = xT.xContactNo;
                txtCity.Text = xT.xCity;
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown(SqlConnection DBConn, TreeView TV, bool MoveUp)
        {
            try
            {
                if (TV.SelectedNode == null) return;
                string xID = TV.SelectedNode.Name;
                List<TrainingProgram> xLst = new List<TrainingProgram>();
                xLst = mLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xID];
            }
            catch { }
        }
        #endregion
    }
}
