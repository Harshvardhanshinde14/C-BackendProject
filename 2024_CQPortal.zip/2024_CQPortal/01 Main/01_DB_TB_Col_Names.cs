﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CQPortal
{
    public partial class TBStrs
    {
        private static List<TBSchema> mLst_Schema_Prj = new List<TBSchema>();
        public static List<TBSchema> GetTBStr_Schema(SqlConnection dbConn)
        {
            List<TBSchema> xLstSQLDB = new List<TBSchema>();
            string xSQL = @"SELECT * FROM " + dbConn.Database + ".INFORMATION_SCHEMA.COLUMNS";
            SqlCommand xCmd = new SqlCommand(xSQL, dbConn);
            xCmd.CommandType = CommandType.Text;
            using (SqlDataReader oReader = xCmd.ExecuteReader())
            {
                while (oReader.Read())
                {
                    TBSchema xNew = new TBSchema();
                    xNew.TABLE_CATALOG = oReader["TABLE_CATALOG"].ToString();
                    xNew.TABLE_SCHEMA = oReader["TABLE_SCHEMA"].ToString();
                    xNew.TABLE_NAME = oReader["TABLE_NAME"].ToString();
                    xNew.COLUMN_NAME = oReader["COLUMN_NAME"].ToString();
                    xNew.ORDINAL_POSITION = oReader["ORDINAL_POSITION"].ToString();
                    xNew.COLUMN_DEFAULT = oReader["COLUMN_DEFAULT"].ToString();
                    xNew.IS_NULLABLE = oReader["IS_NULLABLE"].ToString();
                    xNew.DATA_TYPE = oReader["DATA_TYPE"].ToString();
                    xNew.CHARACTER_MAXIMUM_LENGTH = oReader["CHARACTER_MAXIMUM_LENGTH"].ToString();
                    xNew.CHARACTER_OCTET_LENGTH = oReader["CHARACTER_OCTET_LENGTH"].ToString();
                    xNew.NUMERIC_PRECISION = oReader["NUMERIC_PRECISION"].ToString();
                    xNew.NUMERIC_PRECISION_RADIX = oReader["NUMERIC_PRECISION_RADIX"].ToString();
                    xNew.NUMERIC_SCALE = oReader["NUMERIC_SCALE"].ToString();
                    xNew.DATETIME_PRECISION = oReader["DATETIME_PRECISION"].ToString();
                    xNew.DOMAIN_NAME = oReader["DOMAIN_NAME"].ToString();
                    xLstSQLDB.Add(xNew);
                }
            }
            return xLstSQLDB.OrderBy(p => p.TABLE_NAME).ToList();
        }
        public static void CheckAndCreateTables_Prj(SqlConnection dbConn)
        {
            try
            {
                mLst_Schema_Prj = GetTBStr_Schema(dbConn);
                List<string> xTBNames = TBStrs.GetTables_Prj().Select(p => p.xV2).ToList(); ;
                for (int i = 0; i < xTBNames.Count; i++)
                {
                    if (CheckTableExists(xTBNames[i], mLst_Schema_Prj) == false)
                    {
                        CreateTable(dbConn, "", xTBNames[i]);
                    }
                    else
                    {
                        CheckColumns(dbConn, "", xTBNames[i], mLst_Schema_Prj);
                    }
                    if (CheckTableExists("xDel_" + xTBNames[i], mLst_Schema_Prj) == false)
                    {
                        CreateTable(dbConn, "xDel_", xTBNames[i]);
                    }
                    else
                    {
                        CheckColumns(dbConn, "xDel_", xTBNames[i], mLst_Schema_Prj);
                    }
                    CheckDelTBColumns(dbConn, "xDel_" + xTBNames[i]);//444
                }
                CheckDelTriggers(dbConn, xTBNames);
            }
            catch { } 
            finally
            {
                Application.DoEvents();
            }
        }
        public static void CreateTrigger(SqlConnection dbConn, string xTBName, List<string> xLstSQLServerExTrigger)
        {
            try
            {
                string xTriggerName = "AfterDel_" + xTBName;
                if (xLstSQLServerExTrigger.Contains(xTriggerName) == true) DropTrigger(dbConn, xTriggerName);
                List<TBStr> xLstStr = TBStrs.xGetTBColumns(xTBName);
                string xSQL = @"CREATE TRIGGER " + xTriggerName + " ON " + " [" + xTBName + "] " + " FOR DELETE AS ";
                string xSQLInsert = "";
                string xSQLSelect = "";
                for (int i = 0; i < xLstStr.Count; i++)
                {
                    xSQLInsert = xSQLInsert + "," + "[" + xLstStr[i].xColName + "]";
                    xSQLSelect = xSQLSelect + "," + "[" + xLstStr[i].xColName + "]";
                }
                xSQLInsert = " INSERT INTO [xDel_" + xTBName + "]( " + xSQLInsert.Substring(1) + ", [MCName],[ServerName],[DelTimeStamp],[DelUserID]) ";
                xSQLSelect = " SELECT " + xSQLSelect.Substring(1);
                xSQLSelect = xSQLSelect + ",'-','-',CONVERT(varchar, GETDATE(), 126),User_Name() ";
                xSQL = xSQL + xSQLInsert + xSQLSelect + " FROM DELETED ;";
                SqlCommand xCmd = new SqlCommand(xSQL, dbConn);
                xCmd.CommandType = CommandType.Text;
                xCmd.ExecuteNonQuery();
                xCmd.Dispose();
            }
            catch (Exception ex) { MessageBox.Show(xTBName + " : " + ex.Message); }
        }
        public static bool CheckDelTriggers(SqlConnection dbConn, List<string> xTBNames)
        {
            try
            {
                List<string> xLstSQLServerExTrigger = xGetSQLDBTriggers(dbConn);
                for (int i = 0; i < xTBNames.Count; i++)
                {
                    CreateTrigger(dbConn, xTBNames[i], xLstSQLServerExTrigger);
                }
                return true;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                return false;
            }
        }
        public static List<string> xGetSQLDBTriggers(SqlConnection DBConn)
        {
            try
            {
                List<string> xLst = new List<string>();
                SqlCommand cmd = new SqlCommand("Select name from sys.triggers WHERE [type] = 'TR' ", DBConn);
                cmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = cmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        xLst.Add(oReader["name"].ToString());
                    }
                }
                return xLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<string>(); }
        }
        private static void DropTrigger(SqlConnection DBConn, string xTriggerName)
        {
            try
            {
                string xSQL = "DROP TRIGGER " + xTriggerName;
                DBFunctions.ExeNonQuery(DBConn, xSQL);
            }
            catch { }
        }
        public static List<V1V2V3> GetTables(List<string> xLst)
        {
            List<V1V2V3> xLstTableNames = new List<V1V2V3>();
            xLstTableNames.Add(new V1V2V3("999101", "CQ_Portal_News", 101, true));//xFlag
            xLstTableNames.Add(new V1V2V3("999102", "CQ_Portal_Company", 102, true)); //xFlag
            xLstTableNames.Add(new V1V2V3("999103", "CQ_Portal_Review", 103, true));
            xLstTableNames.Add(new V1V2V3("999104", "CQ_Portal_ContactUs", 104, true));
            xLstTableNames.Add(new V1V2V3("999106", "CQ_Portal_Professionals", 106, true));
            xLstTableNames.Add(new V1V2V3("999107", "CQ_Portal_JobVaccancy", 107, true)); ;//xFlag
            xLstTableNames.Add(new V1V2V3("999108", "CQ_Portal_Tender", 108, true));
            xLstTableNames.Add(new V1V2V3("999109", "CQ_Portal_Bidder", 109, true));
            xLstTableNames.Add(new V1V2V3("999110", "CQ_Portal_Placement", 110, true));
            xLstTableNames.Add(new V1V2V3("999111", "CQ_Portal_GovtPortal", 111, true));
            xLstTableNames.Add(new V1V2V3("999112", "CQ_Portal_SampleTender", 112, true));
            xLstTableNames.Add(new V1V2V3("999113", "CQ_Portal_TrainingProgram", 113, true));
            xLstTableNames.Add(new V1V2V3("999114", "CQ_Portal_PlacedStudent", 114, true));
            xLstTableNames.Add(new V1V2V3("999115", "CQ_Portal_InfraProfessional", 115, true));
            xLstTableNames.Add(new V1V2V3("999116", "CQ_Portal_ConsultantCompany", 116, true));
            xLstTableNames.Add(new V1V2V3("999117", "CQ_Portal_OTP", 117, true));
            xLstTableNames.Add(new V1V2V3("999118", "CQ_Portal_CQNews", 118, true));
            xLstTableNames.Add(new V1V2V3("999119", "CQ_Portal_NewsPhotoName", 119, true));
            xLstTableNames.Add(new V1V2V3("999120", "CQ_Portal_SuccessFulStories", 112, true));
            if (xLst.Count == 0) return xLstTableNames;
            return xLstTableNames.FindAll(p => xLst.Contains(p.xV1.Substring(0, 1)));
        }
        public static List<TBStr> xGetTBColumns(string xTBName)
        {
            try
            {
                List<TBStr> xLstTBStr = new List<TBStr>();

                if (xTBName == "CQ_Portal_News")
                {
                    //xID,xTitle,xSubTitle,xSource,xLinkAdd,xDate,xSeqNo,xFlag
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xTitle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSubTitle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSource", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xLinkAdd", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDate", "float", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xFlag", "bit", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_Company")
                {
                    //xID,xName,xShortName,xDesc,xCity,xCompanyLink,xLogoName,xCompanyOpeningLink,xFlag,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xShortName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCity", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyLink", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xLogoName", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyOpeningLink", "varchar", "1000"));
                    xLstTBStr.Add(new TBStr(xTBName, "xFlag", "bit", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_Professionals")
                {
                    //xID,xName,xPhotoName,xDescription,xCompanyId,xDesignation,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPhotoName", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDescription", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyId", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesignation", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_Review")
                {
                    //xDate, xTitle, xSubTitle, xDescription,xProfessionalID,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDate", "float", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xTitle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSubTitle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDescription", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xProfessionalID", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_JobVaccancy")
                {
                    //xID,xDate,xCompanyId,xTitle,xDesc,xLink,xFlag,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDate", "float", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyId", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xTitle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xLink", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xFlag", "bit", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_Tender")
                {
                    //xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDate", "float", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xPrjNameName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDepName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPrjCoast", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "2000"));
                    xLstTBStr.Add(new TBStr(xTBName, "xImage1", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xImage2", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_Bidder")
                {
                    //xID,xDate,xCompanyID,xBidValue,xPerVariation,,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDate", "float", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyID", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xBidValue", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPerVariation", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_ContactUs")
                {
                    //xID,xName,xCompanyName,xCity,xEmail,xPhoneNo,xSubject,xMessage,xGetquot,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "int", "", "PK"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyName", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCity", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xEmail", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPhoneNo", "varchar", "15"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSubject", "varchar", "300"));
                    xLstTBStr.Add(new TBStr(xTBName, "xMessage", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xGetquot", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_Placement")
                {//xName,xEmail,xPhoneNo,xAge,xEducation,xExperience,xMessage,xFileName,xCVPdfORImage,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "int", "", "PK"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xEmail", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPhoneNo", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xAge", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xEducation", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xExperience", "varchar", "700"));
                    xLstTBStr.Add(new TBStr(xTBName, "xMessage", "varchar", "1000"));
                    xLstTBStr.Add(new TBStr(xTBName, "xFileName", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCVPdfORImage", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_GovtPortal")
                {
                    //xID,xName,xLink,xSeqNo,xFlag,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xLink", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xFlag", "bit", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_SampleTender")
                {
                    //xID,xProjectName,xDept,xDesc,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xProjectName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDept", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_TrainingProgram")
                {
                    //xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xTitle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xShortDesc", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xStartDate", "float", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "900"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDuration", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xLocation", "varchar", "600"));
                    xLstTBStr.Add(new TBStr(xTBName, "xTimings", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xContactNo", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCity", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_PlacedStudent")
                {
                    //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xEmail", "varchar", "200"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDepartment", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xExeperience", "varchar", "700"));
                    xLstTBStr.Add(new TBStr(xTBName, "xQualification", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "900"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPlacedCompany", "varchar", "600"));
                    xLstTBStr.Add(new TBStr(xTBName, "xContactNumber", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPSPhotoName", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_InfraProfessional")
                {
                    //xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xQualification", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesignation", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompany", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xExp", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xContactNumber", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xEmail", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "900"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPhotoName", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_ConsultantCompany")
                {
                    //xID,xName,xShortName,xDesc,xCity,xCompanyLink,xLogoName,xFlag,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xShortName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCity", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyLink", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xLogoName", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xFlag", "bit", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_OTP")
                {
                    //xType,xSTID,xOTP,xTime
                    xLstTBStr.Add(new TBStr(xTBName, "xType", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSTID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xOTP", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xTime", "varchar", "50"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_CQNews")
                {
                    //xID,xTitle,xDesc,xDateTimeStamp,xSeqNo
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "100"));
                    xLstTBStr.Add(new TBStr(xTBName, "xTitle", "varchar", "50"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDate", "float", "50"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", "50"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_NewsPhotoName")
                {//xNewsID,xPhotoFileName,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xNewsID", "varchar", "100")); 
                    xLstTBStr.Add(new TBStr(xTBName, "xPhotoFileName", "varchar", "255")); 
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20")); 
                    return xLstTBStr;
                }
                else if (xTBName == "CQ_Portal_SuccessFulStories")
                {
                    // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp
                    xLstTBStr.Add(new TBStr(xTBName, "xID", "varchar", "20"));
                    xLstTBStr.Add(new TBStr(xTBName, "xTiltle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSubTitle", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xDesc", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xCompanyName", "varchar", "500"));
                    xLstTBStr.Add(new TBStr(xTBName, "xPhotoName", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xLogoName", "varchar", "800"));
                    xLstTBStr.Add(new TBStr(xTBName, "xSeqNo", "int", ""));
                    xLstTBStr.Add(new TBStr(xTBName, "xDateTimeStamp", "varchar", "20"));
                    return xLstTBStr;
                }
                else
                {
                    MessageBox.Show("Table " + xTBName + " Structure Not Found");
                    return new List<TBStr>();
                }
            }
            catch { return new List<TBStr>(); }
        }
        public static bool CreateTable(SqlConnection dbConn, string PreFix, string xTBName)
        {
            try
            {
                string xSQL1 = @"CREATE TABLE dbo." + PreFix + xTBName; // dbo.PTM_Phase (xID varchar(20),xName varchar(50),xChildPhaseId varchar(20),xSeqNo bigint,xType varchar(1));";
                List<TBStr> xLstTBCols = TBStrs.xGetTBColumns(xTBName);
                string xSQL2 = "";
                for (int i = 0; i < xLstTBCols.Count; i++)
                {
                    xSQL2 = xSQL2 + "," + xLstTBCols[i].xColName + " " + xLstTBCols[i].xColType;
                    if (xLstTBCols[i].xColType == "varchar")
                    {
                        xSQL2 = xSQL2 + "(" + xLstTBCols[i].xColSize + ")";
                        if (PreFix == "")
                        {
                            if (xLstTBCols[i].xV1 == "UNIQUE") xSQL2 = xSQL2 + " NOT NULL UNIQUE ";
                        }
                    }
                    if (xLstTBCols[i].xColType == "varbinary")
                    {
                        xSQL2 = xSQL2 + "(" + xLstTBCols[i].xColSize + ")";
                    }
                    else if (xLstTBCols[i].xColType == "bigint")
                    {

                    }
                    else if (xLstTBCols[i].xColType == "int")
                    {
                        if (PreFix == "")
                        {
                            if (xLstTBCols[i].xV1 == "PK") xSQL2 = xSQL2 + " IDENTITY(1,1) PRIMARY KEY";
                        }
                    }
                }
                string xSQL = xSQL1 + "(" + xSQL2.Substring(1) + ")";
                DBFunctions.ExeNonQuery(dbConn, xSQL);
                return true;
            }
            catch (Exception Ex)
            {
                return false;
            }
        }
        public static bool CheckColumns(SqlConnection dbConn, string xPrefix, string xTBName, List<TBSchema> xLst_Schema)
        {
            int i = 0;
            List<TBStr> xLstCQTBColumns = new List<TBStr>();
            try
            {
                xLstCQTBColumns = TBStrs.xGetTBColumns(xTBName);
                List<TBSchema> xLstSQLTBColumns = mLst_Schema_Prj.FindAll(p => p.TABLE_NAME == xPrefix + xTBName);
                for (i = 0; i < xLstCQTBColumns.Count; i++)
                {
                    TBSchema xSQLCol = xLstSQLTBColumns.Find(p => p.COLUMN_NAME == xLstCQTBColumns[i].xColName);
                    if (xSQLCol == null)
                    {
                        // Add Column To Table
                        string xDataLen = "";
                        if (xLstCQTBColumns[i].xColType == "varchar") xDataLen = " (" + xLstCQTBColumns[i].xColSize + ")";
                        string xSQL = "";

                        xSQL = @" ALTER TABLE " + xPrefix + xTBName + " ADD " + xLstCQTBColumns[i].xColName + " " + xLstCQTBColumns[i].xColType + xDataLen;

                        DBFunctions.ExeNonQuery(dbConn, xSQL);
                    }
                    else
                    {
                        if (CheckColDetails(dbConn, xPrefix + xTBName, xLstCQTBColumns[i], xSQLCol) == false)
                        {
                            // Add To Error Log
                            return false;
                        }
                    }
                }
                return true;
            }
            catch
            {
                MessageBox.Show(i.ToString() + " " + xLstCQTBColumns[i].xName + " " + xLstCQTBColumns[i].xColName);
                return false;
            }
        }
        public static List<V1V2V3> GetTables_Prj()
        {
            try
            {
                List<V1V2V3> xLst = GetTables(new List<string>());

                return xLst.OrderBy(p => p.xSeqNo).ToList();
            }
            catch { return new List<V1V2V3>(); }
        }       
        public static bool CheckColDetails(SqlConnection dbConn, string xTBName, TBStr CQCol, TBSchema SQLCol)
        {
            try
            {
                if (CQCol.xColType != SQLCol.DATA_TYPE)
                {
                    string xDataLen = "";
                    if (CQCol.xColType == "varchar") xDataLen = " (" + CQCol.xColSize + ")";
                    string xSQL = @"ALTER TABLE " + xTBName + " ALTER COLUMN " + CQCol.xColName + " " + CQCol.xColType + xDataLen;
                    DBFunctions.ExeNonQuery(dbConn, xSQL);
                }
                if (CQCol.xColType == "varchar")
                {
                    if (Convert.ToDouble(CQCol.xColSize) > Convert.ToDouble(SQLCol.CHARACTER_MAXIMUM_LENGTH))
                    {
                        string xDataLen = " (" + CQCol.xColSize + ")";
                        string xSQL = @"ALTER TABLE " + xTBName + " ALTER COLUMN " + CQCol.xColName + " " + CQCol.xColType + xDataLen;
                        DBFunctions.ExeNonQuery(dbConn, xSQL);
                    }
                }
                return true;
            }
            catch { return false; }
        }
        public static bool CheckDelTBColumns(SqlConnection dbConn, string xTBName)
        {
            int i = 0;
            List<TBStr> xLstCQTBColumns = new List<TBStr>();
            try
            {
                List<TBSchema> xLstSQLTBColumns = mLst_Schema_Prj.FindAll(p => p.TABLE_NAME == xTBName);
                xLstCQTBColumns.Add(new TBStr("-", "MCName", "varchar", "20"));
                xLstCQTBColumns.Add(new TBStr("-", "ServerName", "varchar", "20"));
                xLstCQTBColumns.Add(new TBStr("-", "DelTimeStamp", "varchar", "50"));
                xLstCQTBColumns.Add(new TBStr("-", "DelUserID", "varchar", "20"));
                for (i = 0; i < xLstCQTBColumns.Count; i++)
                {
                    TBSchema xSQLCol = xLstSQLTBColumns.Find(p => p.COLUMN_NAME == xLstCQTBColumns[i].xColName);
                    if (xSQLCol == null)
                    {
                        string xDataLen = "";
                        if (xLstCQTBColumns[i].xColType == "varchar") xDataLen = " (" + xLstCQTBColumns[i].xColSize + ")";
                        string xSQL = "";
                        xSQL = @" ALTER TABLE " + xTBName + " ADD " + xLstCQTBColumns[i].xColName + " " + xLstCQTBColumns[i].xColType + xDataLen;
                        DBFunctions.ExeNonQuery(dbConn, xSQL);
                    }
                    else
                    {
                        if (CheckColDetails(dbConn, xTBName, xLstCQTBColumns[i], xSQLCol) == false)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            catch
            {
                MessageBox.Show(i.ToString() + " " + xLstCQTBColumns[i].xName + " " + xLstCQTBColumns[i].xColName);
                return false;
            }
        }
        private static bool CheckTableExists(string TBName, List<TBSchema> xLst_Schema)
        {
            try
            {
                if (xLst_Schema.FindAll(p => p.TABLE_NAME == TBName).Count() > 0) return true;
                return false;
            }
            catch { return false; }
        }
    }
}
