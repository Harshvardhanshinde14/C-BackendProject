﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Globalization;
using static System.Windows.Forms.AxHost;
using System.Security.Cryptography;
using System.IO;
namespace CQPortal
{
    public static class PlacedStudents
    {
        public static List<PlacedStudent> mLst = new List<PlacedStudent>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<PlacedStudent> xLst)
        {
            //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp.
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xName + "','" + xLst[n].xEmail + "','" + xLst[n].xDepartment + "','" + xLst[n].xExeperience + "','" + xLst[n].xQualification + "','" + xLst[n].xPlacedCompany + "','" + xLst[n].xContactNumber + "','" + xLst[n].xDesc + "','" + xLst[n].xPSPhotoName + "','" + xLst[n].xSeqNo + "','" + xDateTimeStamp + "')");

                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_PlacedStudent (xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xSeqNo,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_PlacedStudent");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            //xEmail,xDepartment,xExeperience
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_PlacedStudent WHERE xID = '" + xID + "' ") == false) return;
                PlacedStudent xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<PlacedStudent> { xT });
            }
            catch { }
        }
        public static List<PlacedStudent> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<PlacedStudent> xRetLst = new List<PlacedStudent>();
                while (oReader.Read())
                {
                    //
                    //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp.,xSeqNo
                    PlacedStudent xT = new PlacedStudent();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xName = oReader["xName"].ToString().Trim();
                    xT.xEmail = oReader["xEmail"].ToString().Trim();
                    xT.xDepartment = oReader["xDepartment"].ToString().Trim();
                    xT.xExeperience = oReader["xExeperience"].ToString().Trim();
                    xT.xQualification = oReader["xQualification"].ToString().Trim();
                    xT.xPlacedCompany = oReader["xPlacedCompany"].ToString().Trim();
                    xT.xContactNumber = oReader["xContactNumber"].ToString().Trim();
                    xT.xDesc = oReader["xDesc"].ToString().Trim(); ;
                    xT.xPSPhotoName = oReader["xPSPhotoName"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xT.xDateTimeStamp = oReader["xDateTimeStamp"].ToString().Trim();
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<PlacedStudent>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<PlacedStudent>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_PlacedStudent";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_PlacedStudent WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                PlacedStudents.xPopTV(TV);
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID()
        {
            try
            {
                List<PlacedStudent> xLst = mLst.FindAll(p => p.xID.Length == 6).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<PlacedStudent> xLst = mLst.OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static PlacedStudent xGetByID(string xID)
        {
            try
            {
                PlacedStudent xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new PlacedStudent();
                return xT;
            }
            catch { return new PlacedStudent(); }
        }
        #endregion

        #region Add Update        
        //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp
        public static void xAdd(SqlConnection DBConn, TreeView TV, TextBox txtName, TextBox txtEmail, TextBox txtDepartment, TextBox txtExeperience, TextBox txtQualification, TextBox txtPlacedCompany, TextBox txtContactNumber, TextBox txtDesc)
        {
            try
            {
                //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp
                PlacedStudent xT = new PlacedStudent();
                xT.xID = xGetNewID();
                xT.xSeqNo = xGetNewSeqNo();
                xT.xName = txtName.Text.Trim();
                xT.xEmail = txtEmail.Text.Trim();
                xT.xDepartment = txtDepartment.Text.Trim();
                string Exp = txtExeperience.Text.Trim();
                double xxExpMonths = 0;
                double.TryParse(Exp, out xxExpMonths);
                int xxxExpMonths = Convert.ToInt32(xxExpMonths * 12);
                string xStartMonth = DateTime.Now.AddMonths(-1 * xxxExpMonths).ToString("yyyyMM");
                xT.xExeperience = xStartMonth;
                xT.xQualification = txtQualification.Text.Trim();
                xT.xPlacedCompany = txtPlacedCompany.Text.Trim();
                xT.xContactNumber = txtContactNumber.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xPSPhotoName = xT.xID + "_PSPhotoName";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static bool xValidate(
    SqlConnection DBConn, TreeView TV, TextBox txtName, TextBox txtEmail, TextBox txtDepartment,
    TextBox txtExeperience, TextBox txtQualification, TextBox txtPlacedCompany, TextBox txtContactNumber,
    TextBox txtDesc, out string ErrorMessage)
        {
            ErrorMessage = string.Empty;
            try
            {
                bool isValid = true;

                // Check for empty fields
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    ErrorMessage += "Name is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    ErrorMessage += "Email is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtDepartment.Text))
                {
                    ErrorMessage += "Department is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtExeperience.Text))
                {
                    ErrorMessage += "Experience is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtQualification.Text))
                {
                    ErrorMessage += "Qualification is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtPlacedCompany.Text))
                {
                    ErrorMessage += "Placed Company is required.\n";
                    isValid = false;
                }
                if (string.IsNullOrWhiteSpace(txtContactNumber.Text))
                {
                    ErrorMessage += "Contact Number is required.\n";
                    isValid = false;
                }
                // Validate email format
                if (!IsValidEmail(txtEmail.Text))
                {
                    ErrorMessage += "Please enter a valid email address.\n";
                    isValid = false;
                }
                // Validate contact number length and numeric content
                if (!IsNumeric(txtContactNumber.Text) || txtContactNumber.Text.Length != 10)
                {
                    ErrorMessage += "Contact number must be exactly 10 numeric digits.\n";
                    isValid = false;
                }
                // Additional validations can be added here (e.g., date format, numeric fields, etc.)
                return isValid;
            }
            catch { return false; }
        }
        private static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
        private static bool IsNumeric(string value)
        {
            try
            {
                return value.All(char.IsDigit);
            }
            catch { return false; }
        }
        public static void xUpdate(SqlConnection DBConn, TreeView TV, string xID, TextBox txtName, TextBox txtEmail, TextBox txtDepartment, TextBox txtExeperience, TextBox txtQualification, TextBox txtPlacedCompany, TextBox txtContactNumber, TextBox txtDesc, string newPhotoName = null)
        {
            try
            {//xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,string xStartDateExp,xSeqNo

                PlacedStudent xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xName = txtName.Text.Trim();
                xT.xEmail = txtEmail.Text.Trim();
                xT.xDepartment = txtDepartment.Text.Trim();
                string Exp = txtExeperience.Text.Trim();
                double xxExpMonths = 0;
                double.TryParse(Exp, out xxExpMonths);
                int xxxExpMonths = Convert.ToInt32(xxExpMonths * 12);
                string xStartMonth = DateTime.Now.AddMonths(-1 * xxxExpMonths).ToString("yyyyMM");
                xT.xExeperience = xStartMonth;
                xT.xQualification = txtQualification.Text.Trim();
                xT.xPlacedCompany = txtPlacedCompany.Text.Trim();
                xT.xContactNumber = txtContactNumber.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();

                // Update the photo name only if a new photo is provided
                if (!string.IsNullOrEmpty(newPhotoName))
                {
                    xT.xPSPhotoName = newPhotoName;
                }
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<PlacedStudent> xLst = mLst.OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst.Count; i++)
                {
                    TV.Nodes.Add(xLst[i].xID, xLst[i].xName);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID, TextBox txtName, TextBox txtEmail, TextBox txtDepartment, TextBox txtExeperience, TextBox txtQualification, TextBox txtPlacedCompany, TextBox txtContactNumber, TextBox txtDesc)
        {
            try
            {
                //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xSeqNo
                PlacedStudent xT = xGetByID(xID);
                txtName.Text = xT.xName;
                txtEmail.Text = xT.xEmail;
                txtDepartment.Text = xT.xDepartment;
                txtExeperience.Text = xT.xExeperience;
                txtQualification.Text = xT.xQualification;
                txtPlacedCompany.Text = xT.xPlacedCompany;
                txtContactNumber.Text = xT.xContactNumber;
                txtDesc.Text = xT.xDesc;
                //txtStartDateExp.Text = xT.xStartDateExp;
                string xxStartDateExp = xT.xExeperience;
                DateTime timespanDate = DateTime.ParseExact(xxStartDateExp, "yyyyMM", CultureInfo.InvariantCulture);
                DateTime now = DateTime.Now;
                int monthsDifference = ((now.Year - timespanDate.Year) * 12) + now.Month - timespanDate.Month;
                txtExeperience.Text = (Convert.ToDouble(monthsDifference) / 12).ToString();
            }
            catch { }
        }
        public static void xUpdatePSPhotoName(SqlConnection DBConn, string xID, string xPSPhotoName)
        {
            try
            {
                PlacedStudent xT = xGetByID(xID);
                if (CQSQL.ExeNonQuery(DBConn, "UPDATE dbo.CQ_Portal_PlacedStudent SET xPSPhotoName = '" + xPSPhotoName + "' WHERE xID = '" + xID + "' ") == true)
                {
                    xT.xPSPhotoName = xPSPhotoName;
                }
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown(SqlConnection DBConn, TreeView TV, bool MoveUp)
        {
            try
            {
                if (TV.SelectedNode == null) return;
                string xID = TV.SelectedNode.Name;
                List<PlacedStudent> xLst = new List<PlacedStudent>();
                xLst = mLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xID];
            }
            catch { }
        }
        public static double CalculateExperience(DateTime xStartDateExp)
        {
            try
            {
                var today = DateTime.Today;
                var years = today.Year - xStartDateExp.Year;
                if (xStartDateExp.Date > today.AddYears(-years)) years--;
                return years + (today.Month - xStartDateExp.Month) / 12 + (today.Day - xStartDateExp.Day) / 365;
            }
            catch { return 0; }
        }
        #endregion

        #region writeFile
        public static bool xCompanysWriteTableToFile(SqlConnection DBConn)
        {
            try
            {
                string xFileName = CQBVar.xPath + "\\" + "101_PlacedStudentsFromTable_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_PlacedStudent ";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp.
                StringBuilder SB = new StringBuilder();
                string xLine = "xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp";
                SB.AppendLine(xLine);
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        // xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp.
                        xLine = oReader["xID"].ToString().Trim() + "," + oReader["xName"].ToString().Trim() + "," + oReader["xEmail"].ToString().Trim() + "";
                        xLine = xLine + "," + oReader["xDepartment"].ToString().Trim() + "," + oReader["xExeperience"].ToString().Trim() + "," + oReader["xQualification"].ToString().Trim() + "";
                        xLine = xLine + "," + oReader["xPlacedCompany"].ToString().Trim() + "," + oReader["xContactNumber"].ToString().Trim() + "," + oReader["xDesc"].ToString().Trim() + "";
                        xLine = xLine + "," + oReader["xPSPhotoName"].ToString().Trim() + "," + oReader["xStartDateExp"].ToString().Trim() + "";
                        SB.AppendLine(xLine);
                    }
                }
                StreamWriter xWriter = new StreamWriter(xFileName);
                xWriter.Write(SB);
                System.Diagnostics.Process.Start(xFileName);
                xWriter.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion
    }
}






