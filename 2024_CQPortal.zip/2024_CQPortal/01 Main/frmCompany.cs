﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using static System.Windows.Forms.AxHost;

namespace CQPortal
{

    public partial class frmCompany : Form
    {
        public DateTime mDate = DateTime.Now;
        public DateTime mShowDate = DateTime.Now;                                                                                      
        string mCaller = "1";

        List<double> mLstHighliteRows = new List<double>();
        private Point mStartingPoint = Point.Empty;
        private Point mCompanyMovingPoint = Point.Empty;
        private bool mCompanyPanning = false;
        private Point mProfStartingPoint = Point.Empty;
        private Point mProfMovingPoint = Point.Empty;
        private bool mProfPanning = false;

        public frmCompany()
        {
            InitializeComponent();
           
        }
        #region Form
        private void frmCompany_Load(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                DBConn.Open();
                Download(DBConn);
                ShowCountCompany(DBConn);
                ShowCountConsultantCompany(DBConn);
                //int currentMonthCount = Companys.GetCurrentMonthCompanyCount(DBConn);
                //txtCompanyCurrentMonthCount.Text = $"Current Month Count: {currentMonthCount}";
                //int previousMonthCount = Companys.GetPreviousMonthCompanyCount(DBConn);
                //txtCompanyPreMonthCount.Text = $"Previous Month Count: {previousMonthCount}";
                //int currentMonthCount2 = ConsultantCompanys.GetCurrentMonthConsultantCompanyCount(DBConn);
                //txtConsultantCurrentMonthCount.Text = $"Current Month Count: {currentMonthCount2}";
                //int previousMonthCount2 = ConsultantCompanys.GetPreviousMonthConsultantCompanyCount(DBConn);
                //txtConsultantPreMonthCount.Text = $"Previous Month Count: {previousMonthCount2}";

                Companys.xPopTV(TVCompany);
                CQBVar.ConnString.UserRole = "-";
                this.Text = "CQ_Portal_" + CQBVar.Version;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally {  DBConn.Close(); }
        }
        private void Download(SqlConnection DBConn)
        {
            try
            {
                Companys.DownLoad(DBConn);
                ConsultantCompanys.DownLoad(DBConn);
                GovtPortals.DownLoad(DBConn);
                InfraProfessionals.DownLoad(DBConn);
                Professionalss.DownLoad(DBConn);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { }
        }
        #endregion

        #region Other
        private void TV_DrawNode(object sender, DrawTreeNodeEventArgs e)
        {
            try
            {
                Functions.TVDrawNode(sender, e);
            }
            catch { }
        }
        private void TC_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection dbCQPrjConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TC.SelectedTab == tabCompany)
                {
                    Companys.xPopTV(TVCompany);
                }
                else if (TC.SelectedTab == tabProfessionals)
                {
                    Professionalss.xPopTV(TVProfessional);
                    Companys.xPopTV(TVProfCompany);
                }
                else if (TC.SelectedTab == tabGovtPortal)
                {
                    GovtPortals.xPopTV(TVGovPoratl);
                }
                else if (TC.SelectedTab == tabInfraProfessional)
                {
                    InfraProfessionals.xPopTV(TVInfraProf);
                }
                else if (TC.SelectedTab == tabconsultantcompany)
                {
                    ConsultantCompanys.xPopTV(TVConsultantCompany);
                }
            }
            catch { }
            finally { }
        }
        #endregion

        #region Company
        private void ShowCountCompany(SqlConnection DBConn)
        {
            try
            {
                Int64 xCompanyCountCurrMonth = 0;
                Int64 xCompanyCountPrevMonth = 0;
                string xCurMonth = DateTime.Now.ToString("yyyyMM");

                DateTime previousMonthDate = DateTime.Now.AddMonths(-1);
                string xPrevMonth = previousMonthDate.ToString("yyyyMM");
                Companys.GetListCountFortMonth(DBConn, xCurMonth, out xCompanyCountCurrMonth);
                Companys.GetListCountFortMonth(DBConn, xPrevMonth, out xCompanyCountPrevMonth);
                lblCompanyPrevMonth.Text = "Company Count for Previous Month : " + xPrevMonth + " : " + xCompanyCountPrevMonth;
                lblCompanyCurrMonth.Text = "Company Count for Current Month : " + xCurMonth + " : " + xCompanyCountCurrMonth; ;

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void btnCompanyAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                Companys.xAdd6(DBConn, TVCompany, txtCompanyName, txtCompanyShortName, txtCompanyDesc, txtCompanyCity, txtCompanyLink, txtCompanyOpeningLinkAdd, ckhCompanyFlag);
                ShowCountCompany(DBConn);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnCompanyUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVCompany.SelectedNode == null) return;
                if (TVCompany.SelectedNode.Level == 0)
                {
                    string xID = TVCompany.SelectedNode.Name;
                    Companys.xUpdate3(DBConn, TVCompany, xID, txtCompanyName, txtCompanyShortName);
                }
                else
                {
                    if (TVCompany.SelectedNode == null) return;
                    string xID = TVCompany.SelectedNode.Name;
                    Companys.xUpdate6(DBConn, TVCompany, xID, txtCompanyName, txtCompanyShortName, txtCompanyDesc, txtCompanyCity, txtCompanyLink, txtCompanyOpeningLinkAdd, ckhCompanyFlag);
                }
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnCompanyDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                MessageBox.Show("selected entry will be deleted");
                DBConn.Open();
                if (TVCompany.SelectedNode == null) return;
                string xID = TVCompany.SelectedNode.Name;
                Companys.xDelete(DBConn, TVCompany, xID);
                ShowCountCompany(DBConn);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnCompanyExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void TVCompany_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVCompany.SelectedNode == null) return;
                string xID = TVCompany.SelectedNode.Name;
                Companys.xPopInRev(xID, txtCompanyName, txtCompanyShortName, txtCompanyDesc, txtCompanyCity, txtCompanyLink, txtCompanyOpeningLinkAdd, ckhCompanyFlag);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        async private void btnCompanyUploadLogo_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVCompany.SelectedNode == null || TVCompany.SelectedNode.Level == 0) return;
                string xID = TVCompany.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("ClientLogo", xFileName);
                DBConn.Open();
                Companys.xUpdateLogo(DBConn, xID, Path.GetFileNameWithoutExtension(xFileName));
                Companys.xPopInRev(xID, txtCompanyName, txtCompanyShortName, txtCompanyDesc, txtCompanyCity, txtCompanyLink, txtCompanyOpeningLinkAdd, ckhCompanyFlag);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }

        }
        private void btnCompanyDefault_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string xIn1 = "Data Will Be moved , Do You Wish To move";
                string xIn2 = "";
                frmSel_Confirmation frm = new frmSel_Confirmation(xIn1, out xIn2);
                frm.ShowDialog();
                frm.Dispose();
                if (xIn2 != CQBVar.Portal.Sel.Confirmation)
                {
                    MessageBox.Show("InValid Key.");
                    return;
                }
                DBConn.Open();
                Companys.xAddDefault(DBConn);
                Companys.xPopTV(TVCompany);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void txtCompanyLink_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (txtCompanyLink.Text == "") return;
                webBrowserCompany.Visible = true;
                webBrowserCompany.ScriptErrorsSuppressed = true;
                webBrowserCompany.Navigate(txtCompanyLink.Text);
            }
            catch { }
        }
        private void btnCompanyAddGrp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                Companys.xAdd3(DBConn, TVCompany, txtCompanyName, txtCompanyShortName);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnCompanyShowLogo_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVCompany.SelectedNode == null || TVCompany.SelectedNode.Level == 0) return;
                string xID = TVCompany.SelectedNode.Name;
                Company xT = Companys.xGetByID(xID);
                string xLogo = xT.xLogoName;
                if (xLogo.ToLower().EndsWith(".JPEG")) xLogo = xLogo.Substring(0, xLogo.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/ClientLogo/" + xLogo;
                UpDLLoadImage.DownloadImage(xLogo, MyURL);
            }
            catch
            {
            }
        }
        private void btnCompanyUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVCompany.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVCompany.SelectedNode.Level == 0)
                {
                    Companys.UpOrDown3(DBCQConn, TVCompany, true);
                }
                else if (TVCompany.SelectedNode.Level == 1)
                {
                    Companys.UpOrDown6(DBCQConn, TVCompany, true);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnCompanyDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVCompany.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVCompany.SelectedNode.Level == 0)
                {
                    Companys.UpOrDown3(DBCQConn, TVCompany, false);
                }
                else if (TVCompany.SelectedNode.Level == 1)
                {
                    Companys.UpOrDown6(DBCQConn, TVCompany, false);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnCompanyWrite_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {DBCQConn.Open();
                Companys.xCompanysWriteTableToFile(DBCQConn);
                Companys.xWrite();
            }
            catch { }
            finally { DBCQConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void btnCompanyRead_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string xIn1 = "Data Will Be moved , Do You Wish To move";
                string xIn2 = "";
                frmSel_Confirmation frm = new frmSel_Confirmation(xIn1, out xIn2);
                frm.ShowDialog();
                frm.Dispose();
                if (xIn2 != CQBVar.Portal.Sel.Confirmation)
                {
                    MessageBox.Show("InValid Key.");
                    return;
                }
                DBConn.Open();
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "CSV Files (*.CSV) | *.CSV";
                if (mOpenFile.ShowDialog() == System.Windows.Forms.DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                Companys.xRead(DBConn, xFileName);
                Companys.xPopTV(TVCompany);
                ShowCountCompany(DBConn);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        #endregion

        #region Professionals
        private void btnProfExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void btnProfAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVProfCompany.SelectedNode == null || TVProfCompany.SelectedNode.Level == 0)
                {
                    MessageBox.Show("Select Company");
                    return;
                }
                string xCompanyID = TVProfCompany.SelectedNode.Name;
                Professionalss.xAdd6(DBConn, TVProfessional, txtProfName, txtProfDesc, xCompanyID, txtProfDesignation);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnProfUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVProfessional.SelectedNode.Level == 0)
                {
                    string xID = TVProfessional.SelectedNode.Name;
                    Companys.xUpdate3(DBConn, TVProfessional, xID, txtProfName, txtProfDesc);
                }
                else
                {
                    if (TVProfessional.SelectedNode == null) return;
                    if (TVProfCompany.SelectedNode == null || TVProfCompany.SelectedNode.Level == 0)
                    {
                        MessageBox.Show("Select Company");
                        return;
                    }
                    string xCompanyID = TVProfCompany.SelectedNode.Name;
                    string xID = TVProfessional.SelectedNode.Name;
                    Professionalss.xUpdate6(DBConn, xID, TVProfessional, txtProfName, txtProfDesc, xCompanyID, txtProfDesignation);
                }
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnProfDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                MessageBox.Show("selected entry will be deleted");
                DBConn.Open();
                if (TVProfessional.SelectedNode == null) return;
                string xID = TVProfessional.SelectedNode.Name;
                Professionalss.xDelete(DBConn, xID, TVProfessional);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnProfDefault_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string xIn1 = "Data Will Be moved , Do You Wish To move";
                string xIn2 = "";
                frmSel_Confirmation frm = new frmSel_Confirmation(xIn1, out xIn2);
                frm.ShowDialog();
                frm.Dispose();
                if (xIn2 != CQBVar.Portal.Sel.Confirmation)
                {
                    MessageBox.Show("InValid Key.");
                    return;
                }
                DBConn.Open();
                Professionalss.xAddDefault(DBConn);
                Professionalss.xPopTV(TVProfessional);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void TVProf_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                PbProfessional = new PictureBox();
                if (TVProfessional.SelectedNode == null) return;
                string xID = TVProfessional.SelectedNode.Name;
                Professionalss.xPopInRev(xID, txtProfName, txtProfDesc, TVProfCompany, txtProfDesignation);
                Professionals xT = Professionalss.xGetByID(xID);
                string xReviewerPhoto = xT.xPhotoName;
            }
            catch { }
        }
        async private void btnProfUploadPhoto_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVProfessional.SelectedNode == null || TVProfessional.SelectedNode.Level == 0) return;
                string xID = TVProfessional.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "jpg Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("ReviewerPhoto", xFileName);
                DBConn.Open();
                Professionalss.xUpdateReviewerPhoto(DBConn, xID, Path.GetFileNameWithoutExtension(xFileName));
                Professionalss.xPopInRev(xID, txtProfName, txtProfDesc, TVProfCompany, txtProfDesignation);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnProfessionalShowLogo_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVProfessional.SelectedNode == null | TVProfessional.SelectedNode.Level == 0) return;
                string xID = TVProfessional.SelectedNode.Name;
                Professionals xT = Professionalss.xGetByID(xID);
                string xLogo = xT.xPhotoName;
                if (xLogo.ToLower().EndsWith(".JPEG")) xLogo = xLogo.Substring(0, xLogo.Length - 5);
                string MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/ReviewerPhoto/" + xLogo;
                UpDLLoadImage.DownloadImage(xLogo, MyURL);
            }
            catch { }
        }
        private void btnProfAddGrp_Click_1(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                Professionalss.xAdd3(DBConn, TVProfessional, txtProfName, txtProfDesc);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnProfMoveUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVProfessional.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVProfessional.SelectedNode.Level == 0)
                {
                    Professionalss.UpOrDown3(DBCQConn, TVProfessional, true);
                }
                else if (TVProfessional.SelectedNode.Level == 1)
                {
                    Professionalss.UpOrDown6(DBCQConn, TVProfessional, true);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnProfMoveDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVProfessional.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVProfessional.SelectedNode.Level == 0)
                {
                    Professionalss.UpOrDown3(DBCQConn, TVProfessional, false);
                }
                else if (TVProfessional.SelectedNode.Level == 1)
                {
                    Professionalss.UpOrDown6(DBCQConn, TVProfessional, false);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        #endregion

        #region BackUp
        private void btnBackUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                string xPath = CQBVar.xPathBackUp;
                xPath = xPath + "\\CQPortal_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bak";
                string sql = @"BACKUP DATABASE CQCRM TO DISK = '" + xPath + "'";
                if (CQSQL.ExeNonQuery(DBConn, sql, true) == true)
                {
                    MessageBox.Show("Backup completed.");
                }
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        #endregion

        #region Govt.Portal
        private void btnGovPoratlExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void btnGovPoratlAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                string errorMessage;
                bool isValid = GovtPortals.xValidate(DBConn, TVGovPoratl, txtGovPortalName, txtGovPoratlLink, chkGovPoratlLinkFlag, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                DBConn.Open();
                GovtPortals.xAdd(DBConn, TVGovPoratl, txtGovPortalName, txtGovPoratlLink, chkGovPoratlLinkFlag);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void TVGovPoratl_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVGovPoratl.SelectedNode == null) return;
                string xID = TVGovPoratl.SelectedNode.Name;
                GovtPortals.xPopInRev(xID, txtGovPortalName, txtGovPoratlLink, chkGovPoratlLinkFlag);
            }
            catch { }
        }
        private void btnGovPoratlUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVGovPoratl.SelectedNode == null)
                {
                    MessageBox.Show("Please select Govt. portal name");
                    return;
                }
                string errorMessage;
                bool isValid = GovtPortals.xValidate(DBConn, TVGovPoratl, txtGovPortalName, txtGovPoratlLink, chkGovPoratlLinkFlag, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                string xID = TVGovPoratl.SelectedNode.Name;
                DBConn.Open();
                GovtPortals.xUpdate(DBConn, TVGovPoratl, xID, txtGovPortalName, txtGovPoratlLink, chkGovPoratlLinkFlag);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnGovPoratlDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVGovPoratl.SelectedNode == null)
                {
                    MessageBox.Show("Please select Govt. portal name");
                    return;
                }
                string xID = TVGovPoratl.SelectedNode.Name;
                DBConn.Open();
                GovtPortals.xDelete(DBConn, TVGovPoratl, xID);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnGovPoratlMoveUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                GovtPortals.UpOrDown(DBConn, TVGovPoratl, true);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnGovPoratlMoveDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                GovtPortals.UpOrDown(DBConn, TVGovPoratl, false);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        #endregion
     
        #region Infraprofessional
        private void btnInfraProfAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                string errorMessage;
                bool isValid = InfraProfessionals.xValidate(DBConn, TVInfraProf, txtInfraProfName, txtInfraProfQualification, txtInfraProfDesignation, txtInfraProfcompany, txtInfraProfExperience, txtInfraProfContact, txtInfraProfEmail, txtInfraProfDescription, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                DBConn.Open();
                InfraProfessionals.xAdd6(DBConn, TVInfraProf, txtInfraProfName, txtInfraProfQualification, txtInfraProfDesignation, txtInfraProfcompany, txtInfraProfExperience, txtInfraProfContact, txtInfraProfEmail, txtInfraProfDescription);
            }
            catch
            {
            }
            finally
            {
                DBConn.Close();
                UseWaitCursor = false;
            }
        }
        private void btnInfraProfUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVInfraProf.SelectedNode == null)
                {
                    MessageBox.Show("Please select Name");
                    return;
                }
                string errorMessage;
                bool isValid = InfraProfessionals.xValidate(DBConn, TVInfraProf, txtInfraProfName, txtInfraProfQualification, txtInfraProfDesignation, txtInfraProfcompany, txtInfraProfExperience, txtInfraProfContact, txtInfraProfEmail, txtInfraProfDescription, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                string xID = TVInfraProf.SelectedNode.Name;
                DBConn.Open();
                InfraProfessionals.xUpdate(DBConn, TVInfraProf, xID, txtInfraProfName, txtInfraProfQualification, txtInfraProfDesignation, txtInfraProfcompany, txtInfraProfExperience, txtInfraProfContact, txtInfraProfEmail, txtInfraProfDescription);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnInfraProfDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVInfraProf.SelectedNode == null)
                {
                    MessageBox.Show("Please select Name");
                    return;
                }
                string xID = TVInfraProf.SelectedNode.Name;
                DBConn.Open();
                InfraProfessionals.xDelete(DBConn, TVInfraProf, xID);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        async private void btnInfraProfUploadImg_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVInfraProf.SelectedNode == null) return;
                string xID = TVInfraProf.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("InfraProfessionalPhotos", xFileName);
                DBConn.Open();
                InfraProfessionals.xUpdatePhotoName(DBConn, xID, Path.GetFileNameWithoutExtension(xFileName));
                InfraProfessionals.xPopInRev(xID, txtInfraProfName, txtInfraProfQualification, txtInfraProfDesignation, txtInfraProfcompany, txtInfraProfExperience, txtInfraProfContact, txtInfraProfEmail, txtInfraProfDescription);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnInfraProfShowImg_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVInfraProf.SelectedNode == null) return;
                string xID = TVInfraProf.SelectedNode.Name;
                InfraProfessional xT = InfraProfessionals.xGetByID(xID);
                string xprofPhoto = xT.xPhotoName;
                if (xprofPhoto.ToLower().EndsWith(".JPEG")) xprofPhoto = xprofPhoto.Substring(0, xprofPhoto.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/InfraProfessionalPhotos/" + xprofPhoto;
                UpDLLoadImage.DownloadImage(xprofPhoto, MyURL);
            }
            catch
            {
            }
        }
        private void btnInfraProfMoveUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                InfraProfessionals.UpOrDown(DBConn, TVInfraProf, true);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnInfraProfMoveDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                InfraProfessionals.UpOrDown(DBConn, TVInfraProf, false);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnInfraProfExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {

            }
        }
        private void TVInfraProf_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVInfraProf.SelectedNode == null) return;
                string xID = TVInfraProf.SelectedNode.Name;
                InfraProfessionals.xPopInRev(xID, txtInfraProfName, txtInfraProfQualification, txtInfraProfDesignation, txtInfraProfcompany, txtInfraProfExperience, txtInfraProfContact, txtInfraProfEmail, txtInfraProfDescription);
            }
            catch { }
        }
        #endregion

        #region Consultant Company
        private void btnConsultantCompanyAddgrp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                ConsultantCompanys.xAdd3(DBConn, TVConsultantCompany, txtConsultantCompanyClientName, txtConsultantCompanyshortname);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnConsultantCompanyAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                ConsultantCompanys.xAdd6(DBConn, TVConsultantCompany, txtConsultantCompanyClientName, txtConsultantCompanyshortname, txtConsultantCompanyDescription, txtConsultantCompanyCity, txtConsultantCompanyLink, ckhCompanyFlag);
                ShowCountConsultantCompany(DBConn);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnConsultantCompanyUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVConsultantCompany.SelectedNode == null) return;
                if (TVConsultantCompany.SelectedNode.Level == 0)
                {
                    string xID = TVConsultantCompany.SelectedNode.Name;
                    ConsultantCompanys.xUpdate3(DBConn, TVConsultantCompany, xID, txtConsultantCompanyClientName, txtConsultantCompanyshortname);
                }
                else
                {
                    if (TVConsultantCompany.SelectedNode == null) return;
                    string xID = TVConsultantCompany.SelectedNode.Name;
                    ConsultantCompanys.xUpdate6(DBConn, TVConsultantCompany, xID, txtConsultantCompanyClientName, txtConsultantCompanyshortname, txtConsultantCompanyDescription, txtConsultantCompanyCity, txtConsultantCompanyLink, ckhCompanyFlag);
                }
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnConsultantCompanyDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                MessageBox.Show("selected entry will be deleted");
                DBConn.Open();
                if (TVConsultantCompany.SelectedNode == null) return;
                string xID = TVConsultantCompany.SelectedNode.Name;
                ConsultantCompanys.xDelete(DBConn, TVConsultantCompany, xID);
                ShowCountConsultantCompany(DBConn);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        async private void btnConsultantCompanyUploadLogo_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVConsultantCompany.SelectedNode == null || TVConsultantCompany.SelectedNode.Level == 0) return;
                string xID = TVConsultantCompany.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("ConsultantClientLogo", xFileName);
                DBConn.Open();
                ConsultantCompanys.xUpdateLogo(DBConn, xID, Path.GetFileNameWithoutExtension(xFileName));
                ConsultantCompanys.xPopInRev(xID, txtConsultantCompanyClientName, txtConsultantCompanyshortname, txtConsultantCompanyDescription, txtConsultantCompanyCity, txtConsultantCompanyLink, ckhCompanyFlag);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnConsultantCompanyShowLogo_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVConsultantCompany.SelectedNode == null || TVConsultantCompany.SelectedNode.Level == 0) return;
                string xID = TVConsultantCompany.SelectedNode.Name;
                ConsultantCompany xT = ConsultantCompanys.xGetByID(xID);
                string xLogo = xT.xLogoName;
                if (xLogo.ToLower().EndsWith(".JPEG")) xLogo = xLogo.Substring(0, xLogo.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/ConsultantClientLogo/" + xLogo;
                UpDLLoadImage.DownloadImage(xLogo, MyURL);
            }
            catch
            {
            }
        }
        private void btnConsultantCompanyMoveUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVConsultantCompany.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVConsultantCompany.SelectedNode.Level == 0)
                {
                    ConsultantCompanys.UpOrDown3(DBCQConn, TVConsultantCompany, true);
                }
                else if (TVConsultantCompany.SelectedNode.Level == 1)
                {
                    ConsultantCompanys.UpOrDown6(DBCQConn, TVConsultantCompany, true);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnConsultantCompanyMoveDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVConsultantCompany.SelectedNode == null) return;
                DBCQConn.Open();
                if (TVConsultantCompany.SelectedNode.Level == 0)
                {
                    ConsultantCompanys.UpOrDown3(DBCQConn, TVConsultantCompany, false);
                }
                else if (TVConsultantCompany.SelectedNode.Level == 1)
                {
                    ConsultantCompanys.UpOrDown6(DBCQConn, TVConsultantCompany, false);
                }
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnConsultantCompanyWrite_Click(object sender, EventArgs e)
        {
            try
            {
                ConsultantCompanys.xWrite();
            }
            catch { }
        }
        private void btnConsultantCompanyRead_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string xIn1 = "Data Will Be moved , Do You Wish To move";
                string xIn2 = "";
                frmSel_Confirmation frm = new frmSel_Confirmation(xIn1, out xIn2);
                frm.ShowDialog();
                frm.Dispose();
                if (xIn2 != CQBVar.Portal.Sel.Confirmation)
                {
                    MessageBox.Show("InValid Key.");
                    return;
                }
                DBConn.Open();
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "CSV Files (*.CSV) | *.CSV";
                if (mOpenFile.ShowDialog() == System.Windows.Forms.DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                ConsultantCompanys.xRead(DBConn, xFileName);
                ConsultantCompanys.xPopTV(TVConsultantCompany);
                ShowCountConsultantCompany(DBConn);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void TVConsultantCompany_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVConsultantCompany.SelectedNode == null) return;
                string xID = TVConsultantCompany.SelectedNode.Name;
                ConsultantCompanys.xPopInRev(xID, txtConsultantCompanyClientName, txtConsultantCompanyshortname, txtConsultantCompanyDescription, txtConsultantCompanyCity, txtConsultantCompanyLink, ckhCompanyFlag);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        private void btnConsultantCompanyExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {
            }
        }
        private void txtConsultantCompanyLink_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (txtConsultantCompanyLink.Text == "") return;
                WebBrowserConsultantCompany.Visible = true;
                WebBrowserConsultantCompany.ScriptErrorsSuppressed = true;
                WebBrowserConsultantCompany.Navigate(txtConsultantCompanyLink.Text);
            }
            catch { }
        }
        private void ShowCountConsultantCompany(SqlConnection DBConn)
        {
            try
            {
                Int64 xConCompanyCountCurrMonth = 0;
                Int64 xConCompanyCountPrevMonth = 0;
                string xCurMonth = DateTime.Now.ToString("yyyyMM");

                DateTime previousMonthDate = DateTime.Now.AddMonths(-1);
                string xPrevMonth = previousMonthDate.ToString("yyyyMM");

                ConsultantCompanys.GetListCountFortMonth(DBConn, xCurMonth, out xConCompanyCountCurrMonth);
                ConsultantCompanys.GetListCountFortMonth(DBConn, xPrevMonth, out xConCompanyCountPrevMonth);
                lblConsultantCompanyPrevMonth.Text = "Consultant Company Count for Previous Month : " + xPrevMonth + " : " + xConCompanyCountPrevMonth;
                lblConsultantCompanyCurrMonth.Text = "Consultant Company Count for Current Month : " + xCurMonth + " : " + xConCompanyCountCurrMonth; ;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion
    }
}





