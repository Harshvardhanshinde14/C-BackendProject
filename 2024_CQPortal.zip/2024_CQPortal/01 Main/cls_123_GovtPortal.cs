﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CQPortal
{
   public static class GovtPortals
    {
        public static List<GovtPortal> mLst = new List<GovtPortal>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<GovtPortal> xLst)
        {
            //xID,xName,xLink,xSeqNo,xFlag,xDateTimeStamp
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xName + "','" + xLst[n].xLink + "'," + xLst[n].xSeqNo +",'" + xLst[n].xFlag + "','" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)//xSeqNo,xDateTimeStamp
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_GovtPortal (xID,xName,xLink,xSeqNo,xFlag,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_GovtPortal");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_GovtPortal WHERE xID = '" + xID + "' ") == false) return;
                GovtPortal xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<GovtPortal> { xT });
            }
            catch { }
        }
        public static List<GovtPortal> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<GovtPortal> xRetLst = new List<GovtPortal>();
                while (oReader.Read())
                {
                    //xID,xName,xLink,xSeqNo,xFlag,xDateTimeStamp
                    GovtPortal xT = new GovtPortal();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xName = oReader["xName"].ToString().Trim();
                    xT.xLink = oReader["xLink"].ToString().Trim();
                    xT.xSeqNo =Convert.ToInt32( oReader["xSeqNo"].ToString().Trim());
                    xT.xFlag = Convert.ToBoolean(oReader["xFlag"].ToString().Trim());
                    xT.xDateTimeStamp = oReader["xDateTimeStamp"].ToString().Trim();
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<GovtPortal>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<GovtPortal>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_GovtPortal";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_GovtPortal WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                xPopTV(TV);
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID()
        {
            try
            {
                List<GovtPortal> xLst = mLst.FindAll(p => p.xID.Length == 6).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<GovtPortal> xLst = mLst.OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static GovtPortal xGetByID(string xID)
        {
            try
            {
                GovtPortal xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new GovtPortal();
                return xT;
            }
            catch { return new GovtPortal(); }
        }
        #endregion

        #region Add Update
        public static void xAdd(SqlConnection DBConn, TreeView TV, TextBox txtName,TextBox txtLink,CheckBox chkFlag)
        {
            try
            {                      //xID,xName,xLink,xSeqNo,xFlag,xDateTimeStamp
                if (txtName.Text.Trim() == "" || txtName.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                GovtPortal xxT = mLst.Find(p => p.xName.ToLower() == txtName.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Name is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

                GovtPortal xT = new GovtPortal();
                xT.xID = xGetNewID();
                xT.xName =txtName.Text.Trim();
                xT.xLink = txtLink.Text.Trim();
                xT.xSeqNo = xGetNewSeqNo();
                xT.xFlag = chkFlag.Checked;
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static bool xValidate(SqlConnection DBConn, TreeView TV, TextBox txtName, TextBox txtLink, CheckBox chkFlag, out string ErrorMessage)
        {
            ErrorMessage = string.Empty;
            bool isValid = true;

            // Check for empty fields
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                ErrorMessage += "Name is required.\n";
                isValid = false;
            }
           
            if (string.IsNullOrWhiteSpace(txtLink.Text))
            {
                ErrorMessage += "Link is required.\n";
                isValid = false;
            }
            return isValid;
        }
        public static void xUpdate(SqlConnection DBConn, TreeView TV,string xID, TextBox txtName, TextBox txtLink, CheckBox chkFlag)
        {
            try
            {
                if (txtName.Text.Trim() == "" || txtName.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                GovtPortal xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xName = txtName.Text.Trim();
                xT.xLink = txtLink.Text.Trim();
                xT.xFlag = chkFlag.Checked;
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<GovtPortal> xLst = mLst.OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst.Count; i++)
                {
                    TV.Nodes.Add(xLst[i].xID, xLst[i].xName);
                }
            }
            catch { }
            finally { TV.EndUpdate(); } 
        }
        public static void xPopInRev(string xID, TextBox txtName,  TextBox txtLink,CheckBox chkFlag)
        {
            try
            {
                GovtPortal xT = xGetByID(xID);
                txtName.Text = xT.xName;
                txtLink.Text = xT.xLink;
                chkFlag.Checked = xT.xFlag;
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown(SqlConnection DBConn, TreeView TV, bool MoveUp) 
        {
            try
            {
                if (TV.SelectedNode == null) return;
                string xID = TV.SelectedNode.Name;
                List<GovtPortal> xLst = new List<GovtPortal>();
                xLst = mLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xID];
            }
            catch { }
        }
        #endregion

    }
}
