﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Globalization;
using static System.Windows.Forms.AxHost;
using CQPortal;


namespace CQPortal
{
    public static class Newss
    {

        public static List<News> mLst = new List<News>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<News> xLst)
        {
            // xID,xTitle,xSubTitle,xSource,xLinkAdd,xDate
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xTitle + "','" + xLst[n].xSubTitle + "','" + xLst[n].xSource + "','" + xLst[n].xLinkAdd + "'," + xLst[n].xDate + ",'" + xLst[n].xFlag +"','" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_News (xID,xTitle,xSubTitle,xSource,xLinkAdd,xDate,xFlag,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
     
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_News WHERE xID = '" + xID + "' ") == false) return;
                News xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<News> { xT });
            }
            catch { }
        }
        public static void UpLoadList(SqlConnection DBConn, List<News> xLst)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_News") == false) return;
                mLst = xLst;
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static List<News> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<News> xRetLst = new List<News>();
                while (oReader.Read())
                {
                    // xID,xTitle,xSubTitle,xSource,xLinkAdd,xDate
                    News xT = new News();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xTitle = oReader["xTitle"].ToString().Trim();
                    xT.xSubTitle = oReader["xSubTitle"].ToString().Trim(); ;
                    xT.xSource = oReader["xSource"].ToString().Trim();
                    xT.xLinkAdd = oReader["xLinkAdd"].ToString().Trim();
                    xT.xDate = oReader["xDate"].ToString().Trim();
                    xT.xFlag =Convert.ToBoolean( oReader["xFlag"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<News>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<News>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_News";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static List<News> DownLoadByDateDescTop10(SqlConnection DBConn,  String xDate)
        {
            try
            {
                List<News> xRetLst = new List<News>();
                string xSQL = @"SELECT TOP 20 * FROM dbo.CQ_Portal_News WHERE xDate <= '" + xDate + "'";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    return xRetLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
                return new List<News>();
            }
        }
        public static void xDelete(SqlConnection DBConn,TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_News WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                Newss.xPopTV(TV);
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID6()
        {
            try
            {
                List<News> xLst = mLst.FindAll(p => p.xID.Length == 6).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static News xGetByID(string xID)
        {
            try
            {
                News xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new News();
                return xT;
            }
            catch { return new News(); }
        }
      
        #endregion

        #region Add Update        

        public static void xAdd6(SqlConnection DBConn,TreeView TV, TextBox txtTitle, TextBox txtSubTitle,  TextBox txtSource, TextBox txtLinkAddress, string xDate,CheckBox  chkLinkFlag)
        {
            try
            {
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Title");
                    return;
                }
                News xxT = mLst.Find(p => p.xTitle.ToLower() == txtTitle.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Title Name is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                if (txtSource.Text.Trim() == "" || txtSource.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Source");
                    return;
                }
                if (txtLinkAddress.Text.Trim() == "" || txtLinkAddress.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Link Address");
                    return;
                }
                News xT = new News();
                xT.xID = xGetNewID6();
                xT.xTitle = txtTitle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xSource = txtSource.Text.Trim();
                xT.xLinkAdd = txtLinkAddress.Text.Trim();
                xT.xDate =   xDate;
                xT.xFlag = chkLinkFlag.Checked;
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xDate.ToString()].Nodes[xT.xID];
            }
            catch { }
        }

        public static bool xValidate(SqlConnection DBConn,TreeView TV, TextBox txtTitle, TextBox txtSubTitle, TextBox txtSource, TextBox txtLinkAddress, string xDate, CheckBox  chkLinkFlag, out string ErrorMessage)
        {
            ErrorMessage = string.Empty;
            bool isValid = true;
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                ErrorMessage += "Title is required.\n";
                isValid = false;
            }         
            if (string.IsNullOrWhiteSpace(txtLinkAddress.Text))
            {
                ErrorMessage += "LinkAddress is required.\n";
                isValid = false;
            }
            return isValid;
        }
        public static void xUpdate6(SqlConnection DBConn,TreeView TV,string xID, TextBox txtTitle, TextBox txtSubTitle, TextBox txtSource, TextBox txtLinkAddress, string xDate,CheckBox chkFlag)
        {
            try
            {
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Title");
                    return;
                }
                if (txtSource.Text.Trim() == "" || txtSource.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Source");
                    return;
                }
                if (txtLinkAddress.Text.Trim() == "" || txtLinkAddress.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Link Address");
                    return;
                }
                News xT = xGetByID(xID);
                if(xT == null) { return; }
                xT.xTitle = txtTitle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xSource = txtSource.Text.Trim();
                xT.xLinkAdd = txtLinkAddress.Text.Trim();
                xT.xDate = xDate;
                xT.xFlag=chkFlag.Checked;
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xDate].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xAddDefault(SqlConnection DBConn)
        {
            try
            {
                List<News> xLstRet = new List<News>();
                xLstRet.Add(new News("101101", "google.com1", "google.com2", "Google3", "https://www.google.com/", "20240327",false));
                xLstRet.Add(new News("101102", "CalQuan.com1", "CalQuan2", "CalQuan3", "https://www.calquan.com/", "20240327",false));
                xLstRet.Add(new News("101103", "yahoo.com1", "Yahoo2", "Yahoo3", "https://www.yahoo.com/?guccounter=1", "20240327", false));
                xLstRet.Add(new News("101104", "LinkedIn1", "LinkedIn2", "LinkedIn3", "https://www.linkedin.com/", "20240327", false));
                xLstRet.Add(new News("101105", "OShO1", "OShO2", "OShO3", "https://www.osho.com/", "20240327", false));
                UpLoadList(DBConn, xLstRet);
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<string> xLst3 = mLst.Select(p => p.xDate).OrderByDescending(p=>p).Distinct().ToList();
                for(int i=0;i<xLst3.Count;i++)
                {
                   TreeNode xNode= TV.Nodes.Add(xLst3[i], xLst3[i]);
                    List<News> xxLstDate = mLst.FindAll(p => p.xDate == xLst3[i]);
                    for (int j = 0; j < xxLstDate.Count; j++)
                    {
                        xNode.Nodes.Add(xxLstDate[j].xID, xxLstDate[j].xTitle);

                    }
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID, TextBox txtTitle, TextBox txtSubTitle, TextBox txtSource, TextBox txtLinkAddress, TextBox txtDate,CheckBox chkFlag)
        {
            try
            {
                News xT = xGetByID(xID);
                txtTitle.Text = xT.xTitle;
                txtSubTitle.Text = xT.xSubTitle;
                txtSource.Text = xT.xSource;
                txtLinkAddress.Text = xT.xLinkAdd;
                txtDate.Text = Functions.DBToDotDate(xT.xDate);
                chkFlag.Checked = xT.xFlag;
            }
            catch { }
        }
        public static void PopDGV(SqlConnection DBConn,  DataGridView DGV, string xDate)
        {

            try
            {
                PopSetGrid(DGV);
                List<News> xLst = DownLoadByDateDescTop10(DBConn,  xDate).OrderByDescending(p=>p.xDate).ToList();
                foreach (News x in xLst)
                {
                    DGV.Rows.Add(x.xID, x.xDate, x.xTitle,x.xSource,x.xLinkAdd);
                }
            }
            catch(Exception ex) { MessageBox.Show(ex.Message); }
        }
        public static void PopSetGrid(DataGridView DGV)
        {
            try
            {  // xID,Date,Title,source,LinkAdd
                DGV.Columns.Clear();
                DataGridViewTextBoxColumn xColID = new DataGridViewTextBoxColumn();
                xColID.HeaderText = "xID";
                xColID.Width = 100;
                xColID.DisplayIndex = 0;
                DGV.Columns.Add(xColID);

                DataGridViewTextBoxColumn xColDate = new DataGridViewTextBoxColumn();
                xColDate.HeaderText = "Date";
                xColDate.Width = 200;
                xColDate.DisplayIndex = 1;
                DGV.Columns.Add(xColDate);

                DataGridViewTextBoxColumn xColTitle = new DataGridViewTextBoxColumn();
                xColTitle.HeaderText = "Title";
                xColTitle.Width = 500;
                xColTitle.DisplayIndex = 2;
                DGV.Columns.Add(xColTitle);

                DataGridViewTextBoxColumn xColSource = new DataGridViewTextBoxColumn();
                xColSource.HeaderText = "Source";
                xColSource.Width = 200;
                xColSource.DisplayIndex = 3;
                DGV.Columns.Add(xColSource);

                DataGridViewTextBoxColumn xColLinkAdd = new DataGridViewTextBoxColumn();
                xColLinkAdd.HeaderText = "LinkAdd";
                xColLinkAdd.Width = 200;
                xColLinkAdd.DisplayIndex = 4;
                DGV.Columns.Add(xColLinkAdd);

                DGV.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
                DGV.Columns[1].SortMode = DataGridViewColumnSortMode.NotSortable;
                DGV.Columns[2].SortMode = DataGridViewColumnSortMode.NotSortable;
                DGV.Columns[3].SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            catch (Exception)
            {

            }
        }
        #endregion
    }
}
