﻿namespace CQPortal
{
    partial class frmContactUs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContactUs));
            this.mOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.tabContactUs = new System.Windows.Forms.TabPage();
            this.splitContainer22 = new System.Windows.Forms.SplitContainer();
            this.btnGetQuot = new System.Windows.Forms.Button();
            this.btnContactUs = new System.Windows.Forms.Button();
            this.btnContactExit = new System.Windows.Forms.Button();
            this.splitContainer23 = new System.Windows.Forms.SplitContainer();
            this.TVContact = new System.Windows.Forms.TreeView();
            this.lblTVTitle = new System.Windows.Forms.Label();
            this.txtContactCompany = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtContactMessage = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtContactPhno = new System.Windows.Forms.TextBox();
            this.txtContactName = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtContactSubject = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtContactCity = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtContactEmail = new System.Windows.Forms.TextBox();
            this.TC = new System.Windows.Forms.TabControl();
            this.tabContactUs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer22)).BeginInit();
            this.splitContainer22.Panel1.SuspendLayout();
            this.splitContainer22.Panel2.SuspendLayout();
            this.splitContainer22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer23)).BeginInit();
            this.splitContainer23.Panel1.SuspendLayout();
            this.splitContainer23.Panel2.SuspendLayout();
            this.splitContainer23.SuspendLayout();
            this.TC.SuspendLayout();
            this.SuspendLayout();
            // 
            // mOpenFile
            // 
            this.mOpenFile.FileName = "mOpenFile";
            // 
            // tabContactUs
            // 
            this.tabContactUs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabContactUs.Controls.Add(this.splitContainer22);
            this.tabContactUs.Location = new System.Drawing.Point(4, 22);
            this.tabContactUs.Name = "tabContactUs";
            this.tabContactUs.Padding = new System.Windows.Forms.Padding(3);
            this.tabContactUs.Size = new System.Drawing.Size(1076, 469);
            this.tabContactUs.TabIndex = 9;
            this.tabContactUs.Text = "ContactUs";
            this.tabContactUs.UseVisualStyleBackColor = true;
            // 
            // splitContainer22
            // 
            this.splitContainer22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer22.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer22.IsSplitterFixed = true;
            this.splitContainer22.Location = new System.Drawing.Point(3, 3);
            this.splitContainer22.Name = "splitContainer22";
            this.splitContainer22.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer22.Panel1
            // 
            this.splitContainer22.Panel1.Controls.Add(this.btnGetQuot);
            this.splitContainer22.Panel1.Controls.Add(this.btnContactUs);
            this.splitContainer22.Panel1.Controls.Add(this.btnContactExit);
            // 
            // splitContainer22.Panel2
            // 
            this.splitContainer22.Panel2.Controls.Add(this.splitContainer23);
            this.splitContainer22.Size = new System.Drawing.Size(1256, 463);
            this.splitContainer22.SplitterDistance = 60;
            this.splitContainer22.TabIndex = 3;
            // 
            // btnGetQuot
            // 
            this.btnGetQuot.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetQuot.Location = new System.Drawing.Point(132, 20);
            this.btnGetQuot.Name = "btnGetQuot";
            this.btnGetQuot.Size = new System.Drawing.Size(100, 25);
            this.btnGetQuot.TabIndex = 223;
            this.btnGetQuot.Text = "Get Quotation";
            this.btnGetQuot.UseVisualStyleBackColor = true;
            this.btnGetQuot.Click += new System.EventHandler(this.btnGetQuot_Click);
            // 
            // btnContactUs
            // 
            this.btnContactUs.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactUs.Location = new System.Drawing.Point(26, 20);
            this.btnContactUs.Name = "btnContactUs";
            this.btnContactUs.Size = new System.Drawing.Size(100, 25);
            this.btnContactUs.TabIndex = 31;
            this.btnContactUs.Text = "Contact Us";
            this.btnContactUs.UseVisualStyleBackColor = true;
            this.btnContactUs.Click += new System.EventHandler(this.btnContactUsShow_Click);
            // 
            // btnContactExit
            // 
            this.btnContactExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactExit.Location = new System.Drawing.Point(937, 20);
            this.btnContactExit.Name = "btnContactExit";
            this.btnContactExit.Size = new System.Drawing.Size(100, 25);
            this.btnContactExit.TabIndex = 30;
            this.btnContactExit.Text = "Exit";
            this.btnContactExit.UseVisualStyleBackColor = true;
            this.btnContactExit.Click += new System.EventHandler(this.btnContactExit_Click);
            // 
            // splitContainer23
            // 
            this.splitContainer23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer23.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer23.IsSplitterFixed = true;
            this.splitContainer23.Location = new System.Drawing.Point(0, 0);
            this.splitContainer23.Name = "splitContainer23";
            // 
            // splitContainer23.Panel1
            // 
            this.splitContainer23.Panel1.Controls.Add(this.TVContact);
            this.splitContainer23.Panel1.Controls.Add(this.lblTVTitle);
            // 
            // splitContainer23.Panel2
            // 
            this.splitContainer23.Panel2.Controls.Add(this.txtContactCompany);
            this.splitContainer23.Panel2.Controls.Add(this.label29);
            this.splitContainer23.Panel2.Controls.Add(this.label31);
            this.splitContainer23.Panel2.Controls.Add(this.txtContactMessage);
            this.splitContainer23.Panel2.Controls.Add(this.label28);
            this.splitContainer23.Panel2.Controls.Add(this.txtContactPhno);
            this.splitContainer23.Panel2.Controls.Add(this.txtContactName);
            this.splitContainer23.Panel2.Controls.Add(this.label30);
            this.splitContainer23.Panel2.Controls.Add(this.txtContactSubject);
            this.splitContainer23.Panel2.Controls.Add(this.label17);
            this.splitContainer23.Panel2.Controls.Add(this.label27);
            this.splitContainer23.Panel2.Controls.Add(this.txtContactCity);
            this.splitContainer23.Panel2.Controls.Add(this.label25);
            this.splitContainer23.Panel2.Controls.Add(this.txtContactEmail);
            this.splitContainer23.Size = new System.Drawing.Size(1256, 399);
            this.splitContainer23.SplitterDistance = 300;
            this.splitContainer23.TabIndex = 0;
            // 
            // TVContact
            // 
            this.TVContact.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVContact.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVContact.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVContact.FullRowSelect = true;
            this.TVContact.HideSelection = false;
            this.TVContact.Location = new System.Drawing.Point(0, 25);
            this.TVContact.Name = "TVContact";
            this.TVContact.Size = new System.Drawing.Size(298, 372);
            this.TVContact.TabIndex = 28;
            this.TVContact.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVContact.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVContact_MouseDoubleClick);
            // 
            // lblTVTitle
            // 
            this.lblTVTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTVTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTVTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTVTitle.Location = new System.Drawing.Point(0, 0);
            this.lblTVTitle.Name = "lblTVTitle";
            this.lblTVTitle.Size = new System.Drawing.Size(298, 25);
            this.lblTVTitle.TabIndex = 38;
            this.lblTVTitle.Text = "Contact Us";
            this.lblTVTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContactCompany
            // 
            this.txtContactCompany.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactCompany.Location = new System.Drawing.Point(388, 84);
            this.txtContactCompany.Name = "txtContactCompany";
            this.txtContactCompany.Size = new System.Drawing.Size(373, 22);
            this.txtContactCompany.TabIndex = 227;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(391, 66);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(62, 16);
            this.label29.TabIndex = 226;
            this.label29.Text = "Company";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(22, 225);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(60, 16);
            this.label31.TabIndex = 224;
            this.label31.Text = "Message";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContactMessage
            // 
            this.txtContactMessage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactMessage.Location = new System.Drawing.Point(19, 243);
            this.txtContactMessage.Multiline = true;
            this.txtContactMessage.Name = "txtContactMessage";
            this.txtContactMessage.Size = new System.Drawing.Size(742, 236);
            this.txtContactMessage.TabIndex = 225;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(22, 15);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(41, 16);
            this.label28.TabIndex = 28;
            this.label28.Text = "Name";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContactPhno
            // 
            this.txtContactPhno.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactPhno.Location = new System.Drawing.Point(388, 136);
            this.txtContactPhno.Name = "txtContactPhno";
            this.txtContactPhno.Size = new System.Drawing.Size(373, 22);
            this.txtContactPhno.TabIndex = 223;
            // 
            // txtContactName
            // 
            this.txtContactName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactName.Location = new System.Drawing.Point(19, 33);
            this.txtContactName.Name = "txtContactName";
            this.txtContactName.Size = new System.Drawing.Size(742, 22);
            this.txtContactName.TabIndex = 29;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(391, 118);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(68, 16);
            this.label30.TabIndex = 222;
            this.label30.Text = "Phone No.";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContactSubject
            // 
            this.txtContactSubject.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactSubject.Location = new System.Drawing.Point(19, 187);
            this.txtContactSubject.Name = "txtContactSubject";
            this.txtContactSubject.Size = new System.Drawing.Size(742, 22);
            this.txtContactSubject.TabIndex = 37;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(22, 66);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 16);
            this.label17.TabIndex = 38;
            this.label17.Text = "City";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(22, 118);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 16);
            this.label27.TabIndex = 34;
            this.label27.Text = "Email";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContactCity
            // 
            this.txtContactCity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactCity.Location = new System.Drawing.Point(19, 84);
            this.txtContactCity.Name = "txtContactCity";
            this.txtContactCity.Size = new System.Drawing.Size(363, 22);
            this.txtContactCity.TabIndex = 39;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(22, 169);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 16);
            this.label25.TabIndex = 36;
            this.label25.Text = "Subject";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtContactEmail
            // 
            this.txtContactEmail.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactEmail.Location = new System.Drawing.Point(19, 136);
            this.txtContactEmail.Name = "txtContactEmail";
            this.txtContactEmail.Size = new System.Drawing.Size(363, 22);
            this.txtContactEmail.TabIndex = 35;
            // 
            // TC
            // 
            this.TC.Controls.Add(this.tabContactUs);
            this.TC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TC.Location = new System.Drawing.Point(0, 0);
            this.TC.Name = "TC";
            this.TC.SelectedIndex = 0;
            this.TC.Size = new System.Drawing.Size(1084, 495);
            this.TC.TabIndex = 0;
            // 
            // frmContactUs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1084, 495);
            this.Controls.Add(this.TC);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmContactUs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CQ_Portal";
            this.Load += new System.EventHandler(this.frmContactUs_Load);
            this.tabContactUs.ResumeLayout(false);
            this.splitContainer22.Panel1.ResumeLayout(false);
            this.splitContainer22.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer22)).EndInit();
            this.splitContainer22.ResumeLayout(false);
            this.splitContainer23.Panel1.ResumeLayout(false);
            this.splitContainer23.Panel2.ResumeLayout(false);
            this.splitContainer23.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer23)).EndInit();
            this.splitContainer23.ResumeLayout(false);
            this.TC.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog mOpenFile;
        private System.Windows.Forms.TabPage tabContactUs;
        private System.Windows.Forms.SplitContainer splitContainer22;
        private System.Windows.Forms.Button btnContactUs;
        private System.Windows.Forms.Button btnContactExit;
        private System.Windows.Forms.SplitContainer splitContainer23;
        private System.Windows.Forms.TreeView TVContact;
        private System.Windows.Forms.TextBox txtContactCompany;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtContactMessage;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtContactPhno;
        private System.Windows.Forms.TextBox txtContactName;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtContactSubject;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtContactCity;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtContactEmail;
        private System.Windows.Forms.TabControl TC;
        private System.Windows.Forms.Button btnGetQuot;
        private System.Windows.Forms.Label lblTVTitle;
    }
}

