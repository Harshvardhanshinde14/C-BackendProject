﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.IO;
using System.Security.Cryptography;
using System.Xml.Linq;
using System.Diagnostics;

namespace CQPortal
{
    public static class SuccessFulStoriess
    {
        public static List<SuccessFulStories> mLst = new List<SuccessFulStories>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<SuccessFulStories> xLst)
        {
            //  // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xTiltle.Replace("'", "''") + "','" + xLst[n].xSubTitle.Replace("'", "''") + "','" + xLst[n].xDesc.Replace("'", "''") + "','" + xLst[n].xCompanyName.Replace("'", "''") + "','" + xLst[n].xPhotoName.Replace("'", "''") + "','" + xLst[n].xLogoName.Replace("'", "''") + "'," + xLst[n].xSeqNo + ",'" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)  // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_SuccessFulStories(xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp) VALUES"
                      + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_SuccessFulStories");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_SuccessFulStories WHERE xID = '" + xID + "' ") == false) return;
                SuccessFulStories xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<SuccessFulStories> { xT });
            }
            catch { }
        }
        public static void UpLoadList(SqlConnection DBConn, List<SuccessFulStories> xLst)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_SuccessFulStories") == false) return;
                mLst = xLst;
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static List<SuccessFulStories> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp
                List<SuccessFulStories> xRetLst = new List<SuccessFulStories>();
                while (oReader.Read())
                {
                    SuccessFulStories xT = new SuccessFulStories();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xTiltle = oReader["xTiltle"].ToString().Trim();
                    xT.xSubTitle = oReader["xSubTitle"].ToString().Trim();
                    xT.xDesc = oReader["xDesc"].ToString().Trim();
                    xT.xCompanyName = oReader["xCompanyName"].ToString().Trim();
                    xT.xPhotoName = oReader["xPhotoName"].ToString().Trim();
                    xT.xLogoName = oReader["xLogoName"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xT.xDateTimeStamp = oReader["xDateTimeStamp"].ToString().Trim();
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<SuccessFulStories>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<SuccessFulStories>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_SuccessFulStories";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                if (xID.Length == 3)
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_SuccessFulStories WHERE LEFT(xID,3) ='" + xID + "' ");
                    mLst.RemoveAll(p => p.xID.Substring(0, 3) == xID);
                    xPopTV(TV);
                }
                else
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_SuccessFulStories WHERE xID ='" + xID + "' ");
                    mLst.RemoveAll(p => p.xID == xID);
                    xPopTV(TV);
                    TV.SelectedNode = TV.Nodes[xID.Substring(0, 3)];
                    TV.SelectedNode.ExpandAll();
                }
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID6(string xID)
        {
            try
            {
                List<SuccessFulStories> xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return xID + "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static string xGetNewID3()
        {
            try
            {
                List<SuccessFulStories> xLst = mLst.FindAll(p => p.xID.Length == 3).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo3()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<SuccessFulStories> xLst = mLst.FindAll(p => p.xID.Length == 3).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        private static Int32 xGetNewSeqNo6(string xID3)
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<SuccessFulStories> xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID3).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static SuccessFulStories xGetByID(string xID)
        {
            try
            {
                SuccessFulStories xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new SuccessFulStories();
                return xT;
            }
            catch { return new SuccessFulStories(); }
        }
        public static List<SuccessFulStories> xGetList3()
        {
            try
            {
                return mLst.FindAll(p => p.xID.Length == 3).ToList();
            }
            catch { return new List<SuccessFulStories>(); }
        }
        public static List<SuccessFulStories> xGetList6(string xID3)
        {
            try
            {
                return mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID3).ToList();
            }
            catch { return new List<SuccessFulStories>(); }
        }
        public static string xGetNameByID(string xID)
        {
            try
            {
                SuccessFulStories xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return null;
                return xT.xTiltle;
            }
            catch { return null; }
        }
    
        #endregion

        #region Add Update
        public static void xAdd3(SqlConnection DBConn, TreeView TV, TextBox txtTiltle, TextBox txtSubTitle)
        {
            try
            // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp

            {
                if (txtTiltle.Text.Trim() == "" || txtTiltle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                SuccessFulStories xxT = mLst.Find(p => p.xID.Length == 3 && p.xTiltle.ToLower() == txtTiltle.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Title Name is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

                SuccessFulStories xT = new SuccessFulStories();
                xT.xID = xGetNewID3();
                xT.xSeqNo = xGetNewSeqNo3();
                xT.xTiltle = txtTiltle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xDesc = "-";
                xT.xCompanyName = "-";
                xT.xPhotoName = "-";
                xT.xLogoName = "-";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static void xUpdate3(SqlConnection DBConn, TreeView TV, string xID, TextBox txtTiltle, TextBox txtSubTitle)
        {
            try
            // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp

            {
                if (txtTiltle.Text.Trim() == "" || txtTiltle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Title");
                    return;
                }
                SuccessFulStories xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xTiltle = txtTiltle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xDesc = "-";
                xT.xCompanyName = "-";
                xT.xPhotoName = "-";
                xT.xLogoName = "-";
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static void xAdd6(SqlConnection DBConn, TreeView TV,TextBox txtTiltle, TextBox txtSubTitle, TextBox txtDesc, TextBox txtCompanyName)
        {
            try
            // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp

            {
                if (TV.SelectedNode == null) return;
                string xID3 = "";
                if (TV.SelectedNode.Level == 0) xID3 = TV.SelectedNode.Name;
                else
                {
                    xID3 = TV.SelectedNode.Parent.Name;
                }
                if (txtTiltle.Text.Trim() == "")
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                SuccessFulStories xxT = mLst.Find(p => p.xTiltle.ToLower() == txtTiltle.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Title Name is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                SuccessFulStories xT = new SuccessFulStories();
                xT.xID = xGetNewID6(xID3);
                xT.xSeqNo = xGetNewSeqNo6(xID3);
                xT.xTiltle = txtTiltle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xCompanyName = txtCompanyName.Text.Trim();
                xT.xPhotoName = "-";
                xT.xLogoName = "-";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xUpdate6(SqlConnection DBConn, TreeView TV, string xID, TextBox txtTiltle, TextBox txtSubTitle, TextBox txtDesc, TextBox txtCompanyName)
        {
            try
            {
                if (txtTiltle.Text.Trim() == "" || txtTiltle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Title");
                    return;
                }
                SuccessFulStories xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xTiltle = txtTiltle.Text.Trim();
                xT.xSubTitle = txtSubTitle.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xCompanyName = txtCompanyName.Text.Trim();
                xT.xPhotoName = "-";
                xT.xLogoName = "-";
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xUpdatePhoto(SqlConnection DBConn, string xID, string xPhotoName)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "UPDATE dbo.CQ_Portal_SuccessFulStories SET xPhotoName = '" + xPhotoName + "' WHERE xID = '" + xID + "' ") == true)
                {
                    SuccessFulStories xT = xGetByID(xID);
                    xT.xPhotoName = xPhotoName;
                }
            }
            catch { }
        }
        public static void xUpdateLogo(SqlConnection DBConn, string xID, string xLogoName)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "UPDATE dbo.CQ_Portal_SuccessFulStories SET xLogoName = '" + xLogoName + "' WHERE xID = '" + xID + "' ") == true)
                {
                    SuccessFulStories xT = xGetByID(xID);
                    xT.xLogoName = xLogoName;
                }
            }
            catch { }
        }
        //public static void xAddDefault(SqlConnection DBConn)
        //{
        //    try
        //    {
        //        List<SuccessFulStories> xLstRet = new List<SuccessFulStories>();
        //        xLstRet.Add(new SuccessFulStories("101", "aa", "aa", "-", "aa", "", "", 1, false));
        //        xLstRet.Add(new SuccessFulStories("101101", "NCC", "NCC", "-", "NCC", "", "", 1, false));
        //        xLstRet.Add(new SuccessFulStories("102", "HCC", "HCC", "-", "HCC", "", "", 2, false));
        //        xLstRet.Add(new SuccessFulStories("102101", "HCC", "HCC", "-", "HCC", "", "", 1, false));
        //        xLstRet.Add(new SuccessFulStories("102102", "twitter", "twitter", "-", "", "", "", 2, false));
        //        xLstRet.Add(new SuccessFulStories("102103", "Microsoft Bing", "Microsoft Bing", "-", "", "", "", 3, false));

        //        UpLoadList(DBConn, xLstRet);
        //    }
        //    catch { }
        //}
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<SuccessFulStories> xLst3 = mLst.FindAll(p => p.xID.Length == 3).OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst3.Count; i++)
                {
                    TreeNode xNode3 = TV.Nodes.Add(xLst3[i].xID, xLst3[i].xTiltle);
                    xPopTVNodes(xNode3);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopTVNodes(TreeNode xNode)
        {
            try
            {
                xNode.Nodes.Clear();
                List<SuccessFulStories> xLst6 = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xNode.Name).OrderBy(p => p.xSeqNo).ToList();

                for (int j = 0; j < xLst6.Count; j++)
                {
                    xNode.Nodes.Add(xLst6[j].xID, xLst6[j].xTiltle);
                }
            }
            catch { }
        }
        public static void xPopInRev(string xID, TextBox txtTiltle, TextBox txtSubTitle, TextBox txtDesc, TextBox txtCompanyName)
        {
            try
            {
                // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp
                SuccessFulStories xT = xGetByID(xID);
                txtTiltle.Text = xT.xTiltle;
                txtSubTitle.Text = xT.xSubTitle;
                txtDesc.Text = xT.xDesc;
                txtCompanyName.Text = xT.xCompanyName;
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown3(SqlConnection DBConn, TreeView TV, bool MoveUp)
        {
            try
            {
                if (TV.SelectedNode == null || TV.SelectedNode.Level != 0) return;
                string xID3 = TV.SelectedNode.Name;
                List<SuccessFulStories> xLst = new List<SuccessFulStories>();
                if (xID3.Length != 3) return;
                xLst = mLst.FindAll(p => p.xID.Length == 3);
                if (xLst.Count < 2) return;
                xLst = xLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID3) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID3)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID3);
            }
            catch { }
        }
        public static void UpOrDown6(SqlConnection DBConn, TreeView TV, bool MoveUp) //xSeqNo
        {
            try
            {
                if (TV.SelectedNode == null) return;
                if (TV.SelectedNode.Level != 1) return;
                string xID = TV.SelectedNode.Name;
                List<SuccessFulStories> xLst = new List<SuccessFulStories>();
                if (xID.Length != 6) return;
                xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID.Substring(0, 3)).OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())//check any duplicate
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID);
            }
            catch { }
        }
        #endregion

        //#region ReadWrite
        //public static bool xWrite(bool xOpen = true)
        //{
        //    try
        //    {
        //        //xID,xName,xShortName,xDesc,xCompanyLink,xLogoName,xSeqNo
        //        SuccessFulStories xT = new SuccessFulStories();
        //        string xFileName = CQBVar.xPath + "\\" + "101_Companies_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
        //        string xData = "";
        //        StringBuilder SB = new StringBuilder();
        //        // xID,xName,xShortName,xDesc,xCity,xCompanyLink,xCompanyOpeningLink,xLogoName,xSeqNo,xFlag,xDateTimeStamp
        //        xData = "xID,xName,xShortName,xDesc,xCompanyLink,xLogoName,xSeqNo";
        //        SB.AppendLine(xData);
        //        List<SuccessFulStories> xLst = mLst.OrderBy(p => p.xID).ToList();
        //        for (int i = 0; i < xLst.Count; i++)
        //        {
        //            xData = xLst[i].xID + "," + xLst[i].xName + "," + xLst[i].xShortName + "," + xLst[i].xDesc + "," + xLst[i].xCompanyLink + "," + xLst[i].xLogoName + "," + xLst[i].xSeqNo;
        //            SB.AppendLine(xData);
        //        }
        //        StreamWriter xWriter = new StreamWriter(xFileName);
        //        xWriter.Write(SB);
        //        xWriter.Close();
        //        if (xOpen != false) System.Diagnostics.Process.Start(xFileName);
        //        return true;
        //    }
        //    catch (Exception ex) { MessageBox.Show(ex.Message); return false; }
        //}
        //public static Boolean xRead(SqlConnection DBConn, string xFileName)
        //{
        //    try
        //    {
        //        StreamReader xReader = new StreamReader(xFileName);
        //        string xLine = "";
        //        //xID,xName,xShortName,xDesc,xCompanyLink,xLogoName,xSeqNo
        //        string[] xText;
        //        mLst.Clear();
        //        Int32 i = 100;
        //        xReader.ReadLine(); // skip header row
        //        do
        //        {
        //            xLine = xReader.ReadLine();
        //            if (xLine == null) break;
        //            xText = xLine.Split(',');
        //            if (xText.Count() > 6)
        //            {
        //                SuccessFulStories xT = new SuccessFulStories();
        //                //if (xText[0].Length != 3 || xText[0].Length != 6 || xText[0].Length != 9) continue;
        //                xT.xID = xText[0];
        //                xT.xName = xText[1];
        //                xT.xShortName = xText[2];
        //                xT.xDesc = xText[3];
        //                xT.xCity = xText[4];
        //                xT.xCompanyLink = xText[5];
        //                xT.xLogoName = xText[6];
        //                xT.xSeqNo = Convert.ToInt32(xText[7]);
        //                if (xText[0].Trim().Length == 3 || xText[0].Trim().Length == 6)
        //                {
        //                    if (mLst.Exists(p => p.xID == xText[0].Trim())) continue;
        //                    if (mLst.Exists(p => p.xName.Trim().ToLower() == xText[1].Trim().ToLower())) continue;
        //                    mLst.Add(xT);
        //                }
        //            }
        //        } while (xLine != null);
        //        xReader.Close();
        //        UpLoad(DBConn);
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //        return false;
        //    }
        //}
        //#endregion

    }
}
