﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CQPortal
{
    public static class Placements
    {
        public static List<Placement> mLst = new List<Placement>();

        #region ULDL
        public static List<Placement> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<Placement> xRetLst = new List<Placement>();
                while (oReader.Read())
                {
                    //xName,xEmail,xPhoneNo,xAge,xEducation,xExperience,xMessage,xFileName,xCVPdfORImage
                    Placement xT = new Placement();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xName = oReader["xName"].ToString().Trim();
                    xT.xEmail = oReader["xEmail"].ToString().Trim();
                    xT.xPhoneNo = oReader["xPhoneNo"].ToString().Trim();
                    xT.xAge = oReader["xAge"].ToString().Trim();
                    xT.xEducation = oReader["xEducation"].ToString().Trim();
                    xT.xExperience = oReader["xExperience"].ToString().Trim();
                    xT.xMessage = oReader["xMessage"].ToString().Trim();
                    xT.xFileName = oReader["xFileName"].ToString().Trim();
                    xT.xCVPdfORImage = oReader["xCVPdfORImage"].ToString().Trim();
                    xT.xDateTimeStamp = oReader["xDateTimeStamp"].ToString().Trim();
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<Placement>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<Placement>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_Placement";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        #endregion

        #region Get
        public static Placement xGetByID(string xID)
        {
            try
            {
                Placement xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new Placement();
                return xT;
            }
            catch { return new Placement(); }
        }
        #endregion

        #region Pop
        public static void xPopTV(SqlConnection DBConn, TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                DownLoad(DBConn);
                List<Placement> xLst = mLst.OrderByDescending(p => p.xDateTimeStamp).ToList(); ;
                for (int i = 0; i < xLst.Count; i++)
                {
                    TV.Nodes.Add(xLst[i].xID, xLst[i].xName + " : " + xLst[i].xDateTimeStamp);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }

        public static void xPopInRev(string xID, TextBox txtName, TextBox txtEmail, TextBox txtPhone, TextBox txtAge, TextBox txtEducation, TextBox txtExperience, TextBox txtMessage, RadioButton rbtnImage, RadioButton rbtnPdf, TextBox txtFileName,Button btnShowImage,Button btnShowPdf)
        {
            try
            {
                //xName,xEmail,xPhoneNo,xAge,xEducation,xExperience,xMessage,xFileName,xCVPdfORImage

                Placement xT = xGetByID(xID);
                txtName.Text = xT.xName;
                txtEmail.Text = xT.xEmail;
                txtPhone.Text = xT.xPhoneNo.ToString();
                txtAge.Text = xT.xAge;
                txtEducation.Text = xT.xEducation;

                txtExperience.Text = xT.xExperience;
                txtMessage.Text = xT.xMessage;
                rbtnImage.Checked = true;
                btnShowImage.Enabled = true;
                btnShowPdf.Enabled = false;
                if (xT.xCVPdfORImage == "0")
                {
                    rbtnPdf.Checked = true;
                    btnShowPdf.Enabled = true;
                    btnShowImage.Enabled = false;
                }
                txtFileName.Text = xT.xFileName;

            }
            catch { }
        }
        #endregion
    }
}
