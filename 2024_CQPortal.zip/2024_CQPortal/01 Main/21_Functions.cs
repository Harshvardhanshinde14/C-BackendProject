﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CQPortal
{
    public class Functions
    {
        public static void TVDrawNode(object sender, DrawTreeNodeEventArgs e)
        {
            if (e.Node == null) return;
            // if treeview's HideSelection property is "True", this will always returns "False" on unfocused treeview
            var selected = (e.State & TreeNodeStates.Selected) == TreeNodeStates.Selected;
            var unfocused = !e.Node.TreeView.Focused;
            // we need to do owner drawing only on a selected node and when the treeview is unfocused, else let the OS do it for us
            if (selected && unfocused)
            {
                var font = e.Node.NodeFont ?? e.Node.TreeView.Font;
                e.Graphics.FillRectangle(System.Drawing.SystemBrushes.Highlight, e.Bounds);
                TextRenderer.DrawText(e.Graphics, e.Node.Text, font, e.Bounds, SystemColors.HighlightText, TextFormatFlags.GlyphOverhangPadding);
            }
            else
            {
                //  var font = e.Node.NodeFont ?? e.Node.TreeView.Font;
                // e.Graphics.FillRectangle(System.Drawing.SystemBrushes.Highlight, e.Bounds);
                // TextRenderer.DrawText(e.Graphics, e.Node.Text, font, e.Bounds, System.Drawing.Color.Black, TextFormatFlags.GlyphOverhangPadding);
                e.DrawDefault = true;
            }
        }
        public static string DBToDotDate(string xDate)
        {
            if (xDate == null || xDate.Length < 6) return "-9999";
            return xDate.Substring(6, 2) + "." + xDate.Substring(4, 2) + "." + xDate.Substring(0, 4);
        }
        public static void xSelectTVNode(TreeView TV, string xID36912)
        {
            try
            {
                if (xID36912.Length == 3)
                {
                    TV.SelectedNode = TV.Nodes[xID36912.ToString()];
                }
                else if (xID36912.Length == 6)
                {
                    TV.SelectedNode = TV.Nodes[xID36912.Substring(0, 3)].Nodes[xID36912.ToString()];
                    TV.Nodes[xID36912.Substring(0, 3)].Expand();
                }
                else if (xID36912.Length == 9)
                {
                    TV.SelectedNode = TV.Nodes[xID36912.Substring(0, 3)].Nodes[xID36912.Substring(0, 6)].Nodes[xID36912.ToString()];
                    TV.Nodes[xID36912.Substring(0, 3)].Nodes[xID36912.Substring(0, 6)].Expand();
                }
                else if (xID36912.Length == 12)
                {
                    TV.SelectedNode = TV.Nodes[xID36912.Substring(0, 3)].Nodes[xID36912.Substring(0, 6)].Nodes[xID36912.Substring(0, 9)].Nodes[xID36912.ToString()];
                    TV.Nodes[xID36912.Substring(0, 3)].Nodes[xID36912.Substring(0, 6)].Nodes[xID36912.Substring(0, 9)].Expand();
                }
            }
            catch { }
        }
    }
}
