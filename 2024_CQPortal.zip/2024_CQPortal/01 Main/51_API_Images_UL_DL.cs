﻿using CQPortal;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace CQPortal
{
    static public class UpDLLoadImage
    {
        #region Upload
        static public async Task UpLoad(string Folder, string imagePath)
        {
            try
            {
                HttpClient mClient = new HttpClient();
                string FileName = Path.GetFileNameWithoutExtension(imagePath);
                string xURL = "https://calquan.com:85/api/Image/UpLoad/" + Folder + "/" + FileName;
                var xImage = Convert.ToBase64String(File.ReadAllBytes(imagePath));
                string JSonData = JsonConvert.SerializeObject(xImage);
                StringContent content = new StringContent(JSonData, Encoding.UTF8, "application/json");
                HttpResponseMessage xResponse = await mClient.PostAsync(xURL, content);
                string xResult = await xResponse.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        static public async Task UpLoadImageWithNAme(string Folder, string xID, string imagePath)
        {
            try
            {
                HttpClient mClient = new HttpClient();
                string FileName = Path.GetFileNameWithoutExtension(imagePath);
                string xURL = "https://calquan.com:85/api/Image/UpLoad/" + Folder + "/" + xID;
                var xImage = Convert.ToBase64String(File.ReadAllBytes(imagePath));
                string JSonData = JsonConvert.SerializeObject(xImage);
                StringContent content = new StringContent(JSonData, Encoding.UTF8, "application/json");
                HttpResponseMessage xResponse = await mClient.PostAsync(xURL, content);
                string xResult = await xResponse.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        static public async Task UpLoadCVImage(string imagePath)
        {
            try
            {
                HttpClient mClient = new HttpClient();
                string FileName = Path.GetFileNameWithoutExtension(imagePath);
                string xURL = "https://calquan.com:85/api/Image/UpLoadCVImage/" + FileName;
                var xImage = Convert.ToBase64String(File.ReadAllBytes(imagePath));
                string JSonData = JsonConvert.SerializeObject(xImage);
                StringContent content = new StringContent(JSonData, Encoding.UTF8, "application/json");
                HttpResponseMessage xResponse = await mClient.PostAsync(xURL, content);
                string xResult = await xResponse.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        static public async Task UpLoadCVPdf(string FilePath)
        {
            try
            {
                HttpClient mClient = new HttpClient();
                string FileName = Path.GetFileNameWithoutExtension(FilePath);
                string xURL = "https://calquan.com:85/api/Image/UpLoadCVPdf/" + FileName;
                var xImage = Convert.ToBase64String(File.ReadAllBytes(FilePath));
                string JSonData = JsonConvert.SerializeObject(xImage);
                StringContent content = new StringContent(JSonData, Encoding.UTF8, "application/json");
                HttpResponseMessage xResponse = await mClient.PostAsync(xURL, content);
                string xResult = await xResponse.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
        #endregion

        #region Downlod
        async public static void DownloadPdf(string xFileName)
        {
            try
            {
                string savePath = CQBVar.xPath + @"\" + xFileName + ".pdf";
                var MyURL = CQBVar.MyURL+"/api/Image/DownLoadCVpdf/" + xFileName;
                await DownloadPdfAsync(MyURL, savePath);
                System.Diagnostics.Process.Start(savePath);
            }
            catch { }


        }
        static async Task DownloadPdfAsync(string url, string savePath)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    using (HttpResponseMessage response = await client.GetAsync(url))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            using (FileStream fileStream = new FileStream(savePath, FileMode.Create, FileAccess.Write))
                            {
                                await response.Content.CopyToAsync(fileStream);
                            }
                        }
                        else { }
                    }
                }
            }
            catch { }
        }
        async public static void DownloadImage(string xImage, String MyURL)
        {
            try
            {
                string savePath = CQBVar.xPath + @"\" + xImage + ".jpeg";
                await DownloadImageAsync(MyURL, savePath);
                System.Diagnostics.Process.Start(savePath);
            }
            catch { }
        }
        static async Task DownloadImageAsync(string url, string savePath)//1
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    using (HttpResponseMessage response = await client.GetAsync(url))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            // Save the image to the specified path
                            using (FileStream fileStream = new FileStream(savePath, FileMode.Create, FileAccess.Write))
                            {
                                await response.Content.CopyToAsync(fileStream);
                            }
                        }
                        else
                        {
                            throw new Exception($"Failed to download image: {response.ReasonPhrase}");
                        }
                    }
                }
            }
            catch { }
        }
        #endregion
    }
}

