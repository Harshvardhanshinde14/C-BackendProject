﻿namespace CQPortal
{
    partial class FrmLogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogIn));
            this.mOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.tabBackUpRecovery = new System.Windows.Forms.TabPage();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.btnBackUpBackUp = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.TVBackUp = new System.Windows.Forms.TreeView();
            this.tabDB = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lblIPAdd = new System.Windows.Forms.Label();
            this.chkLoginSavePW = new System.Windows.Forms.CheckBox();
            this.txtLoginUserName = new System.Windows.Forms.TextBox();
            this.btnLoginDBUpdate = new System.Windows.Forms.Button();
            this.txtLoginIPAddress = new System.Windows.Forms.TextBox();
            this.btnLoginExit = new System.Windows.Forms.Button();
            this.cmbLoginWebNavigation = new System.Windows.Forms.ComboBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.txtLoginPW = new System.Windows.Forms.TextBox();
            this.btnLoginDBLogin = new System.Windows.Forms.Button();
            this.btnLoginTenders = new System.Windows.Forms.Button();
            this.btnLoginCompany = new System.Windows.Forms.Button();
            this.btnLoginJobs = new System.Windows.Forms.Button();
            this.btnLoginContactUs = new System.Windows.Forms.Button();
            this.webLogin = new System.Windows.Forms.WebBrowser();
            this.webBrowserLogin = new System.Windows.Forms.WebBrowser();
            this.TC = new System.Windows.Forms.TabControl();
            this.tabBackUpRecovery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.Panel2.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).BeginInit();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            this.tabDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.TC.SuspendLayout();
            this.SuspendLayout();
            // 
            // mOpenFile
            // 
            this.mOpenFile.FileName = "mOpenFile";
            // 
            // tabBackUpRecovery
            // 
            this.tabBackUpRecovery.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabBackUpRecovery.Controls.Add(this.splitContainer10);
            this.tabBackUpRecovery.Location = new System.Drawing.Point(4, 22);
            this.tabBackUpRecovery.Name = "tabBackUpRecovery";
            this.tabBackUpRecovery.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabBackUpRecovery.Size = new System.Drawing.Size(1020, 507);
            this.tabBackUpRecovery.TabIndex = 7;
            this.tabBackUpRecovery.Text = "BackUp/Recover";
            this.tabBackUpRecovery.UseVisualStyleBackColor = true;
            // 
            // splitContainer10
            // 
            this.splitContainer10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer10.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer10.IsSplitterFixed = true;
            this.splitContainer10.Location = new System.Drawing.Point(3, 3);
            this.splitContainer10.Name = "splitContainer10";
            this.splitContainer10.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.btnBackUpBackUp);
            this.splitContainer10.Panel1.Controls.Add(this.btnExit);
            // 
            // splitContainer10.Panel2
            // 
            this.splitContainer10.Panel2.Controls.Add(this.splitContainer12);
            this.splitContainer10.Size = new System.Drawing.Size(1012, 499);
            this.splitContainer10.SplitterDistance = 60;
            this.splitContainer10.TabIndex = 2;
            // 
            // btnBackUpBackUp
            // 
            this.btnBackUpBackUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackUpBackUp.Location = new System.Drawing.Point(22, 26);
            this.btnBackUpBackUp.Name = "btnBackUpBackUp";
            this.btnBackUpBackUp.Size = new System.Drawing.Size(100, 25);
            this.btnBackUpBackUp.TabIndex = 31;
            this.btnBackUpBackUp.Text = "BackUp";
            this.btnBackUpBackUp.UseVisualStyleBackColor = true;
            this.btnBackUpBackUp.Click += new System.EventHandler(this.btnBackUpBackUp_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(957, 23);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(50, 25);
            this.btnExit.TabIndex = 30;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // splitContainer12
            // 
            this.splitContainer12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer12.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer12.IsSplitterFixed = true;
            this.splitContainer12.Location = new System.Drawing.Point(0, 0);
            this.splitContainer12.Name = "splitContainer12";
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.TVBackUp);
            this.splitContainer12.Size = new System.Drawing.Size(1012, 435);
            this.splitContainer12.SplitterDistance = 300;
            this.splitContainer12.TabIndex = 0;
            // 
            // TVBackUp
            // 
            this.TVBackUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVBackUp.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVBackUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVBackUp.FullRowSelect = true;
            this.TVBackUp.HideSelection = false;
            this.TVBackUp.Location = new System.Drawing.Point(0, 0);
            this.TVBackUp.Name = "TVBackUp";
            this.TVBackUp.Size = new System.Drawing.Size(298, 433);
            this.TVBackUp.TabIndex = 28;
            // 
            // tabDB
            // 
            this.tabDB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabDB.Controls.Add(this.splitContainer3);
            this.tabDB.Location = new System.Drawing.Point(4, 22);
            this.tabDB.Name = "tabDB";
            this.tabDB.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabDB.Size = new System.Drawing.Size(1020, 507);
            this.tabDB.TabIndex = 2;
            this.tabDB.Text = "Login";
            this.tabDB.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(3, 3);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.webLogin);
            this.splitContainer3.Panel2.Controls.Add(this.webBrowserLogin);
            this.splitContainer3.Size = new System.Drawing.Size(1269, 501);
            this.splitContainer3.SplitterDistance = 120;
            this.splitContainer3.TabIndex = 1;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lblIPAdd);
            this.splitContainer1.Panel1.Controls.Add(this.chkLoginSavePW);
            this.splitContainer1.Panel1.Controls.Add(this.txtLoginUserName);
            this.splitContainer1.Panel1.Controls.Add(this.btnLoginDBUpdate);
            this.splitContainer1.Panel1.Controls.Add(this.txtLoginIPAddress);
            this.splitContainer1.Panel1.Controls.Add(this.btnLoginExit);
            this.splitContainer1.Panel1.Controls.Add(this.cmbLoginWebNavigation);
            this.splitContainer1.Panel1.Controls.Add(this.lblUser);
            this.splitContainer1.Panel1.Controls.Add(this.txtLoginPW);
            this.splitContainer1.Panel1.Controls.Add(this.btnLoginDBLogin);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnLoginTenders);
            this.splitContainer1.Panel2.Controls.Add(this.btnLoginCompany);
            this.splitContainer1.Panel2.Controls.Add(this.btnLoginJobs);
            this.splitContainer1.Panel2.Controls.Add(this.btnLoginContactUs);
            this.splitContainer1.Size = new System.Drawing.Size(1269, 120);
            this.splitContainer1.SplitterDistance = 60;
            this.splitContainer1.SplitterWidth = 3;
            this.splitContainer1.TabIndex = 239;
            // 
            // lblIPAdd
            // 
            this.lblIPAdd.AutoSize = true;
            this.lblIPAdd.Location = new System.Drawing.Point(24, 10);
            this.lblIPAdd.Name = "lblIPAdd";
            this.lblIPAdd.Size = new System.Drawing.Size(58, 13);
            this.lblIPAdd.TabIndex = 129;
            this.lblIPAdd.Text = "IP Address";
            // 
            // chkLoginSavePW
            // 
            this.chkLoginSavePW.AutoSize = true;
            this.chkLoginSavePW.Location = new System.Drawing.Point(370, 7);
            this.chkLoginSavePW.Margin = new System.Windows.Forms.Padding(0);
            this.chkLoginSavePW.Name = "chkLoginSavePW";
            this.chkLoginSavePW.Size = new System.Drawing.Size(106, 17);
            this.chkLoginSavePW.TabIndex = 131;
            this.chkLoginSavePW.Text = "Password (Save)";
            this.chkLoginSavePW.UseVisualStyleBackColor = true;
            // 
            // txtLoginUserName
            // 
            this.txtLoginUserName.Location = new System.Drawing.Point(195, 26);
            this.txtLoginUserName.Name = "txtLoginUserName";
            this.txtLoginUserName.Size = new System.Drawing.Size(168, 20);
            this.txtLoginUserName.TabIndex = 127;
            // 
            // btnLoginDBUpdate
            // 
            this.btnLoginDBUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoginDBUpdate.Location = new System.Drawing.Point(648, 23);
            this.btnLoginDBUpdate.Name = "btnLoginDBUpdate";
            this.btnLoginDBUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnLoginDBUpdate.TabIndex = 29;
            this.btnLoginDBUpdate.Text = "Update DB";
            this.btnLoginDBUpdate.UseVisualStyleBackColor = true;
            this.btnLoginDBUpdate.Click += new System.EventHandler(this.btnLoginDBUpdate_Click);
            // 
            // txtLoginIPAddress
            // 
            this.txtLoginIPAddress.Location = new System.Drawing.Point(22, 26);
            this.txtLoginIPAddress.Name = "txtLoginIPAddress";
            this.txtLoginIPAddress.Size = new System.Drawing.Size(168, 20);
            this.txtLoginIPAddress.TabIndex = 126;
            // 
            // btnLoginExit
            // 
            this.btnLoginExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoginExit.Location = new System.Drawing.Point(957, 23);
            this.btnLoginExit.Name = "btnLoginExit";
            this.btnLoginExit.Size = new System.Drawing.Size(50, 25);
            this.btnLoginExit.TabIndex = 30;
            this.btnLoginExit.Text = "X";
            this.btnLoginExit.UseVisualStyleBackColor = true;
            this.btnLoginExit.Click += new System.EventHandler(this.btnLoginExit_Click);
            // 
            // cmbLoginWebNavigation
            // 
            this.cmbLoginWebNavigation.FormattingEnabled = true;
            this.cmbLoginWebNavigation.Location = new System.Drawing.Point(754, 24);
            this.cmbLoginWebNavigation.Name = "cmbLoginWebNavigation";
            this.cmbLoginWebNavigation.Size = new System.Drawing.Size(186, 21);
            this.cmbLoginWebNavigation.TabIndex = 233;
            this.cmbLoginWebNavigation.SelectedIndexChanged += new System.EventHandler(this.cmbLoginWebNavigation_SelectedIndexChanged);
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(198, 10);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(60, 13);
            this.lblUser.TabIndex = 130;
            this.lblUser.Text = "User Name";
            // 
            // txtLoginPW
            // 
            this.txtLoginPW.Location = new System.Drawing.Point(368, 26);
            this.txtLoginPW.Name = "txtLoginPW";
            this.txtLoginPW.PasswordChar = '*';
            this.txtLoginPW.Size = new System.Drawing.Size(168, 20);
            this.txtLoginPW.TabIndex = 128;
            // 
            // btnLoginDBLogin
            // 
            this.btnLoginDBLogin.Font = new System.Drawing.Font("Arial", 9.75F);
            this.btnLoginDBLogin.Location = new System.Drawing.Point(542, 23);
            this.btnLoginDBLogin.Name = "btnLoginDBLogin";
            this.btnLoginDBLogin.Size = new System.Drawing.Size(100, 25);
            this.btnLoginDBLogin.TabIndex = 31;
            this.btnLoginDBLogin.Text = "Login";
            this.btnLoginDBLogin.UseVisualStyleBackColor = true;
            this.btnLoginDBLogin.Click += new System.EventHandler(this.btnLoginDBLogin_Click);
            // 
            // btnLoginTenders
            // 
            this.btnLoginTenders.Enabled = false;
            this.btnLoginTenders.Font = new System.Drawing.Font("Arial", 9.75F);
            this.btnLoginTenders.Location = new System.Drawing.Point(138, 16);
            this.btnLoginTenders.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLoginTenders.Name = "btnLoginTenders";
            this.btnLoginTenders.Size = new System.Drawing.Size(112, 24);
            this.btnLoginTenders.TabIndex = 238;
            this.btnLoginTenders.Text = "News";
            this.btnLoginTenders.UseVisualStyleBackColor = true;
            this.btnLoginTenders.Click += new System.EventHandler(this.btnLoginNews_Click);
            // 
            // btnLoginCompany
            // 
            this.btnLoginCompany.Enabled = false;
            this.btnLoginCompany.Font = new System.Drawing.Font("Arial", 9.75F);
            this.btnLoginCompany.Location = new System.Drawing.Point(255, 16);
            this.btnLoginCompany.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLoginCompany.Name = "btnLoginCompany";
            this.btnLoginCompany.Size = new System.Drawing.Size(112, 24);
            this.btnLoginCompany.TabIndex = 235;
            this.btnLoginCompany.Text = "Companies";
            this.btnLoginCompany.UseVisualStyleBackColor = true;
            this.btnLoginCompany.Click += new System.EventHandler(this.btnLoginCompanies_Click);
            // 
            // btnLoginJobs
            // 
            this.btnLoginJobs.Enabled = false;
            this.btnLoginJobs.Font = new System.Drawing.Font("Arial", 9.75F);
            this.btnLoginJobs.Location = new System.Drawing.Point(22, 16);
            this.btnLoginJobs.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLoginJobs.Name = "btnLoginJobs";
            this.btnLoginJobs.Size = new System.Drawing.Size(112, 24);
            this.btnLoginJobs.TabIndex = 237;
            this.btnLoginJobs.Text = "Jobs";
            this.btnLoginJobs.UseVisualStyleBackColor = true;
            this.btnLoginJobs.Click += new System.EventHandler(this.btnLoginJobs_Click);
            // 
            // btnLoginContactUs
            // 
            this.btnLoginContactUs.Enabled = false;
            this.btnLoginContactUs.Font = new System.Drawing.Font("Arial", 9.75F);
            this.btnLoginContactUs.Location = new System.Drawing.Point(372, 16);
            this.btnLoginContactUs.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLoginContactUs.Name = "btnLoginContactUs";
            this.btnLoginContactUs.Size = new System.Drawing.Size(112, 24);
            this.btnLoginContactUs.TabIndex = 236;
            this.btnLoginContactUs.Text = "Contact Us";
            this.btnLoginContactUs.UseVisualStyleBackColor = true;
            this.btnLoginContactUs.Click += new System.EventHandler(this.btnLoginContactUs_Click);
            // 
            // webLogin
            // 
            this.webLogin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webLogin.Location = new System.Drawing.Point(0, 0);
            this.webLogin.MinimumSize = new System.Drawing.Size(20, 20);
            this.webLogin.Name = "webLogin";
            this.webLogin.Size = new System.Drawing.Size(1267, 375);
            this.webLogin.TabIndex = 45;
            // 
            // webBrowserLogin
            // 
            this.webBrowserLogin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserLogin.Location = new System.Drawing.Point(0, 0);
            this.webBrowserLogin.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserLogin.Name = "webBrowserLogin";
            this.webBrowserLogin.Size = new System.Drawing.Size(1267, 375);
            this.webBrowserLogin.TabIndex = 44;
            this.webBrowserLogin.Visible = false;
            // 
            // TC
            // 
            this.TC.Controls.Add(this.tabDB);
            this.TC.Controls.Add(this.tabBackUpRecovery);
            this.TC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TC.Location = new System.Drawing.Point(0, 0);
            this.TC.Name = "TC";
            this.TC.SelectedIndex = 0;
            this.TC.Size = new System.Drawing.Size(1028, 533);
            this.TC.TabIndex = 0;
            // 
            // FrmLogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1028, 533);
            this.Controls.Add(this.TC);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmLogIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CQ_Portal";
            this.Load += new System.EventHandler(this.FrmLogIn_Load);
            this.tabBackUpRecovery.ResumeLayout(false);
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).EndInit();
            this.splitContainer12.ResumeLayout(false);
            this.tabDB.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.TC.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog mOpenFile;
        private System.Windows.Forms.TabPage tabBackUpRecovery;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.Button btnBackUpBackUp;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.SplitContainer splitContainer12;
        private System.Windows.Forms.TreeView TVBackUp;
        private System.Windows.Forms.TabPage tabDB;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ComboBox cmbLoginWebNavigation;
        private System.Windows.Forms.TextBox txtLoginPW;
        private System.Windows.Forms.Button btnLoginDBLogin;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnLoginExit;
        private System.Windows.Forms.Label lblIPAdd;
        private System.Windows.Forms.TextBox txtLoginIPAddress;
        private System.Windows.Forms.Button btnLoginDBUpdate;
        private System.Windows.Forms.TextBox txtLoginUserName;
        private System.Windows.Forms.CheckBox chkLoginSavePW;
        private System.Windows.Forms.WebBrowser webLogin;
        private System.Windows.Forms.WebBrowser webBrowserLogin;
        private System.Windows.Forms.TabControl TC;
        private System.Windows.Forms.Button btnLoginTenders;
        private System.Windows.Forms.Button btnLoginJobs;
        private System.Windows.Forms.Button btnLoginContactUs;
        private System.Windows.Forms.Button btnLoginCompany;
        private System.Windows.Forms.SplitContainer splitContainer1;
    }
}

