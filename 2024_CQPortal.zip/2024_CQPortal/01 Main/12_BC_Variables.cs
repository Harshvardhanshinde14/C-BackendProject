﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPortal
{
    public class CQBVar
    {
        public static string Version
        {
            get
            {
                string xVersion = "2024091801";
                return xVersion;
            }
        }
        public static string mDBName = "CQPortal";//CQPortal1
        public static string xPath = "C:\\CQ_Portal";
        public static string xPathBackUp = "C:\\CQ_Portal_BackUp";
        public static String MyURL ="https://calquan.com:85";
      //  public static String MyURL = "https://103.14.99.54:85";
        public static class Path
        {
            public static string xProj = "";
            public static string Server = "";
            public static string Database = "";
            public static string Report = "";
            public static string DataFile = "";
            public static string ErrorLog = "";
            public static string Drive = "C:\\CQ_Projects\\";
            public static string ServerDrive = "C:\\CQ_Projects\\";
            public static string Data = "";
        }
        public static class Portal
        {
            public static class Sel
            {
                public static string SS = "";
                public static string DBDate = "";
                public static string Confirmation = "";
            }
            public static class Prj
            {
                public static string Caption = "CQPortal";
            }
        }
        public static class ConnString
        {
            public static String IPAddress = "-";
            public static String UserName = "-";
            public static String UserID = "-";
            public static String UserRole = "-";
            public static String Password = "-";
            public static String TimeOut = "30";
            public static string xServerName = "NonAzure";
            public static String ServerMaster
            {
                get
                {
                    return xGetDBStrConn(xServerName, "master");
                }
            }
            public static String CQ
            {
                get
                {
                    return xGetDBStrConn(xServerName, mDBName);
                }
            }
            private static string xGetDBStrConn(string xServerName, string xCatalogName)
            {
                try
                {
                    string xUsername = UserName;
                    if (xUsername != "sa") xUsername = "cq_" + xUsername;
                   // return "Data Source=" + IPAddress + " ;Network Library=DBMSSOCN;Initial Catalog=" + xCatalogName + "; User ID=" + xUsername + "; Password = " + Password + ";Connection Timeout= " + TimeOut + " ;";
                      return "Data Source=103.14.99.54 ;Network Library=DBMSSOCN;Initial Catalog=" + xCatalogName + "; User ID=sa; Password = cqadmin123;Connection Timeout= " + TimeOut + " ;";
                }
                catch { return ""; }
            }
        }
    };
}
