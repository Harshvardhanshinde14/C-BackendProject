﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPortal
{
    [Serializable]
    public class News
    {//xID,xTitle,xSubTitle,xSource,xLinkAdd,xDate,xSeqNo,xFlag
        public string xID = "";
        public string xTitle;
        public string xSubTitle;
        public string xSource;
        public string xLinkAdd;
        public string xDate;
        public int xSeqNo;
        public bool xFlag = false;
        public News() { }
        public News(string xID, string Title, string xSubTitle, string source, string LinkAdd, string Date, bool xFlag)
        {
            this.xID = xID;
            this.xTitle = Title;
            this.xSubTitle = xSubTitle;
            this.xSource = source;
            this.xLinkAdd = LinkAdd;
            this.xDate = Date;
            this.xFlag = xFlag;
        }
    }

    [Serializable]
    public class Company
    {
        // xID,xName,xShortName,xDesc,xCity,xCompanyLink,xCompanyOpeningLink,xLogoName,xFlag,xSeqNo,xDateTimeStamp
        public string xID;
        public string xName;
        public string xShortName;
        public string xDesc;
        public string xCity;
        public string xCompanyLink;
        public string xCompanyOpeningLink;
        public string xLogoName;
        public bool xFlag = false;
        public int xSeqNo;
        public string xDateTimeStamp;
        public Company() { }
        public Company(string xID, string xName, string xShortName, string xLogoName, string xDesc, string xCompanyLink, string xCompanyOpeningLink, int xSeqNo, bool xFlag)
        {
            this.xID = xID;
            this.xName = xName;
            this.xShortName = xShortName;
            this.xDesc = xDesc;
            this.xCompanyLink = xCompanyLink;
            this.xCompanyOpeningLink = xCompanyOpeningLink;
            this.xLogoName = xLogoName;
            this.xSeqNo = xSeqNo;
            this.xFlag = xFlag;
        }

    }
    [Serializable]
    public class Professionals
    {//xID,xName,xPhotoName,xDescription,xCompanyId,xDesignation,xSeqNo
        public string xID;
        public string xName;
        public string xPhotoName;
        public string xDescription;
        public string xCompanyId;
        public string xDesignation;
        public int xSeqNo;
        public Professionals() { }
        public Professionals(string xID, string xName, string xPhotoName, string xDescription, string xCompanyId, string xDesignation, int xSeqNo)
        {
            this.xID = xID;
            this.xName = xName;
            this.xPhotoName = xPhotoName;
            this.xDescription = xDescription;
            this.xCompanyId = xCompanyId;
            this.xDesignation = xDesignation;
            this.xSeqNo = xSeqNo;
        }
    }
    [Serializable]
    public class Review
    {//xID,xDate, xTitle, xSubTitle, xDescription, xProfessionalID,xSeqNo
        public string xID;
        public string xDate;
        public string xTitle;
        public string xSubTitle;
        public string xDescription;
        public string xProfessionalID;
        public int xSeqNo;
        public Review() { }
    }

    [Serializable]
    public class ContactUs
    {//xName,xCompanyName,xCity,xEmail,xPhoneNo,xSubject,xMessage,xSeqNo,xGetquot,Timestamp
        public string xID;
        public string xName;
        public string xCompanyName;
        public string xCity;
        public string xEmail;
        public string xPhoneNo;
        public string xSubject;
        public string xMessage;
        public int xSeqNo;
        public string xGetquot;
        public string Timestamp;
        public ContactUs() { }

    }

    [Serializable]
    public class JobVaccancy
    {
        //xID,xDate,xTitle,xDesc,xCompanyId,xLink,xFlag,xSeqNo
        public string xID;
        public string xDate;
        public string xTitle;
        public string xDesc;
        public string xCompanyId;
        public string xLink;
        public bool xFlag = false;
        public int xSeqNo;
        public JobVaccancy(string xID, string xDate, string xTitle, string xDesc, string xCompanyId, string xLink, int xSeqNo, bool xFlag)
        {
            this.xID = xID;
            this.xDate = xDate;
            this.xTitle = xTitle;
            this.xDesc = xDesc;
            this.xCompanyId = xCompanyId;
            this.xLink = xLink;
            this.xSeqNo = xSeqNo;
            this.xFlag = xFlag;
        }
        public JobVaccancy() { }
    }

    public class Tender
    {//xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2,xSeqNo
        public string xID;
        public string xDate;
        public string xPrjNameName;
        public string xDepName;
        public string xPrjCoast;
        public string xDesc;
        public string xImage1;
        public string xImage2;
        public Int32 xSeqNo = 0;
        public Tender(String xID, string xDate, string xPrjNameName, string xDepName, string xPrjCoast, string xDesc, string xImage1, string xImage2, Int32 xSeqNo)
        {
            this.xID = xID;
            this.xDate = xDate; ;
            this.xPrjNameName = xPrjNameName;
            this.xDepName = xDepName;
            this.xPrjCoast = xPrjCoast;
            this.xDesc = xDesc;
            this.xImage1 = xImage1;
            this.xImage2 = xImage2;
            this.xSeqNo = xSeqNo;
        }
        public Tender() { }
    }

    public class Bidder
    {//xID,xDate,xCompanyID,xBidValue,xPerVariation,xSeqNo
        public string xID;
        public string xDate;
        public string xCompanyID;
        public string xBidValue;
        public string xPerVariation;
        public Int32 xSeqNo = 0;
        public Bidder(string xID, string xDate, string xCompanyID, string xBidValue, string xPerVariation, Int32 xSeqNo)
        {
            this.xID = xID;
            this.xDate = xDate; ;
            this.xCompanyID = xCompanyID;
            this.xBidValue = xBidValue;
            this.xPerVariation = xPerVariation;
            this.xSeqNo = xSeqNo;
        }
        public Bidder() { }
    }
    [Serializable]
    public class Placement
    {//xID,xName,xEmail,xPhoneNo,xAge,xEducation,xExperience,xMessage,xFileName,xCVPdfORImage,xDateTimeStamp
        public string xID;
        public string xName;
        public string xEmail;
        public string xPhoneNo;
        public string xAge;
        public string xEducation;
        public string xExperience;
        public string xMessage;
        public string xFileName;
        public string xCVPdfORImage = "1";//0=PDF, 1=Image
        public string xDateTimeStamp;
        public Placement() { }
    }

    [Serializable]
    public class GovtPortal
    {
        //xID,xName,xLink,xSeqNo,xFlag,xDateTimeStamp
        public string xID;
        public string xName;
        public string xLink;
        public int xSeqNo;
        public bool xFlag = false;
        public string xDateTimeStamp;
        public GovtPortal() { }
    }
    [Serializable]
    public class TrainingProgram
    {
        //xID,xTitle,xShortDesc,xStartDate,xDesc,xDuration,xLocation,xTimings,xContactNo,xCity,xSeqNo,xDateTimeStamp
        public string xID;
        public string xTitle;
        public string xShortDesc;
        public string xStartDate;
        public string xDesc;
        public string xDuration;
        public string xLocation;
        public string xTimings;
        public string xContactNo;
        public string xCity;
        public int xSeqNo;
        public string xDateTimeStamp;
        public TrainingProgram() { }
    }
    [Serializable]
    public class PlacedStudent
    {//xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xSeqNo,xDateTimeStamp
        public string xID;
        public string xName;
        public string xEmail;
        public string xDepartment;
        public string xExeperience;
        public string xQualification;
        public string xPlacedCompany;
        public string xContactNumber;
        public string xDesc;
        public string xPSPhotoName;
        public int xSeqNo;
        public string xDateTimeStamp;
        public PlacedStudent()
        {

        }
    }

    [Serializable]
    public class InfraProfessional
    { //xID,xName,xQualification,xDesignation,xCompany,xExp,xContactNumber,xEmail,xDesc,xPhotoName,xSeqNo
        public string xID;
        public string xName;
        public string xQualification;
        public string xDesignation;
        public string xCompany;
        public string xExp;
        public string xContactNumber;
        public string xEmail;
        public string xDesc;
        public string xPhotoName;
        public int xSeqNo;
        public InfraProfessional() { }
    }
    [Serializable]
    public class ConsultantCompany
    {//xID,xName,xShortName,xDesc,xCity,xCompanyLink,xLogoName,xFlag,xSeqNo
        public string xID;
        public string xName;
        public string xShortName;
        public string xDesc;
        public string xCity;
        public string xCompanyLink;
        public string xLogoName;
        public bool xFlag = false;
        public int xSeqNo;
        public ConsultantCompany() { }
    }
    [Serializable]
    public class CQNews
    { //xID,xTitle,xDate,xDesc,xSeqNo,xDateTimeStamp
        public string xID;
        public string xTitle;
        public string xDate;
        public string xDesc;
        public int xSeqNo;
        public string xNewsTbPhotoName;
        public CQNews() { }
    }
    [Serializable]
    public class NewsPhotoName
    { //xNewsID,xPhotoFileName
        public string xNewsID;
        public string xPhotoFileName;
        public NewsPhotoName() { }
    }
    [Serializable]
    public class SuccessFulStories
    {
        // xID,xTiltle,xSubTitle,xDesc,xCompanyName,xPhotoName,xLogoName,xSeqNo,xDateTimeStamp
        public string xID;
        public string xTiltle;
        public string xSubTitle;
        public string xDesc;
        public string xCompanyName;
        public string xPhotoName;
        public string xLogoName;
        public int xSeqNo;
        public string xDateTimeStamp;
        public SuccessFulStories() { }
        public SuccessFulStories(string xID, string xTiltle, string xSubTitle, string xDesc, string xCompanyName, string xPhotoName, string xLogoName, int xSeqNo,string xDateTimeStamp)
        {
            this.xID = xID;
            this.xTiltle = xTiltle;
            this.xSubTitle = xSubTitle;
            this.xDesc = xDesc;
            this.xCompanyName = xCompanyName;
            this.xPhotoName = xPhotoName;
            this.xLogoName = xLogoName;
            this.xSeqNo = xSeqNo;
            this.xDateTimeStamp = xDateTimeStamp;
        }
}

}
