﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Xsl;

namespace CQPortal
{
   public static class ContactUss
    {
        public static List<ContactUs> mLst = new List<ContactUs>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<ContactUs> xLst)
        {
            //xID,xName,xCompanyName,xCity,xEmail,xPhoneNo,xSubject,xMessage
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xName + "','" + xLst[n].xCompanyName + "','" + xLst[n].xCity + "','" + xLst[n].xEmail +"','" + xLst[n].xPhoneNo + "','" + xLst[n].xSubject + "','" + xLst[n].xMessage + "','" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)//xSeqNo,xDateTimeStamp
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_ContactUs (xName,xCompanyName,xCity,xEmail,xPhoneNo,xSubject,xMessage,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, ContactUs xT)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_ContactUs Where xID= '"+xT.xID+"'") == false) return;
                ActualDBUpLoad(DBConn, new List<ContactUs>() { xT});
            }
            catch { }
        }
        public static List<ContactUs> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<ContactUs> xRetLst = new List<ContactUs>();
                while (oReader.Read())
                {
                    //xID,xName,xCompanyName,xCity,xEmail,xPhoneNo,xSubject,xMessage
                    ContactUs xT = new ContactUs();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xName = oReader["xName"].ToString().Trim();
                    xT.xCompanyName = oReader["xCompanyName"].ToString().Trim();
                    xT.xCity = oReader["xCity"].ToString().Trim();
                    xT.xEmail = oReader["xEmail"].ToString().Trim();
                    xT.xPhoneNo = oReader["xPhoneNo"].ToString().Trim();
                    xT.xSubject = oReader["xSubject"].ToString().Trim();
                    xT.xMessage =oReader["xMessage"].ToString().Trim();
                    xT.xGetquot = oReader["xGetquot"].ToString().Trim();
                    xT.Timestamp = oReader["xDateTimeStamp"].ToString().Trim();
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<ContactUs>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<ContactUs>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_ContactUs";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static List<ContactUs> DownLoadByFlag(SqlConnection DBConn,string xGetQuot)
        {
            try
            {
                List <ContactUs> xLst = new List<ContactUs>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_ContactUs WHERE xGetquot = '" + xGetQuot + "' ";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                   xLst= ActualDBDownLoad(oReader);
                }
                return xLst;
            }
            catch
            {
                return new List<ContactUs>();
            }
        }
        #endregion

        #region Get
        public static ContactUs xGetByID(string xID)
        {
            try
            {
                ContactUs xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new ContactUs();
                return xT;
            }
            catch { return new ContactUs(); }
        }
        #endregion

        #region Add Update
        public static void xAdd6(SqlConnection DBConn, TreeView TV,TextBox txtName, TextBox txtCompany, TextBox txtCity, TextBox txtEmail,TextBox txtPhone,TextBox txtSubject, TextBox txtMessage)
        {
            try
            {    //xID,xName,xCompanyName,xCity,xEmail,xPhoneNo,xSubject,xMessage
               
                if (txtCity.Text.Trim() == "" || txtName.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }

                ContactUs xT = new ContactUs();
                xT.xName = txtName.Text.Trim();
                xT.xCompanyName = txtCompany.Text.Trim();
                xT.xCity = txtCity.Text.Trim();
                xT.xEmail = txtEmail.Text.Trim();
                xT.xPhoneNo =txtPhone.Text.Trim();
                xT.xSubject = txtSubject.Text.Trim();
                xT.xMessage = txtMessage.Text.Trim();
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT );
                //xPopTV(DBConn, TV);
            }
            catch { }
        }
        public static void xUpdate6(SqlConnection DBConn,string xID, TreeView TV, TextBox txtName, TextBox txtCompany, TextBox txtCity, TextBox txtEmail, TextBox txtPhone, TextBox txtSubject, TextBox txtMessage)
        {
            try
            {
                if (txtCity.Text.Trim() == "" || txtName.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                ContactUs xT=xGetByID(xID);
                if(xT == null) { return; }
                xT.xName = txtName.Text.Trim();
                xT.xCompanyName = txtCompany.Text.Trim();
                xT.xCity = txtCity.Text.Trim();
                xT.xEmail = txtEmail.Text.Trim();
                xT.xPhoneNo = txtPhone.Text.Trim();
                xT.xSubject = txtSubject.Text.Trim();
                xT.xMessage = txtMessage.Text.Trim();
                UpLoadSingle(DBConn, xT);
                //xPopTV(DBConn, TV);
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(SqlConnection DBConn, TreeView TV,string  xGetQuot)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
               
                List<ContactUs> xLst = DownLoadByFlag(DBConn, xGetQuot).OrderByDescending(p => p.Timestamp).ToList(); ;
                for (int i = 0; i < xLst.Count; i++)
                {
                    TV.Nodes.Add(xLst[i].xID, xLst[i].xName + " : " + xLst[i].Timestamp);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID, TextBox txtName, TextBox txtCompany, TextBox txtCity, TextBox txtEmail, TextBox txtPhone, TextBox txtSubject, TextBox txtMessage)
        {
            try
            {
                ContactUs xT = xGetByID(xID);
                if (xT != null)
                {
                    txtName.Text = xT.xName;
                    txtCompany.Text = xT.xCompanyName;
                    txtCity.Text = xT.xCity;
                    txtEmail.Text = xT.xEmail;
                    txtPhone.Text = xT.xPhoneNo.ToString();
                    txtSubject.Text = xT.xSubject;
                    txtMessage.Text = xT.xMessage;
                }
            }
            catch { }
        }
        #endregion
    }
}
