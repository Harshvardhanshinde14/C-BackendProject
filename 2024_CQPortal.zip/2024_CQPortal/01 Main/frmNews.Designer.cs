﻿namespace CQPortal
{
    partial class frmNews
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNews));
            this.mOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.tabTenderBidders = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.btnTenderBiddersDefault = new System.Windows.Forms.Button();
            this.btnTenderBiddersExit = new System.Windows.Forms.Button();
            this.btnTenderBiddersDelete = new System.Windows.Forms.Button();
            this.btnTenderBiddersAdd = new System.Windows.Forms.Button();
            this.btnTenderBiddersUpdate = new System.Windows.Forms.Button();
            this.splitContainer28 = new System.Windows.Forms.SplitContainer();
            this.TVTenderBiddersTender = new System.Windows.Forms.TreeView();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer29 = new System.Windows.Forms.SplitContainer();
            this.CalTenderBidders = new System.Windows.Forms.MonthCalendar();
            this.label39 = new System.Windows.Forms.Label();
            this.txtTenderBiddersBidValue = new System.Windows.Forms.TextBox();
            this.txtTenderBiddersPerVari = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.txtTenderBiddersDate = new System.Windows.Forms.TextBox();
            this.TVTenderBiddersCompany = new System.Windows.Forms.TreeView();
            this.label38 = new System.Windows.Forms.Label();
            this.tabTender = new System.Windows.Forms.TabPage();
            this.splitContainer24 = new System.Windows.Forms.SplitContainer();
            this.btnTenderAdd = new System.Windows.Forms.Button();
            this.btnTenderAddGrp = new System.Windows.Forms.Button();
            this.btnTenderShowImage2 = new System.Windows.Forms.Button();
            this.btnTenderULImage2 = new System.Windows.Forms.Button();
            this.btnTenderShowImage1 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btnTenderULImage1 = new System.Windows.Forms.Button();
            this.btnTenderExit = new System.Windows.Forms.Button();
            this.btnTenderDelete = new System.Windows.Forms.Button();
            this.btnTenderUpdate = new System.Windows.Forms.Button();
            this.splitContainer25 = new System.Windows.Forms.SplitContainer();
            this.TVTender = new System.Windows.Forms.TreeView();
            this.label4 = new System.Windows.Forms.Label();
            this.splitContainer26 = new System.Windows.Forms.SplitContainer();
            this.label37 = new System.Windows.Forms.Label();
            this.txtTenderDesc = new System.Windows.Forms.TextBox();
            this.CalTender = new System.Windows.Forms.MonthCalendar();
            this.label32 = new System.Windows.Forms.Label();
            this.txtTenderPrjName = new System.Windows.Forms.TextBox();
            this.txtTenderDepName = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtTenderPrjCoast = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtTenderDate = new System.Windows.Forms.TextBox();
            this.tabReview = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.btnReviewDown = new System.Windows.Forms.Button();
            this.btnReviewUp = new System.Windows.Forms.Button();
            this.btnReviewExit = new System.Windows.Forms.Button();
            this.btnReviewDelete = new System.Windows.Forms.Button();
            this.btnReviewAdd = new System.Windows.Forms.Button();
            this.btnReviewUpdate = new System.Windows.Forms.Button();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.TVReview = new System.Windows.Forms.TreeView();
            this.label3 = new System.Windows.Forms.Label();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.label15 = new System.Windows.Forms.Label();
            this.CalReview = new System.Windows.Forms.MonthCalendar();
            this.txtReviewSubTitle = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtReviewDate = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtReviewTitle = new System.Windows.Forms.TextBox();
            this.txtReviewDesc = new System.Windows.Forms.TextBox();
            this.tabNews = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnNewsDefault = new System.Windows.Forms.Button();
            this.btnNewsShowByDate = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNewsShowByDate = new System.Windows.Forms.TextBox();
            this.btnNewsExit = new System.Windows.Forms.Button();
            this.btnNewsDelete = new System.Windows.Forms.Button();
            this.btnNewsAdd = new System.Windows.Forms.Button();
            this.btnNewsUpdate = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.TVNews = new System.Windows.Forms.TreeView();
            this.label5 = new System.Windows.Forms.Label();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.chkNewsLinkFlag = new System.Windows.Forms.CheckBox();
            this.xCalNews = new System.Windows.Forms.MonthCalendar();
            this.txtNewsSubTitle = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtNewsDate = new System.Windows.Forms.TextBox();
            this.txtNewsLinkAddress = new System.Windows.Forms.TextBox();
            this.txtNewsTitle = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtNewsSource = new System.Windows.Forms.TextBox();
            this.webBrowserNews = new System.Windows.Forms.WebBrowser();
            this.NewsDGV = new System.Windows.Forms.DataGridView();
            this.TC = new System.Windows.Forms.TabControl();
            this.tabSuccessFulStories = new System.Windows.Forms.TabPage();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.btnSuccessFulStoriesShowLogo = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesUploadLogo = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesDown = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesUp = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesShowImage = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesAddGrp = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesExit = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesUploadImage = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesDelete = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesAdd = new System.Windows.Forms.Button();
            this.btnSuccessFulStoriesUpdate = new System.Windows.Forms.Button();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.TVSuccessFulStories = new System.Windows.Forms.TreeView();
            this.label8 = new System.Windows.Forms.Label();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.label66 = new System.Windows.Forms.Label();
            this.txtSuccessFulStoriesCompanyName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSuccessFulStoriesSubTitle = new System.Windows.Forms.TextBox();
            this.txtSuccessFulStoriesDesc = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtSuccessFulStoriesTiltle = new System.Windows.Forms.TextBox();
            this.webBrowserCompany = new System.Windows.Forms.WebBrowser();
            this.tabTenderBidders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer28)).BeginInit();
            this.splitContainer28.Panel1.SuspendLayout();
            this.splitContainer28.Panel2.SuspendLayout();
            this.splitContainer28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer29)).BeginInit();
            this.splitContainer29.Panel1.SuspendLayout();
            this.splitContainer29.Panel2.SuspendLayout();
            this.splitContainer29.SuspendLayout();
            this.tabTender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer24)).BeginInit();
            this.splitContainer24.Panel1.SuspendLayout();
            this.splitContainer24.Panel2.SuspendLayout();
            this.splitContainer24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer25)).BeginInit();
            this.splitContainer25.Panel1.SuspendLayout();
            this.splitContainer25.Panel2.SuspendLayout();
            this.splitContainer25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer26)).BeginInit();
            this.splitContainer26.Panel1.SuspendLayout();
            this.splitContainer26.SuspendLayout();
            this.tabReview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tabNews.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NewsDGV)).BeginInit();
            this.TC.SuspendLayout();
            this.tabSuccessFulStories.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            this.SuspendLayout();
            // 
            // mOpenFile
            // 
            this.mOpenFile.FileName = "mOpenFile";
            // 
            // tabTenderBidders
            // 
            this.tabTenderBidders.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabTenderBidders.Controls.Add(this.splitContainer4);
            this.tabTenderBidders.Location = new System.Drawing.Point(4, 22);
            this.tabTenderBidders.Name = "tabTenderBidders";
            this.tabTenderBidders.Padding = new System.Windows.Forms.Padding(3);
            this.tabTenderBidders.Size = new System.Drawing.Size(1076, 469);
            this.tabTenderBidders.TabIndex = 11;
            this.tabTenderBidders.Text = "Tender Bidders List";
            this.tabTenderBidders.UseVisualStyleBackColor = true;
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer4.IsSplitterFixed = true;
            this.splitContainer4.Location = new System.Drawing.Point(3, 3);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.btnTenderBiddersDefault);
            this.splitContainer4.Panel1.Controls.Add(this.btnTenderBiddersExit);
            this.splitContainer4.Panel1.Controls.Add(this.btnTenderBiddersDelete);
            this.splitContainer4.Panel1.Controls.Add(this.btnTenderBiddersAdd);
            this.splitContainer4.Panel1.Controls.Add(this.btnTenderBiddersUpdate);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer28);
            this.splitContainer4.Size = new System.Drawing.Size(1068, 461);
            this.splitContainer4.SplitterDistance = 60;
            this.splitContainer4.TabIndex = 4;
            // 
            // btnTenderBiddersDefault
            // 
            this.btnTenderBiddersDefault.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderBiddersDefault.Location = new System.Drawing.Point(777, 20);
            this.btnTenderBiddersDefault.Name = "btnTenderBiddersDefault";
            this.btnTenderBiddersDefault.Size = new System.Drawing.Size(100, 25);
            this.btnTenderBiddersDefault.TabIndex = 35;
            this.btnTenderBiddersDefault.Text = "Default";
            this.btnTenderBiddersDefault.UseVisualStyleBackColor = true;
            this.btnTenderBiddersDefault.Click += new System.EventHandler(this.btnTenderBiddersDefault_Click);
            // 
            // btnTenderBiddersExit
            // 
            this.btnTenderBiddersExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderBiddersExit.Location = new System.Drawing.Point(883, 20);
            this.btnTenderBiddersExit.Name = "btnTenderBiddersExit";
            this.btnTenderBiddersExit.Size = new System.Drawing.Size(100, 25);
            this.btnTenderBiddersExit.TabIndex = 30;
            this.btnTenderBiddersExit.Text = "Exit";
            this.btnTenderBiddersExit.UseVisualStyleBackColor = true;
            this.btnTenderBiddersExit.Click += new System.EventHandler(this.btnTenderBiddersExit_Click);
            // 
            // btnTenderBiddersDelete
            // 
            this.btnTenderBiddersDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderBiddersDelete.Location = new System.Drawing.Point(232, 20);
            this.btnTenderBiddersDelete.Name = "btnTenderBiddersDelete";
            this.btnTenderBiddersDelete.Size = new System.Drawing.Size(100, 25);
            this.btnTenderBiddersDelete.TabIndex = 28;
            this.btnTenderBiddersDelete.Text = "Delete";
            this.btnTenderBiddersDelete.UseVisualStyleBackColor = true;
            this.btnTenderBiddersDelete.Click += new System.EventHandler(this.btnTenderBiddersDelete_Click);
            // 
            // btnTenderBiddersAdd
            // 
            this.btnTenderBiddersAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderBiddersAdd.Location = new System.Drawing.Point(20, 20);
            this.btnTenderBiddersAdd.Name = "btnTenderBiddersAdd";
            this.btnTenderBiddersAdd.Size = new System.Drawing.Size(100, 25);
            this.btnTenderBiddersAdd.TabIndex = 29;
            this.btnTenderBiddersAdd.Text = "Add";
            this.btnTenderBiddersAdd.UseVisualStyleBackColor = true;
            this.btnTenderBiddersAdd.Click += new System.EventHandler(this.btnTenderBiddersAdd_Click);
            // 
            // btnTenderBiddersUpdate
            // 
            this.btnTenderBiddersUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderBiddersUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnTenderBiddersUpdate.Name = "btnTenderBiddersUpdate";
            this.btnTenderBiddersUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnTenderBiddersUpdate.TabIndex = 27;
            this.btnTenderBiddersUpdate.Text = "Update";
            this.btnTenderBiddersUpdate.UseVisualStyleBackColor = true;
            this.btnTenderBiddersUpdate.Click += new System.EventHandler(this.btnTenderBiddersUpdate_Click);
            // 
            // splitContainer28
            // 
            this.splitContainer28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer28.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer28.IsSplitterFixed = true;
            this.splitContainer28.Location = new System.Drawing.Point(0, 0);
            this.splitContainer28.Name = "splitContainer28";
            // 
            // splitContainer28.Panel1
            // 
            this.splitContainer28.Panel1.Controls.Add(this.TVTenderBiddersTender);
            this.splitContainer28.Panel1.Controls.Add(this.label2);
            // 
            // splitContainer28.Panel2
            // 
            this.splitContainer28.Panel2.Controls.Add(this.splitContainer29);
            this.splitContainer28.Size = new System.Drawing.Size(1068, 397);
            this.splitContainer28.SplitterDistance = 300;
            this.splitContainer28.TabIndex = 0;
            // 
            // TVTenderBiddersTender
            // 
            this.TVTenderBiddersTender.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVTenderBiddersTender.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVTenderBiddersTender.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVTenderBiddersTender.FullRowSelect = true;
            this.TVTenderBiddersTender.HideSelection = false;
            this.TVTenderBiddersTender.Location = new System.Drawing.Point(0, 25);
            this.TVTenderBiddersTender.Name = "TVTenderBiddersTender";
            this.TVTenderBiddersTender.Size = new System.Drawing.Size(298, 370);
            this.TVTenderBiddersTender.TabIndex = 28;
            this.TVTenderBiddersTender.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVTenderBiddersTender.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVTenderBiddersTender_MouseDoubleClick);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(298, 25);
            this.label2.TabIndex = 49;
            this.label2.Text = "Tender Bidder List";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer29
            // 
            this.splitContainer29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer29.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer29.IsSplitterFixed = true;
            this.splitContainer29.Location = new System.Drawing.Point(0, 0);
            this.splitContainer29.Name = "splitContainer29";
            // 
            // splitContainer29.Panel1
            // 
            this.splitContainer29.Panel1.Controls.Add(this.CalTenderBidders);
            this.splitContainer29.Panel1.Controls.Add(this.label39);
            this.splitContainer29.Panel1.Controls.Add(this.txtTenderBiddersBidValue);
            this.splitContainer29.Panel1.Controls.Add(this.txtTenderBiddersPerVari);
            this.splitContainer29.Panel1.Controls.Add(this.label41);
            this.splitContainer29.Panel1.Controls.Add(this.label42);
            this.splitContainer29.Panel1.Controls.Add(this.txtTenderBiddersDate);
            // 
            // splitContainer29.Panel2
            // 
            this.splitContainer29.Panel2.Controls.Add(this.TVTenderBiddersCompany);
            this.splitContainer29.Panel2.Controls.Add(this.label38);
            this.splitContainer29.Size = new System.Drawing.Size(764, 397);
            this.splitContainer29.SplitterDistance = 500;
            this.splitContainer29.TabIndex = 34;
            // 
            // CalTenderBidders
            // 
            this.CalTenderBidders.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalTenderBidders.Location = new System.Drawing.Point(155, 24);
            this.CalTenderBidders.Name = "CalTenderBidders";
            this.CalTenderBidders.TabIndex = 218;
            this.CalTenderBidders.Visible = false;
            this.CalTenderBidders.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.CalTenderBindder_DateSelected);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(22, 67);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(62, 16);
            this.label39.TabIndex = 38;
            this.label39.Text = "Bid Value";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenderBiddersBidValue
            // 
            this.txtTenderBiddersBidValue.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderBiddersBidValue.Location = new System.Drawing.Point(19, 85);
            this.txtTenderBiddersBidValue.Name = "txtTenderBiddersBidValue";
            this.txtTenderBiddersBidValue.Size = new System.Drawing.Size(464, 22);
            this.txtTenderBiddersBidValue.TabIndex = 39;
            // 
            // txtTenderBiddersPerVari
            // 
            this.txtTenderBiddersPerVari.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderBiddersPerVari.Location = new System.Drawing.Point(19, 134);
            this.txtTenderBiddersPerVari.Name = "txtTenderBiddersPerVari";
            this.txtTenderBiddersPerVari.Size = new System.Drawing.Size(464, 22);
            this.txtTenderBiddersPerVari.TabIndex = 35;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(22, 116);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(106, 16);
            this.label41.TabIndex = 34;
            this.label41.Text = "Percent Variation";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(22, 15);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(34, 16);
            this.label42.TabIndex = 28;
            this.label42.Text = "Date";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenderBiddersDate
            // 
            this.txtTenderBiddersDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderBiddersDate.Location = new System.Drawing.Point(19, 33);
            this.txtTenderBiddersDate.Name = "txtTenderBiddersDate";
            this.txtTenderBiddersDate.Size = new System.Drawing.Size(182, 22);
            this.txtTenderBiddersDate.TabIndex = 29;
            this.txtTenderBiddersDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TxtTenderBidderDate_MouseDoubleClick);
            // 
            // TVTenderBiddersCompany
            // 
            this.TVTenderBiddersCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVTenderBiddersCompany.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVTenderBiddersCompany.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVTenderBiddersCompany.FullRowSelect = true;
            this.TVTenderBiddersCompany.HideSelection = false;
            this.TVTenderBiddersCompany.Location = new System.Drawing.Point(0, 25);
            this.TVTenderBiddersCompany.Name = "TVTenderBiddersCompany";
            this.TVTenderBiddersCompany.Size = new System.Drawing.Size(258, 370);
            this.TVTenderBiddersCompany.TabIndex = 29;
            this.TVTenderBiddersCompany.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            // 
            // label38
            // 
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Dock = System.Windows.Forms.DockStyle.Top;
            this.label38.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(0, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(258, 25);
            this.label38.TabIndex = 38;
            this.label38.Text = "Company";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabTender
            // 
            this.tabTender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabTender.Controls.Add(this.splitContainer24);
            this.tabTender.Location = new System.Drawing.Point(4, 22);
            this.tabTender.Name = "tabTender";
            this.tabTender.Padding = new System.Windows.Forms.Padding(3);
            this.tabTender.Size = new System.Drawing.Size(1076, 469);
            this.tabTender.TabIndex = 10;
            this.tabTender.Text = "Tender";
            this.tabTender.UseVisualStyleBackColor = true;
            // 
            // splitContainer24
            // 
            this.splitContainer24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer24.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer24.IsSplitterFixed = true;
            this.splitContainer24.Location = new System.Drawing.Point(3, 3);
            this.splitContainer24.Name = "splitContainer24";
            this.splitContainer24.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer24.Panel1
            // 
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderAdd);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderAddGrp);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderShowImage2);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderULImage2);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderShowImage1);
            this.splitContainer24.Panel1.Controls.Add(this.button5);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderULImage1);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderExit);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderDelete);
            this.splitContainer24.Panel1.Controls.Add(this.btnTenderUpdate);
            // 
            // splitContainer24.Panel2
            // 
            this.splitContainer24.Panel2.Controls.Add(this.splitContainer25);
            this.splitContainer24.Size = new System.Drawing.Size(1068, 461);
            this.splitContainer24.SplitterDistance = 60;
            this.splitContainer24.TabIndex = 3;
            // 
            // btnTenderAdd
            // 
            this.btnTenderAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderAdd.Location = new System.Drawing.Point(126, 20);
            this.btnTenderAdd.Name = "btnTenderAdd";
            this.btnTenderAdd.Size = new System.Drawing.Size(100, 25);
            this.btnTenderAdd.TabIndex = 29;
            this.btnTenderAdd.Text = "Add";
            this.btnTenderAdd.UseVisualStyleBackColor = true;
            this.btnTenderAdd.Click += new System.EventHandler(this.btnTenderAdd_Click);
            // 
            // btnTenderAddGrp
            // 
            this.btnTenderAddGrp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderAddGrp.Location = new System.Drawing.Point(20, 20);
            this.btnTenderAddGrp.Name = "btnTenderAddGrp";
            this.btnTenderAddGrp.Size = new System.Drawing.Size(100, 25);
            this.btnTenderAddGrp.TabIndex = 43;
            this.btnTenderAddGrp.Text = "Add Group";
            this.btnTenderAddGrp.UseVisualStyleBackColor = true;
            this.btnTenderAddGrp.Click += new System.EventHandler(this.btnTenderAddGrp_Click);
            // 
            // btnTenderShowImage2
            // 
            this.btnTenderShowImage2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderShowImage2.Location = new System.Drawing.Point(762, 20);
            this.btnTenderShowImage2.Name = "btnTenderShowImage2";
            this.btnTenderShowImage2.Size = new System.Drawing.Size(100, 25);
            this.btnTenderShowImage2.TabIndex = 42;
            this.btnTenderShowImage2.Text = "Show Image 2";
            this.btnTenderShowImage2.UseVisualStyleBackColor = true;
            this.btnTenderShowImage2.Click += new System.EventHandler(this.btnTenderShowImage2_Click);
            // 
            // btnTenderULImage2
            // 
            this.btnTenderULImage2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderULImage2.Location = new System.Drawing.Point(656, 20);
            this.btnTenderULImage2.Name = "btnTenderULImage2";
            this.btnTenderULImage2.Size = new System.Drawing.Size(100, 25);
            this.btnTenderULImage2.TabIndex = 41;
            this.btnTenderULImage2.Text = "Upload Image 2";
            this.btnTenderULImage2.UseVisualStyleBackColor = true;
            this.btnTenderULImage2.Click += new System.EventHandler(this.btnTenderULImage2_Click);
            // 
            // btnTenderShowImage1
            // 
            this.btnTenderShowImage1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderShowImage1.Location = new System.Drawing.Point(550, 20);
            this.btnTenderShowImage1.Name = "btnTenderShowImage1";
            this.btnTenderShowImage1.Size = new System.Drawing.Size(100, 25);
            this.btnTenderShowImage1.TabIndex = 37;
            this.btnTenderShowImage1.Text = "Show Image 1";
            this.btnTenderShowImage1.UseVisualStyleBackColor = true;
            this.btnTenderShowImage1.Click += new System.EventHandler(this.btnTenderShowImage1_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(1051, 30);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(93, 25);
            this.button5.TabIndex = 35;
            this.button5.Text = "Default";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.btnTenderDefault_Click);
            // 
            // btnTenderULImage1
            // 
            this.btnTenderULImage1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderULImage1.Location = new System.Drawing.Point(444, 20);
            this.btnTenderULImage1.Name = "btnTenderULImage1";
            this.btnTenderULImage1.Size = new System.Drawing.Size(100, 25);
            this.btnTenderULImage1.TabIndex = 31;
            this.btnTenderULImage1.Text = "Upload Image 1";
            this.btnTenderULImage1.UseVisualStyleBackColor = true;
            this.btnTenderULImage1.Click += new System.EventHandler(this.btnTenderULImage1_Click);
            // 
            // btnTenderExit
            // 
            this.btnTenderExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderExit.Location = new System.Drawing.Point(883, 20);
            this.btnTenderExit.Name = "btnTenderExit";
            this.btnTenderExit.Size = new System.Drawing.Size(100, 25);
            this.btnTenderExit.TabIndex = 30;
            this.btnTenderExit.Text = "Exit";
            this.btnTenderExit.UseVisualStyleBackColor = true;
            this.btnTenderExit.Click += new System.EventHandler(this.btnTenderExit_Click);
            // 
            // btnTenderDelete
            // 
            this.btnTenderDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderDelete.Location = new System.Drawing.Point(338, 20);
            this.btnTenderDelete.Name = "btnTenderDelete";
            this.btnTenderDelete.Size = new System.Drawing.Size(100, 25);
            this.btnTenderDelete.TabIndex = 28;
            this.btnTenderDelete.Text = "Delete";
            this.btnTenderDelete.UseVisualStyleBackColor = true;
            this.btnTenderDelete.Click += new System.EventHandler(this.btnTenderDelete_Click);
            // 
            // btnTenderUpdate
            // 
            this.btnTenderUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenderUpdate.Location = new System.Drawing.Point(232, 20);
            this.btnTenderUpdate.Name = "btnTenderUpdate";
            this.btnTenderUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnTenderUpdate.TabIndex = 27;
            this.btnTenderUpdate.Text = "Update";
            this.btnTenderUpdate.UseVisualStyleBackColor = true;
            this.btnTenderUpdate.Click += new System.EventHandler(this.btnTenderUpdate_Click);
            // 
            // splitContainer25
            // 
            this.splitContainer25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer25.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer25.IsSplitterFixed = true;
            this.splitContainer25.Location = new System.Drawing.Point(0, 0);
            this.splitContainer25.Name = "splitContainer25";
            // 
            // splitContainer25.Panel1
            // 
            this.splitContainer25.Panel1.Controls.Add(this.TVTender);
            this.splitContainer25.Panel1.Controls.Add(this.label4);
            // 
            // splitContainer25.Panel2
            // 
            this.splitContainer25.Panel2.Controls.Add(this.splitContainer26);
            this.splitContainer25.Size = new System.Drawing.Size(1068, 397);
            this.splitContainer25.SplitterDistance = 300;
            this.splitContainer25.TabIndex = 0;
            // 
            // TVTender
            // 
            this.TVTender.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVTender.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVTender.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVTender.FullRowSelect = true;
            this.TVTender.HideSelection = false;
            this.TVTender.Location = new System.Drawing.Point(0, 25);
            this.TVTender.Name = "TVTender";
            this.TVTender.Size = new System.Drawing.Size(298, 370);
            this.TVTender.TabIndex = 28;
            this.TVTender.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVTender.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVTender_MouseDoubleClick);
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(298, 25);
            this.label4.TabIndex = 50;
            this.label4.Text = "Tender";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer26
            // 
            this.splitContainer26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer26.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer26.IsSplitterFixed = true;
            this.splitContainer26.Location = new System.Drawing.Point(0, 0);
            this.splitContainer26.Name = "splitContainer26";
            this.splitContainer26.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer26.Panel1
            // 
            this.splitContainer26.Panel1.Controls.Add(this.label37);
            this.splitContainer26.Panel1.Controls.Add(this.txtTenderDesc);
            this.splitContainer26.Panel1.Controls.Add(this.CalTender);
            this.splitContainer26.Panel1.Controls.Add(this.label32);
            this.splitContainer26.Panel1.Controls.Add(this.txtTenderPrjName);
            this.splitContainer26.Panel1.Controls.Add(this.txtTenderDepName);
            this.splitContainer26.Panel1.Controls.Add(this.label33);
            this.splitContainer26.Panel1.Controls.Add(this.label34);
            this.splitContainer26.Panel1.Controls.Add(this.txtTenderPrjCoast);
            this.splitContainer26.Panel1.Controls.Add(this.label35);
            this.splitContainer26.Panel1.Controls.Add(this.txtTenderDate);
            this.splitContainer26.Size = new System.Drawing.Size(764, 397);
            this.splitContainer26.SplitterDistance = 300;
            this.splitContainer26.TabIndex = 34;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(22, 223);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(72, 16);
            this.label37.TabIndex = 222;
            this.label37.Text = "Description";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenderDesc
            // 
            this.txtTenderDesc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderDesc.Location = new System.Drawing.Point(19, 241);
            this.txtTenderDesc.Multiline = true;
            this.txtTenderDesc.Name = "txtTenderDesc";
            this.txtTenderDesc.Size = new System.Drawing.Size(874, 91);
            this.txtTenderDesc.TabIndex = 223;
            // 
            // CalTender
            // 
            this.CalTender.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalTender.Location = new System.Drawing.Point(155, 24);
            this.CalTender.Name = "CalTender";
            this.CalTender.TabIndex = 218;
            this.CalTender.Visible = false;
            this.CalTender.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.CalTender_DateSelected);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(22, 67);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(86, 16);
            this.label32.TabIndex = 38;
            this.label32.Text = "Project Name";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenderPrjName
            // 
            this.txtTenderPrjName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderPrjName.Location = new System.Drawing.Point(19, 85);
            this.txtTenderPrjName.Name = "txtTenderPrjName";
            this.txtTenderPrjName.Size = new System.Drawing.Size(874, 22);
            this.txtTenderPrjName.TabIndex = 39;
            // 
            // txtTenderDepName
            // 
            this.txtTenderDepName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderDepName.Location = new System.Drawing.Point(19, 134);
            this.txtTenderDepName.Name = "txtTenderDepName";
            this.txtTenderDepName.Size = new System.Drawing.Size(874, 22);
            this.txtTenderDepName.TabIndex = 35;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(22, 169);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(79, 16);
            this.label33.TabIndex = 36;
            this.label33.Text = "Project Cost";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(22, 116);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(112, 16);
            this.label34.TabIndex = 34;
            this.label34.Text = "Department Name";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenderPrjCoast
            // 
            this.txtTenderPrjCoast.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderPrjCoast.Location = new System.Drawing.Point(19, 187);
            this.txtTenderPrjCoast.Name = "txtTenderPrjCoast";
            this.txtTenderPrjCoast.Size = new System.Drawing.Size(874, 22);
            this.txtTenderPrjCoast.TabIndex = 37;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(22, 15);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(34, 16);
            this.label35.TabIndex = 28;
            this.label35.Text = "Date";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenderDate
            // 
            this.txtTenderDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderDate.Location = new System.Drawing.Point(19, 33);
            this.txtTenderDate.Name = "txtTenderDate";
            this.txtTenderDate.Size = new System.Drawing.Size(182, 22);
            this.txtTenderDate.TabIndex = 29;
            this.txtTenderDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtTenderDate_MouseDoubleClick);
            // 
            // tabReview
            // 
            this.tabReview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabReview.Controls.Add(this.splitContainer7);
            this.tabReview.Location = new System.Drawing.Point(4, 22);
            this.tabReview.Name = "tabReview";
            this.tabReview.Padding = new System.Windows.Forms.Padding(3);
            this.tabReview.Size = new System.Drawing.Size(1076, 469);
            this.tabReview.TabIndex = 4;
            this.tabReview.Text = "Review";
            this.tabReview.UseVisualStyleBackColor = true;
            // 
            // splitContainer7
            // 
            this.splitContainer7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer7.IsSplitterFixed = true;
            this.splitContainer7.Location = new System.Drawing.Point(3, 3);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.btnReviewDown);
            this.splitContainer7.Panel1.Controls.Add(this.btnReviewUp);
            this.splitContainer7.Panel1.Controls.Add(this.btnReviewExit);
            this.splitContainer7.Panel1.Controls.Add(this.btnReviewDelete);
            this.splitContainer7.Panel1.Controls.Add(this.btnReviewAdd);
            this.splitContainer7.Panel1.Controls.Add(this.btnReviewUpdate);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.splitContainer8);
            this.splitContainer7.Size = new System.Drawing.Size(1068, 461);
            this.splitContainer7.SplitterDistance = 60;
            this.splitContainer7.TabIndex = 1;
            // 
            // btnReviewDown
            // 
            this.btnReviewDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviewDown.Location = new System.Drawing.Point(394, 20);
            this.btnReviewDown.Name = "btnReviewDown";
            this.btnReviewDown.Size = new System.Drawing.Size(50, 25);
            this.btnReviewDown.TabIndex = 44;
            this.btnReviewDown.Text = "\\/";
            this.btnReviewDown.UseVisualStyleBackColor = true;
            this.btnReviewDown.Click += new System.EventHandler(this.btnReviewDown_Click);
            // 
            // btnReviewUp
            // 
            this.btnReviewUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviewUp.Location = new System.Drawing.Point(338, 20);
            this.btnReviewUp.Name = "btnReviewUp";
            this.btnReviewUp.Size = new System.Drawing.Size(50, 25);
            this.btnReviewUp.TabIndex = 43;
            this.btnReviewUp.Text = "/\\";
            this.btnReviewUp.UseVisualStyleBackColor = true;
            this.btnReviewUp.Click += new System.EventHandler(this.btnReviewUp_Click);
            // 
            // btnReviewExit
            // 
            this.btnReviewExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviewExit.Location = new System.Drawing.Point(883, 20);
            this.btnReviewExit.Name = "btnReviewExit";
            this.btnReviewExit.Size = new System.Drawing.Size(100, 25);
            this.btnReviewExit.TabIndex = 30;
            this.btnReviewExit.Text = "Exit";
            this.btnReviewExit.UseVisualStyleBackColor = true;
            this.btnReviewExit.Click += new System.EventHandler(this.btnReviewExit_Click);
            // 
            // btnReviewDelete
            // 
            this.btnReviewDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviewDelete.Location = new System.Drawing.Point(232, 20);
            this.btnReviewDelete.Name = "btnReviewDelete";
            this.btnReviewDelete.Size = new System.Drawing.Size(100, 25);
            this.btnReviewDelete.TabIndex = 28;
            this.btnReviewDelete.Text = "Delete";
            this.btnReviewDelete.UseVisualStyleBackColor = true;
            this.btnReviewDelete.Click += new System.EventHandler(this.btnReviewDelete_Click);
            // 
            // btnReviewAdd
            // 
            this.btnReviewAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviewAdd.Location = new System.Drawing.Point(20, 20);
            this.btnReviewAdd.Name = "btnReviewAdd";
            this.btnReviewAdd.Size = new System.Drawing.Size(100, 25);
            this.btnReviewAdd.TabIndex = 29;
            this.btnReviewAdd.Text = "Add";
            this.btnReviewAdd.UseVisualStyleBackColor = true;
            this.btnReviewAdd.Click += new System.EventHandler(this.btnReviewAdd_Click);
            // 
            // btnReviewUpdate
            // 
            this.btnReviewUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviewUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnReviewUpdate.Name = "btnReviewUpdate";
            this.btnReviewUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnReviewUpdate.TabIndex = 27;
            this.btnReviewUpdate.Text = "Update";
            this.btnReviewUpdate.UseVisualStyleBackColor = true;
            this.btnReviewUpdate.Click += new System.EventHandler(this.btnReviewUpdate_Click);
            // 
            // splitContainer8
            // 
            this.splitContainer8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer8.IsSplitterFixed = true;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Name = "splitContainer8";
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.TVReview);
            this.splitContainer8.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer8.Size = new System.Drawing.Size(1068, 397);
            this.splitContainer8.SplitterDistance = 300;
            this.splitContainer8.TabIndex = 0;
            // 
            // TVReview
            // 
            this.TVReview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVReview.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVReview.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVReview.FullRowSelect = true;
            this.TVReview.HideSelection = false;
            this.TVReview.Location = new System.Drawing.Point(0, 25);
            this.TVReview.Name = "TVReview";
            this.TVReview.Size = new System.Drawing.Size(298, 370);
            this.TVReview.TabIndex = 28;
            this.TVReview.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVReview.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVReview_MouseDoubleClick);
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(298, 25);
            this.label3.TabIndex = 50;
            this.label3.Text = "Reviews";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.label15);
            this.splitContainer3.Panel1.Controls.Add(this.CalReview);
            this.splitContainer3.Panel1.Controls.Add(this.txtReviewSubTitle);
            this.splitContainer3.Panel1.Controls.Add(this.label10);
            this.splitContainer3.Panel1.Controls.Add(this.txtReviewDate);
            this.splitContainer3.Panel1.Controls.Add(this.label7);
            this.splitContainer3.Panel1.Controls.Add(this.label6);
            this.splitContainer3.Panel1.Controls.Add(this.txtReviewTitle);
            this.splitContainer3.Panel1.Controls.Add(this.txtReviewDesc);
            this.splitContainer3.Size = new System.Drawing.Size(764, 397);
            this.splitContainer3.SplitterDistance = 300;
            this.splitContainer3.TabIndex = 300;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(22, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 16);
            this.label15.TabIndex = 218;
            this.label15.Text = "Date";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CalReview
            // 
            this.CalReview.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalReview.Location = new System.Drawing.Point(169, 19);
            this.CalReview.Name = "CalReview";
            this.CalReview.TabIndex = 220;
            this.CalReview.Visible = false;
            this.CalReview.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.CalReview_DateSelected);
            // 
            // txtReviewSubTitle
            // 
            this.txtReviewSubTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReviewSubTitle.Location = new System.Drawing.Point(19, 134);
            this.txtReviewSubTitle.Name = "txtReviewSubTitle";
            this.txtReviewSubTitle.Size = new System.Drawing.Size(713, 22);
            this.txtReviewSubTitle.TabIndex = 31;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(22, 169);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 16);
            this.label10.TabIndex = 38;
            this.label10.Text = "Description";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtReviewDate
            // 
            this.txtReviewDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReviewDate.Location = new System.Drawing.Point(19, 33);
            this.txtReviewDate.Name = "txtReviewDate";
            this.txtReviewDate.Size = new System.Drawing.Size(109, 22);
            this.txtReviewDate.TabIndex = 219;
            this.txtReviewDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtReviewDate_MouseDoubleClick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 16);
            this.label7.TabIndex = 30;
            this.label7.Text = "SubTitle";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(22, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 16);
            this.label6.TabIndex = 28;
            this.label6.Text = "Title";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtReviewTitle
            // 
            this.txtReviewTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReviewTitle.Location = new System.Drawing.Point(19, 85);
            this.txtReviewTitle.Name = "txtReviewTitle";
            this.txtReviewTitle.Size = new System.Drawing.Size(713, 22);
            this.txtReviewTitle.TabIndex = 29;
            // 
            // txtReviewDesc
            // 
            this.txtReviewDesc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReviewDesc.Location = new System.Drawing.Point(19, 187);
            this.txtReviewDesc.Multiline = true;
            this.txtReviewDesc.Name = "txtReviewDesc";
            this.txtReviewDesc.Size = new System.Drawing.Size(713, 93);
            this.txtReviewDesc.TabIndex = 39;
            // 
            // tabNews
            // 
            this.tabNews.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabNews.Controls.Add(this.splitContainer1);
            this.tabNews.Location = new System.Drawing.Point(4, 22);
            this.tabNews.Name = "tabNews";
            this.tabNews.Padding = new System.Windows.Forms.Padding(3);
            this.tabNews.Size = new System.Drawing.Size(1076, 469);
            this.tabNews.TabIndex = 1;
            this.tabNews.Text = "News";
            this.tabNews.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnNewsDefault);
            this.splitContainer1.Panel1.Controls.Add(this.btnNewsShowByDate);
            this.splitContainer1.Panel1.Controls.Add(this.label11);
            this.splitContainer1.Panel1.Controls.Add(this.txtNewsShowByDate);
            this.splitContainer1.Panel1.Controls.Add(this.btnNewsExit);
            this.splitContainer1.Panel1.Controls.Add(this.btnNewsDelete);
            this.splitContainer1.Panel1.Controls.Add(this.btnNewsAdd);
            this.splitContainer1.Panel1.Controls.Add(this.btnNewsUpdate);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1068, 461);
            this.splitContainer1.SplitterDistance = 60;
            this.splitContainer1.TabIndex = 0;
            // 
            // btnNewsDefault
            // 
            this.btnNewsDefault.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewsDefault.Location = new System.Drawing.Point(777, 20);
            this.btnNewsDefault.Name = "btnNewsDefault";
            this.btnNewsDefault.Size = new System.Drawing.Size(100, 25);
            this.btnNewsDefault.TabIndex = 34;
            this.btnNewsDefault.Text = "Default";
            this.btnNewsDefault.UseVisualStyleBackColor = true;
            this.btnNewsDefault.Click += new System.EventHandler(this.btnNewsDefault_Click);
            // 
            // btnNewsShowByDate
            // 
            this.btnNewsShowByDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewsShowByDate.Location = new System.Drawing.Point(618, 20);
            this.btnNewsShowByDate.Name = "btnNewsShowByDate";
            this.btnNewsShowByDate.Size = new System.Drawing.Size(100, 25);
            this.btnNewsShowByDate.TabIndex = 33;
            this.btnNewsShowByDate.Text = "Show By Date";
            this.btnNewsShowByDate.UseVisualStyleBackColor = true;
            this.btnNewsShowByDate.Click += new System.EventHandler(this.btnNewsShowByDate_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(508, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 16);
            this.label11.TabIndex = 31;
            this.label11.Text = "Date";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtNewsShowByDate
            // 
            this.txtNewsShowByDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewsShowByDate.Location = new System.Drawing.Point(503, 23);
            this.txtNewsShowByDate.Name = "txtNewsShowByDate";
            this.txtNewsShowByDate.Size = new System.Drawing.Size(109, 22);
            this.txtNewsShowByDate.TabIndex = 32;
            this.txtNewsShowByDate.DoubleClick += new System.EventHandler(this.txtNewsShowByDate_DoubleClick);
            // 
            // btnNewsExit
            // 
            this.btnNewsExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewsExit.Location = new System.Drawing.Point(883, 20);
            this.btnNewsExit.Name = "btnNewsExit";
            this.btnNewsExit.Size = new System.Drawing.Size(100, 25);
            this.btnNewsExit.TabIndex = 30;
            this.btnNewsExit.Text = "Exit";
            this.btnNewsExit.UseVisualStyleBackColor = true;
            this.btnNewsExit.Click += new System.EventHandler(this.btnNewsExit_Click);
            // 
            // btnNewsDelete
            // 
            this.btnNewsDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewsDelete.Location = new System.Drawing.Point(232, 20);
            this.btnNewsDelete.Name = "btnNewsDelete";
            this.btnNewsDelete.Size = new System.Drawing.Size(100, 25);
            this.btnNewsDelete.TabIndex = 28;
            this.btnNewsDelete.Text = "Delete";
            this.btnNewsDelete.UseVisualStyleBackColor = true;
            this.btnNewsDelete.Click += new System.EventHandler(this.btnNewsDelete_Click);
            // 
            // btnNewsAdd
            // 
            this.btnNewsAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewsAdd.Location = new System.Drawing.Point(20, 20);
            this.btnNewsAdd.Name = "btnNewsAdd";
            this.btnNewsAdd.Size = new System.Drawing.Size(100, 25);
            this.btnNewsAdd.TabIndex = 29;
            this.btnNewsAdd.Text = "Add";
            this.btnNewsAdd.UseVisualStyleBackColor = true;
            this.btnNewsAdd.Click += new System.EventHandler(this.btnNewsAdd_Click);
            // 
            // btnNewsUpdate
            // 
            this.btnNewsUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewsUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnNewsUpdate.Name = "btnNewsUpdate";
            this.btnNewsUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnNewsUpdate.TabIndex = 27;
            this.btnNewsUpdate.Text = "Update";
            this.btnNewsUpdate.UseVisualStyleBackColor = true;
            this.btnNewsUpdate.Click += new System.EventHandler(this.btnNewsUpdate_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.TVNews);
            this.splitContainer2.Panel1.Controls.Add(this.label5);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer9);
            this.splitContainer2.Size = new System.Drawing.Size(1068, 397);
            this.splitContainer2.SplitterDistance = 300;
            this.splitContainer2.TabIndex = 0;
            // 
            // TVNews
            // 
            this.TVNews.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVNews.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVNews.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVNews.FullRowSelect = true;
            this.TVNews.HideSelection = false;
            this.TVNews.Location = new System.Drawing.Point(0, 25);
            this.TVNews.Name = "TVNews";
            this.TVNews.Size = new System.Drawing.Size(298, 370);
            this.TVNews.TabIndex = 28;
            this.TVNews.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVNews.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVNews_MouseDoubleClick);
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(298, 25);
            this.label5.TabIndex = 50;
            this.label5.Text = "News";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer9
            // 
            this.splitContainer9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer9.IsSplitterFixed = true;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.chkNewsLinkFlag);
            this.splitContainer9.Panel1.Controls.Add(this.xCalNews);
            this.splitContainer9.Panel1.Controls.Add(this.txtNewsSubTitle);
            this.splitContainer9.Panel1.Controls.Add(this.label9);
            this.splitContainer9.Panel1.Controls.Add(this.label24);
            this.splitContainer9.Panel1.Controls.Add(this.txtNewsDate);
            this.splitContainer9.Panel1.Controls.Add(this.txtNewsLinkAddress);
            this.splitContainer9.Panel1.Controls.Add(this.txtNewsTitle);
            this.splitContainer9.Panel1.Controls.Add(this.label20);
            this.splitContainer9.Panel1.Controls.Add(this.label1);
            this.splitContainer9.Panel1.Controls.Add(this.label26);
            this.splitContainer9.Panel1.Controls.Add(this.txtNewsSource);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.Controls.Add(this.webBrowserNews);
            this.splitContainer9.Panel2.Controls.Add(this.NewsDGV);
            this.splitContainer9.Size = new System.Drawing.Size(764, 397);
            this.splitContainer9.SplitterDistance = 300;
            this.splitContainer9.TabIndex = 218;
            // 
            // chkNewsLinkFlag
            // 
            this.chkNewsLinkFlag.AutoSize = true;
            this.chkNewsLinkFlag.Location = new System.Drawing.Point(707, 190);
            this.chkNewsLinkFlag.Name = "chkNewsLinkFlag";
            this.chkNewsLinkFlag.Size = new System.Drawing.Size(66, 17);
            this.chkNewsLinkFlag.TabIndex = 220;
            this.chkNewsLinkFlag.Text = "LinkFlag";
            this.chkNewsLinkFlag.UseVisualStyleBackColor = true;
            // 
            // xCalNews
            // 
            this.xCalNews.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xCalNews.Location = new System.Drawing.Point(149, 23);
            this.xCalNews.Name = "xCalNews";
            this.xCalNews.TabIndex = 217;
            this.xCalNews.Visible = false;
            this.xCalNews.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.xCalNews_DateSelected);
            // 
            // txtNewsSubTitle
            // 
            this.txtNewsSubTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewsSubTitle.Location = new System.Drawing.Point(19, 85);
            this.txtNewsSubTitle.Name = "txtNewsSubTitle";
            this.txtNewsSubTitle.Size = new System.Drawing.Size(752, 22);
            this.txtNewsSubTitle.TabIndex = 219;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(22, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 16);
            this.label9.TabIndex = 218;
            this.label9.Text = "SubTitle";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(22, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 16);
            this.label24.TabIndex = 28;
            this.label24.Text = "Date";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtNewsDate
            // 
            this.txtNewsDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewsDate.Location = new System.Drawing.Point(19, 33);
            this.txtNewsDate.Name = "txtNewsDate";
            this.txtNewsDate.Size = new System.Drawing.Size(109, 22);
            this.txtNewsDate.TabIndex = 29;
            this.txtNewsDate.DoubleClick += new System.EventHandler(this.txtNewsDate_DoubleClick);
            // 
            // txtNewsLinkAddress
            // 
            this.txtNewsLinkAddress.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewsLinkAddress.Location = new System.Drawing.Point(19, 187);
            this.txtNewsLinkAddress.Name = "txtNewsLinkAddress";
            this.txtNewsLinkAddress.Size = new System.Drawing.Size(680, 22);
            this.txtNewsLinkAddress.TabIndex = 35;
            this.txtNewsLinkAddress.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtNewsLinkAddress_MouseDoubleClick);
            // 
            // txtNewsTitle
            // 
            this.txtNewsTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewsTitle.Location = new System.Drawing.Point(146, 33);
            this.txtNewsTitle.Name = "txtNewsTitle";
            this.txtNewsTitle.Size = new System.Drawing.Size(625, 22);
            this.txtNewsTitle.TabIndex = 31;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(22, 169);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(306, 16);
            this.label20.TabIndex = 34;
            this.label20.Text = "Link Address (double click the link to view the page)";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "Source";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(149, 15);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(31, 16);
            this.label26.TabIndex = 30;
            this.label26.Text = "Title";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtNewsSource
            // 
            this.txtNewsSource.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewsSource.Location = new System.Drawing.Point(19, 134);
            this.txtNewsSource.Name = "txtNewsSource";
            this.txtNewsSource.Size = new System.Drawing.Size(752, 22);
            this.txtNewsSource.TabIndex = 33;
            // 
            // webBrowserNews
            // 
            this.webBrowserNews.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserNews.Location = new System.Drawing.Point(0, 0);
            this.webBrowserNews.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserNews.Name = "webBrowserNews";
            this.webBrowserNews.Size = new System.Drawing.Size(762, 91);
            this.webBrowserNews.TabIndex = 1;
            this.webBrowserNews.Visible = false;
            // 
            // NewsDGV
            // 
            this.NewsDGV.BackgroundColor = System.Drawing.Color.White;
            this.NewsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.NewsDGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NewsDGV.Location = new System.Drawing.Point(0, 0);
            this.NewsDGV.Name = "NewsDGV";
            this.NewsDGV.RowHeadersWidth = 51;
            this.NewsDGV.Size = new System.Drawing.Size(762, 91);
            this.NewsDGV.TabIndex = 0;
            this.NewsDGV.Visible = false;
            // 
            // TC
            // 
            this.TC.Controls.Add(this.tabNews);
            this.TC.Controls.Add(this.tabReview);
            this.TC.Controls.Add(this.tabTender);
            this.TC.Controls.Add(this.tabTenderBidders);
            this.TC.Controls.Add(this.tabSuccessFulStories);
            this.TC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TC.Location = new System.Drawing.Point(0, 0);
            this.TC.Name = "TC";
            this.TC.SelectedIndex = 0;
            this.TC.Size = new System.Drawing.Size(1084, 495);
            this.TC.TabIndex = 0;
            this.TC.SelectedIndexChanged += new System.EventHandler(this.TC_SelectedIndexChanged);
            // 
            // tabSuccessFulStories
            // 
            this.tabSuccessFulStories.Controls.Add(this.splitContainer5);
            this.tabSuccessFulStories.Location = new System.Drawing.Point(4, 22);
            this.tabSuccessFulStories.Name = "tabSuccessFulStories";
            this.tabSuccessFulStories.Size = new System.Drawing.Size(1076, 469);
            this.tabSuccessFulStories.TabIndex = 12;
            this.tabSuccessFulStories.Text = "SuccessFul Stories";
            this.tabSuccessFulStories.UseVisualStyleBackColor = true;
            // 
            // splitContainer5
            // 
            this.splitContainer5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.IsSplitterFixed = true;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesShowLogo);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesUploadLogo);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesDown);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesUp);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesShowImage);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesAddGrp);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesExit);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesUploadImage);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesDelete);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesAdd);
            this.splitContainer5.Panel1.Controls.Add(this.btnSuccessFulStoriesUpdate);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer5.Size = new System.Drawing.Size(1076, 469);
            this.splitContainer5.SplitterDistance = 60;
            this.splitContainer5.TabIndex = 2;
            // 
            // btnSuccessFulStoriesShowLogo
            // 
            this.btnSuccessFulStoriesShowLogo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesShowLogo.Location = new System.Drawing.Point(762, 20);
            this.btnSuccessFulStoriesShowLogo.Name = "btnSuccessFulStoriesShowLogo";
            this.btnSuccessFulStoriesShowLogo.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesShowLogo.TabIndex = 42;
            this.btnSuccessFulStoriesShowLogo.Text = "Show Logo";
            this.btnSuccessFulStoriesShowLogo.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesShowLogo.Click += new System.EventHandler(this.btnSuccessFulStoriesShowLogo_Click);
            // 
            // btnSuccessFulStoriesUploadLogo
            // 
            this.btnSuccessFulStoriesUploadLogo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesUploadLogo.Location = new System.Drawing.Point(656, 20);
            this.btnSuccessFulStoriesUploadLogo.Name = "btnSuccessFulStoriesUploadLogo";
            this.btnSuccessFulStoriesUploadLogo.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesUploadLogo.TabIndex = 41;
            this.btnSuccessFulStoriesUploadLogo.Text = "Upload Logo";
            this.btnSuccessFulStoriesUploadLogo.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesUploadLogo.Click += new System.EventHandler(this.btnSuccessFulStoriesUploadLogo_Click);
            // 
            // btnSuccessFulStoriesDown
            // 
            this.btnSuccessFulStoriesDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesDown.Location = new System.Drawing.Point(924, 20);
            this.btnSuccessFulStoriesDown.Name = "btnSuccessFulStoriesDown";
            this.btnSuccessFulStoriesDown.Size = new System.Drawing.Size(50, 25);
            this.btnSuccessFulStoriesDown.TabIndex = 40;
            this.btnSuccessFulStoriesDown.Text = "\\/";
            this.btnSuccessFulStoriesDown.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesDown.Click += new System.EventHandler(this.btnSuccessFulStoriesDown_Click);
            // 
            // btnSuccessFulStoriesUp
            // 
            this.btnSuccessFulStoriesUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesUp.Location = new System.Drawing.Point(865, 20);
            this.btnSuccessFulStoriesUp.Name = "btnSuccessFulStoriesUp";
            this.btnSuccessFulStoriesUp.Size = new System.Drawing.Size(50, 25);
            this.btnSuccessFulStoriesUp.TabIndex = 39;
            this.btnSuccessFulStoriesUp.Text = "/\\";
            this.btnSuccessFulStoriesUp.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesUp.Click += new System.EventHandler(this.btnSuccessFulStoriesUp_Click);
            // 
            // btnSuccessFulStoriesShowImage
            // 
            this.btnSuccessFulStoriesShowImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesShowImage.Location = new System.Drawing.Point(550, 20);
            this.btnSuccessFulStoriesShowImage.Name = "btnSuccessFulStoriesShowImage";
            this.btnSuccessFulStoriesShowImage.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesShowImage.TabIndex = 37;
            this.btnSuccessFulStoriesShowImage.Text = "Show Image";
            this.btnSuccessFulStoriesShowImage.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesShowImage.Click += new System.EventHandler(this.btnSuccessFulStoriesShowImage_Click);
            // 
            // btnSuccessFulStoriesAddGrp
            // 
            this.btnSuccessFulStoriesAddGrp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesAddGrp.Location = new System.Drawing.Point(20, 20);
            this.btnSuccessFulStoriesAddGrp.Name = "btnSuccessFulStoriesAddGrp";
            this.btnSuccessFulStoriesAddGrp.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesAddGrp.TabIndex = 36;
            this.btnSuccessFulStoriesAddGrp.Text = "Add Group";
            this.btnSuccessFulStoriesAddGrp.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesAddGrp.Click += new System.EventHandler(this.btnSuccessFulStoriesAddGrp_Click);
            // 
            // btnSuccessFulStoriesExit
            // 
            this.btnSuccessFulStoriesExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesExit.Location = new System.Drawing.Point(980, 20);
            this.btnSuccessFulStoriesExit.Name = "btnSuccessFulStoriesExit";
            this.btnSuccessFulStoriesExit.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesExit.TabIndex = 35;
            this.btnSuccessFulStoriesExit.Text = "Exit";
            this.btnSuccessFulStoriesExit.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesExit.Click += new System.EventHandler(this.btnSuccessFulStoriesExit_Click);
            // 
            // btnSuccessFulStoriesUploadImage
            // 
            this.btnSuccessFulStoriesUploadImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesUploadImage.Location = new System.Drawing.Point(444, 20);
            this.btnSuccessFulStoriesUploadImage.Name = "btnSuccessFulStoriesUploadImage";
            this.btnSuccessFulStoriesUploadImage.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesUploadImage.TabIndex = 31;
            this.btnSuccessFulStoriesUploadImage.Text = "Upload Image";
            this.btnSuccessFulStoriesUploadImage.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesUploadImage.Click += new System.EventHandler(this.btnSuccessFulStoriesUploadImage_Click);
            // 
            // btnSuccessFulStoriesDelete
            // 
            this.btnSuccessFulStoriesDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesDelete.Location = new System.Drawing.Point(338, 20);
            this.btnSuccessFulStoriesDelete.Name = "btnSuccessFulStoriesDelete";
            this.btnSuccessFulStoriesDelete.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesDelete.TabIndex = 28;
            this.btnSuccessFulStoriesDelete.Text = "Delete";
            this.btnSuccessFulStoriesDelete.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesDelete.Click += new System.EventHandler(this.btnSuccessFulStoriesDelete_Click);
            // 
            // btnSuccessFulStoriesAdd
            // 
            this.btnSuccessFulStoriesAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesAdd.Location = new System.Drawing.Point(126, 20);
            this.btnSuccessFulStoriesAdd.Name = "btnSuccessFulStoriesAdd";
            this.btnSuccessFulStoriesAdd.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesAdd.TabIndex = 29;
            this.btnSuccessFulStoriesAdd.Text = "Add";
            this.btnSuccessFulStoriesAdd.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesAdd.Click += new System.EventHandler(this.btnSuccessFulStoriesAdd_Click);
            // 
            // btnSuccessFulStoriesUpdate
            // 
            this.btnSuccessFulStoriesUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuccessFulStoriesUpdate.Location = new System.Drawing.Point(232, 20);
            this.btnSuccessFulStoriesUpdate.Name = "btnSuccessFulStoriesUpdate";
            this.btnSuccessFulStoriesUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnSuccessFulStoriesUpdate.TabIndex = 27;
            this.btnSuccessFulStoriesUpdate.Text = "Update";
            this.btnSuccessFulStoriesUpdate.UseVisualStyleBackColor = true;
            this.btnSuccessFulStoriesUpdate.Click += new System.EventHandler(this.btnSuccessFulStoriesUpdate_Click);
            // 
            // splitContainer6
            // 
            this.splitContainer6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer6.IsSplitterFixed = true;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.TVSuccessFulStories);
            this.splitContainer6.Panel1.Controls.Add(this.label8);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.splitContainer11);
            this.splitContainer6.Size = new System.Drawing.Size(1076, 405);
            this.splitContainer6.SplitterDistance = 300;
            this.splitContainer6.TabIndex = 0;
            // 
            // TVSuccessFulStories
            // 
            this.TVSuccessFulStories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVSuccessFulStories.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVSuccessFulStories.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVSuccessFulStories.FullRowSelect = true;
            this.TVSuccessFulStories.HideSelection = false;
            this.TVSuccessFulStories.Location = new System.Drawing.Point(0, 25);
            this.TVSuccessFulStories.Name = "TVSuccessFulStories";
            this.TVSuccessFulStories.Size = new System.Drawing.Size(298, 378);
            this.TVSuccessFulStories.TabIndex = 28;
            this.TVSuccessFulStories.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVSuccessFulStories.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVSuccessFulStories_MouseDoubleClick);
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(298, 25);
            this.label8.TabIndex = 44;
            this.label8.Text = "SuccessFulStories";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer11
            // 
            this.splitContainer11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer11.IsSplitterFixed = true;
            this.splitContainer11.Location = new System.Drawing.Point(0, 0);
            this.splitContainer11.Name = "splitContainer11";
            this.splitContainer11.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.label66);
            this.splitContainer11.Panel1.Controls.Add(this.txtSuccessFulStoriesCompanyName);
            this.splitContainer11.Panel1.Controls.Add(this.label12);
            this.splitContainer11.Panel1.Controls.Add(this.txtSuccessFulStoriesSubTitle);
            this.splitContainer11.Panel1.Controls.Add(this.txtSuccessFulStoriesDesc);
            this.splitContainer11.Panel1.Controls.Add(this.label14);
            this.splitContainer11.Panel1.Controls.Add(this.label17);
            this.splitContainer11.Panel1.Controls.Add(this.txtSuccessFulStoriesTiltle);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.webBrowserCompany);
            this.splitContainer11.Size = new System.Drawing.Size(772, 405);
            this.splitContainer11.SplitterDistance = 275;
            this.splitContainer11.TabIndex = 34;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(22, 127);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(100, 16);
            this.label66.TabIndex = 222;
            this.label66.Text = "Company Name";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSuccessFulStoriesCompanyName
            // 
            this.txtSuccessFulStoriesCompanyName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSuccessFulStoriesCompanyName.Location = new System.Drawing.Point(19, 146);
            this.txtSuccessFulStoriesCompanyName.Multiline = true;
            this.txtSuccessFulStoriesCompanyName.Name = "txtSuccessFulStoriesCompanyName";
            this.txtSuccessFulStoriesCompanyName.Size = new System.Drawing.Size(402, 35);
            this.txtSuccessFulStoriesCompanyName.TabIndex = 223;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 16);
            this.label12.TabIndex = 38;
            this.label12.Text = "Sub Title";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSuccessFulStoriesSubTitle
            // 
            this.txtSuccessFulStoriesSubTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSuccessFulStoriesSubTitle.Location = new System.Drawing.Point(19, 84);
            this.txtSuccessFulStoriesSubTitle.Multiline = true;
            this.txtSuccessFulStoriesSubTitle.Name = "txtSuccessFulStoriesSubTitle";
            this.txtSuccessFulStoriesSubTitle.Size = new System.Drawing.Size(402, 36);
            this.txtSuccessFulStoriesSubTitle.TabIndex = 39;
            // 
            // txtSuccessFulStoriesDesc
            // 
            this.txtSuccessFulStoriesDesc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSuccessFulStoriesDesc.Location = new System.Drawing.Point(19, 205);
            this.txtSuccessFulStoriesDesc.Multiline = true;
            this.txtSuccessFulStoriesDesc.Name = "txtSuccessFulStoriesDesc";
            this.txtSuccessFulStoriesDesc.Size = new System.Drawing.Size(607, 59);
            this.txtSuccessFulStoriesDesc.TabIndex = 35;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(22, 186);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 16);
            this.label14.TabIndex = 34;
            this.label14.Text = "Description";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(22, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(31, 16);
            this.label17.TabIndex = 28;
            this.label17.Text = "Title";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSuccessFulStoriesTiltle
            // 
            this.txtSuccessFulStoriesTiltle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSuccessFulStoriesTiltle.Location = new System.Drawing.Point(19, 33);
            this.txtSuccessFulStoriesTiltle.Name = "txtSuccessFulStoriesTiltle";
            this.txtSuccessFulStoriesTiltle.Size = new System.Drawing.Size(607, 22);
            this.txtSuccessFulStoriesTiltle.TabIndex = 29;
            // 
            // webBrowserCompany
            // 
            this.webBrowserCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserCompany.Location = new System.Drawing.Point(0, 0);
            this.webBrowserCompany.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserCompany.Name = "webBrowserCompany";
            this.webBrowserCompany.Size = new System.Drawing.Size(770, 124);
            this.webBrowserCompany.TabIndex = 46;
            // 
            // frmNews
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1084, 495);
            this.Controls.Add(this.TC);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmNews";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CQ_Portal";
            this.Load += new System.EventHandler(this.frmNews_Load);
            this.tabTenderBidders.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer28.Panel1.ResumeLayout(false);
            this.splitContainer28.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer28)).EndInit();
            this.splitContainer28.ResumeLayout(false);
            this.splitContainer29.Panel1.ResumeLayout(false);
            this.splitContainer29.Panel1.PerformLayout();
            this.splitContainer29.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer29)).EndInit();
            this.splitContainer29.ResumeLayout(false);
            this.tabTender.ResumeLayout(false);
            this.splitContainer24.Panel1.ResumeLayout(false);
            this.splitContainer24.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer24)).EndInit();
            this.splitContainer24.ResumeLayout(false);
            this.splitContainer25.Panel1.ResumeLayout(false);
            this.splitContainer25.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer25)).EndInit();
            this.splitContainer25.ResumeLayout(false);
            this.splitContainer26.Panel1.ResumeLayout(false);
            this.splitContainer26.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer26)).EndInit();
            this.splitContainer26.ResumeLayout(false);
            this.tabReview.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tabNews.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            this.splitContainer9.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.NewsDGV)).EndInit();
            this.TC.ResumeLayout(false);
            this.tabSuccessFulStories.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel1.PerformLayout();
            this.splitContainer11.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog mOpenFile;
        private System.Windows.Forms.TabPage tabTenderBidders;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Button btnTenderBiddersDefault;
        private System.Windows.Forms.Button btnTenderBiddersExit;
        private System.Windows.Forms.Button btnTenderBiddersDelete;
        private System.Windows.Forms.Button btnTenderBiddersAdd;
        private System.Windows.Forms.Button btnTenderBiddersUpdate;
        private System.Windows.Forms.SplitContainer splitContainer28;
        private System.Windows.Forms.TreeView TVTenderBiddersTender;
        private System.Windows.Forms.SplitContainer splitContainer29;
        private System.Windows.Forms.MonthCalendar CalTenderBidders;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtTenderBiddersBidValue;
        private System.Windows.Forms.TextBox txtTenderBiddersPerVari;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtTenderBiddersDate;
        private System.Windows.Forms.TreeView TVTenderBiddersCompany;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tabTender;
        private System.Windows.Forms.SplitContainer splitContainer24;
        private System.Windows.Forms.Button btnTenderAdd;
        private System.Windows.Forms.Button btnTenderAddGrp;
        private System.Windows.Forms.Button btnTenderShowImage2;
        private System.Windows.Forms.Button btnTenderULImage2;
        private System.Windows.Forms.Button btnTenderShowImage1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnTenderULImage1;
        private System.Windows.Forms.Button btnTenderExit;
        private System.Windows.Forms.Button btnTenderDelete;
        private System.Windows.Forms.Button btnTenderUpdate;
        private System.Windows.Forms.SplitContainer splitContainer25;
        private System.Windows.Forms.TreeView TVTender;
        private System.Windows.Forms.SplitContainer splitContainer26;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtTenderDesc;
        private System.Windows.Forms.MonthCalendar CalTender;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtTenderPrjName;
        private System.Windows.Forms.TextBox txtTenderDepName;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtTenderPrjCoast;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtTenderDate;
        private System.Windows.Forms.TabPage tabReview;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.Button btnReviewDown;
        private System.Windows.Forms.Button btnReviewUp;
        private System.Windows.Forms.Button btnReviewExit;
        private System.Windows.Forms.Button btnReviewDelete;
        private System.Windows.Forms.Button btnReviewAdd;
        private System.Windows.Forms.Button btnReviewUpdate;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.TreeView TVReview;
        private System.Windows.Forms.MonthCalendar CalReview;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtReviewDate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtReviewDesc;
        private System.Windows.Forms.TextBox txtReviewTitle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtReviewSubTitle;
        private System.Windows.Forms.TabPage tabNews;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnNewsDefault;
        private System.Windows.Forms.Button btnNewsShowByDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNewsShowByDate;
        private System.Windows.Forms.Button btnNewsExit;
        private System.Windows.Forms.Button btnNewsDelete;
        private System.Windows.Forms.Button btnNewsAdd;
        private System.Windows.Forms.Button btnNewsUpdate;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.TreeView TVNews;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.CheckBox chkNewsLinkFlag;
        private System.Windows.Forms.MonthCalendar xCalNews;
        private System.Windows.Forms.TextBox txtNewsSubTitle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtNewsDate;
        private System.Windows.Forms.TextBox txtNewsLinkAddress;
        private System.Windows.Forms.TextBox txtNewsTitle;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtNewsSource;
        private System.Windows.Forms.WebBrowser webBrowserNews;
        private System.Windows.Forms.DataGridView NewsDGV;
        private System.Windows.Forms.TabControl TC;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabSuccessFulStories;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.Button btnSuccessFulStoriesDown;
        private System.Windows.Forms.Button btnSuccessFulStoriesUp;
        private System.Windows.Forms.Button btnSuccessFulStoriesShowImage;
        private System.Windows.Forms.Button btnSuccessFulStoriesAddGrp;
        private System.Windows.Forms.Button btnSuccessFulStoriesExit;
        private System.Windows.Forms.Button btnSuccessFulStoriesUploadImage;
        private System.Windows.Forms.Button btnSuccessFulStoriesDelete;
        private System.Windows.Forms.Button btnSuccessFulStoriesAdd;
        private System.Windows.Forms.Button btnSuccessFulStoriesUpdate;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.TreeView TVSuccessFulStories;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtSuccessFulStoriesCompanyName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSuccessFulStoriesSubTitle;
        private System.Windows.Forms.TextBox txtSuccessFulStoriesDesc;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtSuccessFulStoriesTiltle;
        private System.Windows.Forms.WebBrowser webBrowserCompany;
        private System.Windows.Forms.Button btnSuccessFulStoriesShowLogo;
        private System.Windows.Forms.Button btnSuccessFulStoriesUploadLogo;
    }
}

