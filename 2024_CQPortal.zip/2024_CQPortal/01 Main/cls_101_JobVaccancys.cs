﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CQPortal
{
   public static class JobVaccancys
    {
        public static List<JobVaccancy> mLst = new List<JobVaccancy>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<JobVaccancy> xLst)
        {
            //xID,xDate,xCompanyId, xTitle,xLink,xSeqNo
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xDate + "','" + xLst[n].xTitle + "','" + xLst[n].xDesc +"','" + xLst[n].xCompanyId + "','" + xLst[n].xLink + "'," + xLst[n].xSeqNo + ",'" + xLst[n].xFlag +"','" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)//xSeqNo,xDateTimeStamp
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_JobVaccancy (xID,xDate,xTitle,xDesc,xCompanyId,xLink,xSeqNo,xFlag,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_JobVaccancy");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_JobVaccancy WHERE xID = '" + xID + "' ") == false) return;
                JobVaccancy xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<JobVaccancy> { xT });
            }
            catch { }
        }
        public static void UpLoadList(SqlConnection DBConn, List<JobVaccancy> xLst)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_JobVaccancy") == false) return;
                mLst = xLst;
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static List<JobVaccancy> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<JobVaccancy> xRetLst = new List<JobVaccancy>();
                while (oReader.Read())
                {
                    //xID,xDate,xCompanyId, xTitle,xLink,xSeqNo
                    JobVaccancy xT = new JobVaccancy();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xDate = oReader["xDate"].ToString().Trim();
                    xT.xTitle = oReader["xTitle"].ToString().Trim();
                    xT.xDesc = oReader["xDesc"].ToString().Trim();
                    xT.xCompanyId = oReader["xCompanyId"].ToString().Trim();
                    xT.xLink = oReader["xLink"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xT.xFlag = Convert.ToBoolean(oReader["xFlag"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<JobVaccancy>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<JobVaccancy>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_JobVaccancy";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {

                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;

                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_JobVaccancy WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID.Substring(0, 6));
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID9(string xCompanyID)
        {
            try
            {
                List<JobVaccancy> xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xCompanyID).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return xCompanyID + "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo(string xCompanyID)
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<JobVaccancy> xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xCompanyID).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static JobVaccancy xGetByID(string xID)
        {
            try
            {
                JobVaccancy xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new JobVaccancy();
                return xT;
            }
            catch { return new JobVaccancy(); }
        }
        #endregion

        #region Add Update
        public static void xAdd6(SqlConnection DBConn, TreeView TV,string xDate, TextBox txtTitle, TextBox txtDesc, TextBox txtLink,CheckBox chkFlag)
        {
            try
            {   //xID,xDate,xCompanyId,xTitle,xLink,xSeqNo
                if (TV.SelectedNode == null||TV.SelectedNode.Level==0) return;
                String xCompannyID = "";
                if (TV.SelectedNode.Level == 1) xCompannyID = TV.SelectedNode.Name;
                else if(TV.SelectedNode.Level == 2) xCompannyID=TV.SelectedNode.Parent.Name;
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Title");
                    return;
                }
                JobVaccancy xxT = mLst.Find(p => p.xTitle.ToLower() == txtTitle.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Title Title is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

                JobVaccancy xT = new JobVaccancy();
                xT.xID = xGetNewID9(xCompannyID);
                xT.xDate =xDate;
                xT.xSeqNo = xGetNewSeqNo(xCompannyID);
                xT.xTitle = txtTitle.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xCompanyId = xCompannyID;
                xT.xLink = txtLink.Text.Trim();
                xT.xFlag = chkFlag.Checked;
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xCompanyId].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xUpdate6(SqlConnection DBConn, TreeView TV,string xID, string xDate, TextBox txtTitle, TextBox txtDesc, TextBox txtLink, CheckBox chkFlag)
        {
            try
            {
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Title");
                    return;
                }

                JobVaccancy xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xDate = xDate;
                xT.xTitle = txtTitle.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xCompanyId = xID.Substring(0,6);
                xT.xLink = txtLink.Text.Trim();
                xT.xFlag = chkFlag.Checked;
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID.Substring(0,6)].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xAddDefault(SqlConnection DBConn)
        {
            try
            {
                List<JobVaccancy> xLst = new List<JobVaccancy>();
                xLst.Add(new JobVaccancy("101101101", "20240421", "CalQuan", "CalQuan", "101101", "http://www.calquan.com",1,false));
                xLst.Add(new JobVaccancy("101101102", "20240421", "Yahoo", "Yahoo", "101101",  "https://www.yahoo.com/?guccounter=1",2, false));
                xLst.Add(new JobVaccancy("102101101", "20240423", "LinkedIn", "LinkedIn", "102101",  "https://in.linkedin.com/",1, false));
                xLst.Add(new JobVaccancy("102101102", "20240424", "GMail", "GMail", "102101", "http://www.gmail.com/",2, false));
                UpLoadList(DBConn, xLst);
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();   
                TV.Nodes.Clear();
                List<Company> xLst3 = Companys.xGetList3();
                for (int i = 0; i < xLst3.Count; i++)
                {
                    TreeNode xNode3 = TV.Nodes.Add(xLst3[i].xID, xLst3[i].xName);
                    List<Company> xLst6 = Companys.xGetList6(xLst3[i].xID);
                    for (int j = 0; j < xLst6.Count; j++)
                    {
                        TreeNode xNode6 = xNode3.Nodes.Add(xLst6[j].xID, xLst6[j].xName);
                        List<JobVaccancy> xLst9 = mLst.FindAll(p => p.xID.Substring(0, 6) == xLst6[j].xID).OrderBy(p=>p.xSeqNo).ToList();
                        for (int k = 0; k < xLst9.Count; k++)
                        {
                            TreeNode xNode9 = xNode6.Nodes.Add(xLst9[k].xID, xLst9[k].xTitle);
                        }
                    }
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID, TextBox txtDate, TextBox txtTitle, TextBox txtDesc, TextBox txtLink,CheckBox chkFlag)
        {
            try
            {
                JobVaccancy xT = xGetByID(xID);
                txtDate.Text = Functions.DBToDotDate(xT.xDate);
                txtTitle.Text = xT.xTitle;
                txtDesc.Text = xT.xDesc;
                txtLink.Text = xT.xLink;
                chkFlag.Checked = xT.xFlag;
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown9(SqlConnection DBConn, TreeView TV, bool MoveUp) //xSeqNo
        {
            try
            {
                if (TV.SelectedNode == null) return;
                if (TV.SelectedNode.Level != 2) return;
                string xID = TV.SelectedNode.Name;
                List<JobVaccancy> xLst = new List<JobVaccancy>();
                if (xID.Length != 9) return;
                xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xID.Substring(0,6)).OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID);
            }
            catch { }
        }
        #endregion

        #region writeFile
        public static bool xCompanysWriteTableToFile(SqlConnection DBConn)
        {
            try
            {
                string xFileName = CQBVar.xPath + "\\" + "101_JobVaccancyFromTable_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_JobVaccancy ";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                //xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp.
                StringBuilder SB = new StringBuilder();
                string xLine = "xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp";
                SB.AppendLine(xLine);
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        // xID,xName,xEmail,xDepartment,xExeperience,xQualification,xPlacedCompany,xContactNumber,xDesc,xPSPhotoName,xStartDateExp.
                        xLine = oReader["xID"].ToString().Trim() + "," + oReader["xName"].ToString().Trim() + "," + oReader["xEmail"].ToString().Trim() + "";
                        xLine = xLine + "," + oReader["xDepartment"].ToString().Trim() + "," + oReader["xExeperience"].ToString().Trim() + "," + oReader["xQualification"].ToString().Trim() + "";
                        xLine = xLine + "," + oReader["xPlacedCompany"].ToString().Trim() + "," + oReader["xContactNumber"].ToString().Trim() + "," + oReader["xDesc"].ToString().Trim() + "";
                        xLine = xLine + "," + oReader["xPSPhotoName"].ToString().Trim() + "," + oReader["xStartDateExp"].ToString().Trim() + "";
                        SB.AppendLine(xLine);
                    }
                }
                StreamWriter xWriter = new StreamWriter(xFileName);
                xWriter.Write(SB);
                System.Diagnostics.Process.Start(xFileName);
                xWriter.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion

    }
}
