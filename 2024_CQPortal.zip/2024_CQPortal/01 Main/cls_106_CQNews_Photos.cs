﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using System.Net.Http;


namespace CQPortal
{
    public static class NewsPhotoNames
    {
        public static List<NewsPhotoName> mLst = new List<NewsPhotoName>();
        public static List<string> mLstPhotoNames = new List<string>();
        
        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<NewsPhotoName> xLst)
        {
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xNewsID + "','" + xLst[n].xPhotoFileName + "','" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_NewsPhotoName (xNewsID,xPhotoFileName,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void Uploadsingle(SqlConnection DBConn, NewsPhotoName xT)
        {
            try
            {
                ActualDBUpLoad(DBConn, new List<NewsPhotoName> { xT });
            }
            catch { }
        }
        public static List<NewsPhotoName> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<NewsPhotoName> xRetLst = new List<NewsPhotoName>();
                while (oReader.Read())
                {
                    NewsPhotoName xT = new NewsPhotoName();
                    xT.xNewsID = oReader["xNewsID"].ToString().Trim();
                    xT.xPhotoFileName = oReader["xPhotoFileName"].ToString().Trim();
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<NewsPhotoName>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<NewsPhotoName>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_NewsPhotoName";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        #endregion

        #region Get
        private static string xGetNewID9(string xNewsID6)
        {
            try
            {
                List<NewsPhotoName> xLst = mLst.FindAll(p => p.xNewsID.Length == 9 && p.xNewsID.Substring(0, 6) == xNewsID6).OrderByDescending(p => Convert.ToInt32(p.xNewsID)).ToList(); ;
                if (xLst.Count == 0) return xNewsID6 + "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xNewsID) + 1));
            }
            catch { return ""; }
        }
        #endregion

        #region Add / Clear
        public static void xAddImage(SqlConnection DBConn, TreeView TV, string xPhotoFileName)
        {
            try
            { 
                if (TV.SelectedNode == null)
                {
                    MessageBox.Show("Select News");
                }
                string xNewsID = "";
                xNewsID = TV.SelectedNode.Name;
                if (TV.SelectedNode.Level == 1) xNewsID = TV.SelectedNode.Parent.Name;
                NewsPhotoName xT = new NewsPhotoName();
                xT.xNewsID = xGetNewID9(xNewsID);
                xT.xPhotoFileName = xPhotoFileName;
                Uploadsingle(DBConn, xT);
                mLst.Add(xT);
               CQNewss.xPopTV(TV);
               TV.SelectedNode = TV.Nodes[xNewsID].Nodes[xT.xNewsID];
            }
            catch { }
        }
        public static void xClearGarbageEntries(SqlConnection DBConn)
        {
            try
            {
               
                List<string> xUnUsedNewsID = new List<string>();
                for (int i = 0; i < mLst.Count; i++)
                {
                    if (mLstPhotoNames.Contains(mLst[i].xPhotoFileName) == false)
                    {
                        xUnUsedNewsID.Add(mLst[i].xNewsID);
                    }

                }
                for (int i = 0; i < xUnUsedNewsID.Count; i++)
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM CQ_Portal_NewsPhotoName WHERE xNewsID ='" + xUnUsedNewsID[i] + "'");
                    mLst.RemoveAll(p => p.xNewsID == xUnUsedNewsID[i]);
                }
            }
            catch { }
        }
        async internal static System.Threading.Tasks.Task GetPhotoNames()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    try
                    {
                        mLstPhotoNames.Clear();

                        string xURL = CQBVar.MyURL + "/api/Portal/GetPhotolistFromNewsPhotos/";
                        HttpResponseMessage response = await client.GetAsync(xURL);
                        response.EnsureSuccessStatusCode(); // Ensure success status code, otherwise an exception will be thrown
                        string responseBody = await response.Content.ReadAsStringAsync();
                        mLstPhotoNames = JsonConvert.DeserializeObject<List<string>>(responseBody);

                    }
                    catch (HttpRequestException ex)
                    {
                        Console.WriteLine($"Request error: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { }
        }
        public static void xClearGarbageEntriesByNewsID(SqlConnection DBConn)
        {
            try
            {
                List<string> xLstNewsID = CQNewss.xGetListAll().Select(p=>p.xID).ToList();

                List<string> xLstUnUsedNewsID = new List<string>();
                for (int i = 0; i < mLst.Count; i++)
                {
                    if (xLstNewsID.Contains(mLst[i].xNewsID.Substring(0,6)) == false)
                    {
                        xLstUnUsedNewsID.Add(mLst[i].xNewsID);
                    }
                    
                }
                xLstUnUsedNewsID=xLstUnUsedNewsID.Distinct().ToList();
                for (int i = 0; i < xLstUnUsedNewsID.Count; i++)
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM CQ_Portal_NewsPhotoName WHERE xNewsID ='" + xLstUnUsedNewsID[i] + "'");
                    mLst.RemoveAll(p => p.xNewsID == xLstUnUsedNewsID[i]);
                }
            }
            catch { }
        }

        #endregion

        #region Pop
        public static void xPopTVNode(TreeNode xNode6)
        {
            try
            {
                xNode6.Nodes.Clear();
                List<NewsPhotoName> xLst9 = mLst.FindAll(p => p.xNewsID.Substring(0, 6) == xNode6.Name);
                for (int j = 0; j < xLst9.Count; j++)
                {
                    xNode6.Nodes.Add(xLst9[j].xNewsID, xLst9[j].xPhotoFileName);
                }
            }
            catch { }
        }
        #endregion
    }
}
