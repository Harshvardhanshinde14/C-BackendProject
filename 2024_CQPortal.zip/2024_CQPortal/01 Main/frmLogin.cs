﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using static System.Windows.Forms.AxHost;

namespace CQPortal
{
    public partial class FrmLogIn : Form
    {
        #region Form
        public FrmLogIn()
        {
            InitializeComponent();
        }
        private void FrmLogIn_Load(object sender, EventArgs e)
        {
            try
            {
                xGetSettings();
                CQBVar.ConnString.IPAddress = txtLoginIPAddress.Text.Trim();
                CQBVar.ConnString.UserName = txtLoginUserName.Text.Trim();
                CQBVar.ConnString.Password = txtLoginPW.Text.Trim();
                CQBVar.ConnString.UserRole = "-";
                webLogin.ScriptErrorsSuppressed = true;
                webLogin.Navigate("www.google.com");
                if (TC.TabPages.Contains(tabBackUpRecovery) == true) TC.TabPages.Remove(tabBackUpRecovery);
                this.Text = "CQ_Portal_" + CQBVar.Version;
                PopCmb(cmbLoginWebNavigation);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { }
        }
        private void PopCmb(ComboBox cmb)
        {
            try
            {
                cmb.DisplayMember = "Value";
                cmb.ValueMember = "Key";
                cmb.Items.Clear();
                cmb.Items.Add(new KeyValuePair<string, string>("103.14.99.54:90", "CalQuan"));

                cmb.Items.Add(new KeyValuePair<string, string>("103.14.99.54:91", "Bakul"));
                cmb.Items.Add(new KeyValuePair<string, string>("calquan.in", "CalQuan.in"));
                cmb.SelectedIndex = 0;
            }
            catch { }
        }
        private void xChkFolderDB()
        {
            try
            {
                CQBVar.ConnString.IPAddress = txtLoginIPAddress.Text.Trim();
                CQBVar.ConnString.UserName = txtLoginUserName.Text.Trim();
                CQBVar.ConnString.Password = txtLoginPW.Text.Trim();
                CQBVar.ConnString.UserRole = "-";
                xSaveSettings();
                string xStr = CQBVar.ConnString.ServerMaster;
                SqlConnection dbSerMasterConn = new SqlConnection(xStr);
                dbSerMasterConn.Open();
                CreateDB_Prj(dbSerMasterConn);
                CheckDBSchema();
                if (Directory.Exists(CQBVar.xPath) == false) Directory.CreateDirectory(CQBVar.xPath);
                if (Directory.Exists(CQBVar.xPathBackUp) == false) Directory.CreateDirectory(CQBVar.xPathBackUp);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        public static bool CreateDB_Prj(SqlConnection dbSerMasterConn)
        {
            string xSQL = "";
            try
            {
                string xDBName = CQBVar.mDBName;
                xSQL = " CREATE DATABASE " + xDBName + " ON PRIMARY "
                                   + " (NAME = " + xDBName + ", FILENAME = '" + CQBVar.Path.ServerDrive + xDBName + ".mdf', SIZE = 1000MB,MAXSIZE = UNLIMITED, FILEGROWTH =10%) "
                                   + " LOG ON (NAME = MyDataBase_Log, FILENAME = '" + CQBVar.Path.ServerDrive + xDBName + ".ldf', SIZE = 500MB, MAXSIZE = UNLIMITED, FILEGROWTH =10%) ";
                SqlCommand myCommand = new SqlCommand(xSQL, dbSerMasterConn);
                myCommand.CommandTimeout = 100;
                myCommand.ExecuteNonQuery();
                return true;
            }
            catch { return false; }
        }
        public static bool CheckDBSchema()
        {
            SqlConnection dbCQPrjConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                dbCQPrjConn.Open();
                TBStrs.CheckAndCreateTables_Prj(dbCQPrjConn);
                CQSQL.ExeNonQuery(dbCQPrjConn, $"UPDATE dbo.CQ_Portal_Company SET xFlag = 'false' WHERE  xFlag IS NULL");
                CQSQL.ExeNonQuery(dbCQPrjConn, $"UPDATE dbo.CQ_Portal_JobVaccancy SET xFlag = 'false' WHERE  xFlag IS NULL");
                CQSQL.ExeNonQuery(dbCQPrjConn, $"UPDATE dbo.CQ_Portal_PlacedStudent SET xEmail = '-' WHERE  xEmail IS NULL");
                CQSQL.ExeNonQuery(dbCQPrjConn, $"UPDATE dbo.CQ_Portal_PlacedStudent SET xDepartment = '-' WHERE  xDepartment IS NULL");
                CQSQL.ExeNonQuery(dbCQPrjConn, $"UPDATE dbo.CQ_Portal_PlacedStudent SET xExeperience = '-' WHERE  xExeperience IS NULL");
                dbCQPrjConn.Close();
                return true;
            }
            catch { return false; }
        }
        #endregion

        #region Login
        private void btnLoginExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void btnLoginDBUpdate_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                xChkFolderDB();
                xSaveSettings();
            }
            catch { }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }
        private bool xSaveSettings()
        {
            try
            {
                Application.UserAppDataRegistry.SetValue("IPAdd", txtLoginIPAddress.Text);
                Application.UserAppDataRegistry.SetValue("UserName", txtLoginUserName.Text);
                if (chkLoginSavePW.Checked == true)
                {
                    Application.UserAppDataRegistry.SetValue("ChkPW", "true");
                    Application.UserAppDataRegistry.SetValue("PW", txtLoginPW.Text);
                    return true;
                }
                else
                {
                    Application.UserAppDataRegistry.SetValue("ChkPW", "false");
                    return true;
                }
            }
            catch { return false; }
        }
        private void xGetSettings()
        {
            try
            {
                txtLoginIPAddress.Text = Application.UserAppDataRegistry.GetValue("IPAdd", "").ToString();
                txtLoginUserName.Text = Application.UserAppDataRegistry.GetValue("UserName", "").ToString();
                chkLoginSavePW.Checked = false;
                if (Application.UserAppDataRegistry.GetValue("ChkPW", "").ToString() == "true")
                {
                    txtLoginPW.Text = Application.UserAppDataRegistry.GetValue("PW", "").ToString();
                    chkLoginSavePW.Checked = true;
                }
            }
            catch { }
        }
        private void btnLoginDBLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (Login() == true)
                {
                    btnLoginCompany.Enabled = true;
                    btnLoginContactUs.Enabled = true;
                    btnLoginTenders.Enabled = true;
                    btnLoginJobs.Enabled = true;
                }
            }
            catch { }
        }
        private bool Login()
        {
            try
            {
                if (xSaveSettings() == true)
                {
                    CQBVar.ConnString.IPAddress = txtLoginIPAddress.Text.Trim();
                    CQBVar.ConnString.UserName = txtLoginUserName.Text.Trim();
                    CQBVar.ConnString.Password = txtLoginPW.Text.Trim();
                    CQBVar.ConnString.UserRole = "-";
                    SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
                    DBConn.Open();

                    DBConn.Close();
                    return true;
                }
                return true;
            }
            catch { return false; }
        }
        private void cmbLoginWebNavigation_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbLoginWebNavigation.SelectedIndex == -1) return;
                string xStr = "";
                xStr = ((KeyValuePair<string, string>)cmbLoginWebNavigation.SelectedItem).Key;
                webLogin.ScriptErrorsSuppressed = true;
                webLogin.Navigate(xStr);
            }
            catch { }
        }
        private void btnLoginJobs_Click(object sender, EventArgs e)
        {
            try
            {
                frmJobs frm = new frmJobs();
                frm.ShowDialog();
                frm.Close();
            }
            catch { }
        }
        private void btnLoginNews_Click(object sender, EventArgs e)
        {
            try
            {
                frmNews frm = new frmNews();
                frm.ShowDialog();
                frm.Close();
            }
            catch { }
        }
        private void btnLoginCompanies_Click(object sender, EventArgs e)
        {
            try
            {
                frmCompany frm = new frmCompany();
                frm.ShowDialog();
                frm.Close();
            }
            catch { }
        }
        private void btnLoginContactUs_Click(object sender, EventArgs e)
        {
            try
            {
                frmContactUs frm = new frmContactUs();
                frm.ShowDialog();
                frm.Close();
            }
            catch { }
        }

        #endregion

        #region BackUp
        private void btnBackUpBackUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                string xPath = CQBVar.xPathBackUp;
                xPath = xPath + "\\CQPortal_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bak";
                string sql = @"BACKUP DATABASE CQCRM TO DISK = '" + xPath + "'";
                if (CQSQL.ExeNonQuery(DBConn, sql, true) == true)
                {
                    MessageBox.Show("Backup completed.");
                }
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        
        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        #endregion

    }
}





