﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics.Contracts;

namespace CQPortal
{
   public static class Tenders
    {
        public static List<Tender> mLst = new List<Tender>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<Tender> xLst)
        {
            //xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xDate + "','" + xLst[n].xPrjNameName + "','" + xLst[n].xDepName +"','" + xLst[n].xPrjCoast + "','" + xLst[n].xDesc + "','" + xLst[n].xImage1 + "','" + xLst[n].xImage2 + "'," + xLst[n].xSeqNo + ",'" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)//xSeqNo,xDateTimeStamp
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_Tender (xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2,xSeqNo,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Tender");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Tender WHERE xID = '" + xID + "' ") == false) return;
                Tender xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<Tender> { xT });
            }
            catch { }
        }
        public static void UpLoadList(SqlConnection DBConn, List<Tender> xLst)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Tender") == false) return;
                mLst = xLst;
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static List<Tender> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<Tender> xRetLst = new List<Tender>();
                while (oReader.Read())
                {
                    ////xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2
                    Tender xT = new Tender();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xDate = oReader["xDate"].ToString().Trim();
                    xT.xPrjNameName = oReader["xPrjNameName"].ToString().Trim();
                    xT.xDepName = oReader["xDepName"].ToString().Trim();
                    xT.xPrjCoast = oReader["xPrjCoast"].ToString().Trim();
                    xT.xDesc = oReader["xDesc"].ToString().Trim();
                    xT.xImage1 = oReader["xImage1"].ToString().Trim();
                    xT.xImage2 = oReader["xImage2"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<Tender>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<Tender>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_Tender";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                if (TV.SelectedNode.Level == 0)
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Tender WHERE LEFT(xID,3) = '" + xID + "' ");
                    mLst.RemoveAll(p => p.xID.Substring(0, 3) == xID);
                    xPopTV(TV);
                }
              else  if (TV.SelectedNode.Level == 1)
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Tender WHERE LEFT(xID,6) = '" + xID + "' ");
                    mLst.RemoveAll(p => p.xID.Substring(0,6) == xID);
                    xPopTV(TV);
                    TV.SelectedNode = TV.Nodes[xID.Substring(0, 3)];
                }
              else  if (TV.SelectedNode.Level == 2)
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Tender WHERE xID ='" + xID + "' ");
                    mLst.RemoveAll(p => p.xID == xID);
                    xPopTV(TV);
                    TV.SelectedNode=TV.Nodes[xID.Substring(0, 3)].Nodes[xID.Substring(0,6)];
                }
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID()
        {
            try
            {
                List<Tender> xLst = mLst.FindAll(p => p.xID.Length == 3).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<Tender> xLst = mLst.OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        private static string xGetNewID6(string xID3)
        {
            try
            {
                List<Tender> xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID3).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return xID3 + "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo6(string xID3)
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<Tender> xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID3).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        private static string xGetNewID9(string xID6)
        {
            try
            {
                List<Tender> xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xID6).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return xID6 + "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo9(string xID6)
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<Tender> xLst = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xID6).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static List<Tender> xGetList()
        {
            try
            {
                return mLst.ToList();
            }
            catch { return new List<Tender>(); }
        }
        public static Tender xGetByID(string xID)
        {
            try
            {
                Tender xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new Tender();
                return xT;
            }
            catch { return new Tender(); }
        }
       
        #endregion

        #region Add Update
        public static void xAdd3(SqlConnection DBConn, TreeView TV, string xDate, TextBox txtPrjNAme, TextBox txtDepName, TextBox txtPrjCoast, TextBox txtDesc)
        {
            try
            {
                ////xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2
                if (txtPrjNAme.Text.Trim() == "" || txtPrjNAme.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Project Name");
                    return;
                }
                Tender xxT = mLst.Find(p => p.xPrjNameName.ToLower() == txtPrjNAme.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("ProjectName is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

                Tender xT = new Tender();
                xT.xID = xGetNewID();
                xT.xDate = xDate;
                xT.xSeqNo = xGetNewSeqNo();
                xT.xPrjNameName = txtPrjNAme.Text.Trim();
                xT.xDepName = txtDepName.Text.Trim();
                xT.xPrjCoast = txtPrjCoast.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xImage1 = xT.xID + "_Image1";
                xT.xImage2 = xT.xID + "_Image2";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static void xAdd6(SqlConnection DBConn, TreeView TV, string xDate, TextBox txtPrjNAme, TextBox txtDepName, TextBox txtPrjCoast, TextBox txtDesc)
        {
            try
            {
                ////xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2
                if (TV.SelectedNode == null) ;
                if (txtPrjNAme.Text.Trim() == "" || txtPrjNAme.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Project Name");
                    return;
                }
                Tender xxT = mLst.Find(p => p.xPrjNameName.ToLower() == txtPrjNAme.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show(" ProjectName is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                string xID3 = TV.SelectedNode.Name;
                if (TV.SelectedNode.Level == 1) xID3 = TV.SelectedNode.Parent.Name;
                Tender xT = new Tender();
                xT.xID = xGetNewID6(xID3);
                xT.xDate = xDate;
                xT.xSeqNo = xGetNewSeqNo6(xID3);
                xT.xPrjNameName = txtPrjNAme.Text.Trim();
                xT.xDepName = txtDepName.Text.Trim();
                xT.xPrjCoast = txtPrjCoast.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xImage1 = xT.xID + "_Image1";
                xT.xImage2 = xT.xID + "_Image2";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID];
            }
            catch { }
        }
        public static bool xValidate(SqlConnection DBConn, TreeView TV, string xDate, TextBox txtPrjNAme, TextBox txtDepName, TextBox txtPrjCoast, TextBox txtDesc, out string ErrorMessage)
        {
            ErrorMessage = string.Empty;
            bool isValid = true;

            // Check for empty fields
            if (string.IsNullOrWhiteSpace(txtPrjNAme.Text))
            {
                ErrorMessage += "projectName is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtDepName.Text))
            {
                ErrorMessage += "Department name  is required.\n";
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtDesc.Text))
            {
                ErrorMessage += "Description is required.\n";
                isValid = false;
            }
            return isValid;
        }
        public static void xAdd9(SqlConnection DBConn, TreeView TV, string xDate, TextBox txtPrjNAme, TextBox txtDepName, TextBox txtPrjCoast, TextBox txtDesc)
        {
            try
            {
                ////xID,xDate,xPrjNameName,xDepName,xPrjCoast,xDesc,xImage1,xImage2
                if (TV.SelectedNode == null) ;
                    if (txtPrjNAme.Text.Trim() == "" || txtPrjNAme.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Project Name");
                    return;
                }
                Tender xxT = mLst.Find(p => p.xPrjNameName.ToLower() == txtPrjNAme.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("ProjectName is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                string xID6 = xID6 = TV.SelectedNode.Name;
                if (TV.SelectedNode.Level==2)xID6=TV.SelectedNode.Parent.Name;
                if (TV.SelectedNode.Level == 2) xID6 = TV.SelectedNode.Parent.Name;
                Tender xT = new Tender();
                xT.xID = xGetNewID9(xID6);
                xT.xDate = xDate;
                xT.xSeqNo = xGetNewSeqNo9(xID6);
                xT.xPrjNameName = txtPrjNAme.Text.Trim();
                xT.xDepName = txtDepName.Text.Trim();
                xT.xPrjCoast = txtPrjCoast.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xImage1 = xT.xID + "_Image1";
                xT.xImage2 = xT.xID + "_Image2";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0,3)].Nodes[xT.xID.Substring(0,6)].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xUpdate(SqlConnection DBConn,string xID, TreeView TV, string xDate, TextBox txtPrjNAme, TextBox txtDepName, TextBox txtPrjCoast, TextBox txtDesc)
        {
            try
            {
                if (txtPrjNAme.Text.Trim() == "" || txtPrjNAme.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Project Name");
                    return;
                }
                Tender xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xDate = xDate;
                xT.xPrjNameName = txtPrjNAme.Text.Trim();
                xT.xDepName = txtDepName.Text.Trim();
                xT.xPrjCoast = txtPrjCoast.Text.Trim();
                xT.xDesc = txtDesc.Text.Trim();
                xT.xImage1 = xT.xID + "_Image1";
                xT.xImage2 = xT.xID + "_Image2";
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xT.xID);
            }
            catch { }
        }
        public static void xAddDefault(SqlConnection DBConn)
        {
            try
            {
                List<Tender> xLst = new List<Tender>();
                xLst.Add(new Tender("101","20240424", "Jalna – Nanded Expressway", "MSRDC", "14,500 crore", "JNE-1", "JalanaImage1", "JalanaImage2",1));
                xLst.Add(new Tender("102", "20240423", "Belgaum – Hungund – Raichur Expressway", "NHAI", "976.52 crore", "Belgaum – Hungund – Raichur Expressway", "BelgamImage1", "BelgamImage1",2));
                xLst.Add(new Tender("103", "20240424", "Mumbai Multi Modal Corridor’s 11 Construction", "MSRDC", "10,000 crore", "Mumbai Multi Modal Corridor’s 11 Construction", "MumbaiImage1", "MumbaiImage2",3));
                UpLoadList(DBConn, xLst);
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<Tender> xLst3 = mLst.FindAll(p => p.xID.Length == 3).OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst3.Count; i++)
                {
                    TreeNode xNode3 = TV.Nodes.Add(xLst3[i].xID, xLst3[i].xPrjNameName);
                    List<Tender> xLst6 = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xLst3[i].xID).OrderBy(p => p.xSeqNo).ToList();
                    for (int j = 0; j < xLst6.Count; j++)
                    {
                        TreeNode xNode6 = xNode3.Nodes.Add(xLst6[j].xID, xLst6[j].xPrjNameName);

                        List<Tender> xLst9 = mLst.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xLst6[j].xID).OrderBy(p => p.xSeqNo).ToList();
                        for (int k = 0; k < xLst9.Count; k++)
                        {
                            xNode6.Nodes.Add(xLst9[k].xID, xLst9[k].xPrjNameName);
                        }
                    }
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID,  TextBox txtDate, TextBox txtPrjName, TextBox txtDepName, TextBox txtPrjCoast, TextBox txtDesc)
        {
            try
            {
                Tender xT = xGetByID(xID);
                txtDate.Text = Functions.DBToDotDate(xT.xDate);
                txtPrjName.Text = xT.xPrjNameName;
                txtDepName.Text = xT.xDepName;
                txtPrjCoast.Text = xT.xPrjCoast;
                txtDesc.Text = xT.xDesc;
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown(SqlConnection DBConn, TreeView TV, bool MoveUp) //xSeqNo
        {
            try
            {
                if (TV.SelectedNode == null) return;
                string xID = TV.SelectedNode.Name;
                List<Tender> xLst = new List<Tender>();
                if (xID.Length != 3) return;
                xLst = mLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID);
            }
            catch { }
        }
        #endregion

    }
}
