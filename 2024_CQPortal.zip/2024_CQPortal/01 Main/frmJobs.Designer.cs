﻿namespace CQPortal
{
    partial class frmJobs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmJobs));
            this.mOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.tabPlacedStudent = new System.Windows.Forms.TabPage();
            this.splitContainer40 = new System.Windows.Forms.SplitContainer();
            this.btnPlacedStudentWrite = new System.Windows.Forms.Button();
            this.btnPlacedStudentMoveDown = new System.Windows.Forms.Button();
            this.btnPlacedStudentMoveUp = new System.Windows.Forms.Button();
            this.btnPlacedStudentShowImage = new System.Windows.Forms.Button();
            this.btnPlacedStudentExit = new System.Windows.Forms.Button();
            this.btnPlacedStudentUploadImage = new System.Windows.Forms.Button();
            this.btnPlacedStudentDelete = new System.Windows.Forms.Button();
            this.btnPlacedStudentAdd = new System.Windows.Forms.Button();
            this.btnPlacedStudentUpdate = new System.Windows.Forms.Button();
            this.splitContainer41 = new System.Windows.Forms.SplitContainer();
            this.TVPlacedStudent = new System.Windows.Forms.TreeView();
            this.label4 = new System.Windows.Forms.Label();
            this.splitContainer42 = new System.Windows.Forms.SplitContainer();
            this.label73 = new System.Windows.Forms.Label();
            this.txtPlacedStudentExperience = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.txtPlacedStudentDepartment = new System.Windows.Forms.TextBox();
            this.txtPlacedStudentEmail = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtPlacedStudentPlacedCompany = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.txtPlacedStudentQualification = new System.Windows.Forms.TextBox();
            this.txtPlacedStudentContactNumber = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.txtPlacedStudentDescription = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.txtPlacedStudentName = new System.Windows.Forms.TextBox();
            this.tabTrainingProgram = new System.Windows.Forms.TabPage();
            this.splitContainer38 = new System.Windows.Forms.SplitContainer();
            this.btnTrainingProgramMoveUp = new System.Windows.Forms.Button();
            this.btnTrainingProgramMoveDown = new System.Windows.Forms.Button();
            this.btnTrainingProgramExit = new System.Windows.Forms.Button();
            this.btnTrainingProgramDelete = new System.Windows.Forms.Button();
            this.btnTrainingProgramAdd = new System.Windows.Forms.Button();
            this.btnTrainingProgramUpdate = new System.Windows.Forms.Button();
            this.splitContainer39 = new System.Windows.Forms.SplitContainer();
            this.TVTrainingProgram = new System.Windows.Forms.TreeView();
            this.label3 = new System.Windows.Forms.Label();
            this.CalTrainingProgram = new System.Windows.Forms.MonthCalendar();
            this.label65 = new System.Windows.Forms.Label();
            this.txtTrainingProgramShortDesc = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.txtTrainingProgramCity = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtTrainingProgramContactNo = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtTrainingProgramTiming = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.txtTrainingProgramLocation = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtTrainingProgramDuration = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtTrainingProgramDescription = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.txtTrainingProgramStartDate = new System.Windows.Forms.TextBox();
            this.txtTrainingProgramTitle = new System.Windows.Forms.TextBox();
            this.tabPlacement = new System.Windows.Forms.TabPage();
            this.splitContainer30 = new System.Windows.Forms.SplitContainer();
            this.btnPlacementShowPdf = new System.Windows.Forms.Button();
            this.btnPlacementShowImage = new System.Windows.Forms.Button();
            this.btnPlacementRefresh = new System.Windows.Forms.Button();
            this.btnPlacementExit = new System.Windows.Forms.Button();
            this.splitContainer31 = new System.Windows.Forms.SplitContainer();
            this.TVPlacement = new System.Windows.Forms.TreeView();
            this.label38 = new System.Windows.Forms.Label();
            this.splitContainer32 = new System.Windows.Forms.SplitContainer();
            this.label44 = new System.Windows.Forms.Label();
            this.rbtPlacementPdf = new System.Windows.Forms.RadioButton();
            this.txtPlacementEmail = new System.Windows.Forms.TextBox();
            this.txtPlacementFileName = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.rbtPlacementImage = new System.Windows.Forms.RadioButton();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.txtPlacementExperience = new System.Windows.Forms.TextBox();
            this.txtPlacementEducation = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtPlacementName = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtPlacementPhoneNo = new System.Windows.Forms.TextBox();
            this.txtPlacementAge = new System.Windows.Forms.TextBox();
            this.txtPlacementMessage = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.tabJobVaccancys = new System.Windows.Forms.TabPage();
            this.splitContainer15 = new System.Windows.Forms.SplitContainer();
            this.btnJobVacDown = new System.Windows.Forms.Button();
            this.btnJobVacUp = new System.Windows.Forms.Button();
            this.btnJobVacShowImage = new System.Windows.Forms.Button();
            this.btnJobVacDefault = new System.Windows.Forms.Button();
            this.btnJobVacULImage = new System.Windows.Forms.Button();
            this.btnJobVacExit = new System.Windows.Forms.Button();
            this.btnJobVacDelete = new System.Windows.Forms.Button();
            this.btnJobVacAdd = new System.Windows.Forms.Button();
            this.btnJobVacUpdate = new System.Windows.Forms.Button();
            this.splitContainer19 = new System.Windows.Forms.SplitContainer();
            this.TVJobVaccancys = new System.Windows.Forms.TreeView();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer20 = new System.Windows.Forms.SplitContainer();
            this.chkJobVacFlag = new System.Windows.Forms.CheckBox();
            this.xCalJobVaccancys = new System.Windows.Forms.MonthCalendar();
            this.label18 = new System.Windows.Forms.Label();
            this.txtJobVacTitle = new System.Windows.Forms.TextBox();
            this.txtJobVacDesc = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtJobVacLinkAdd = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtJobVacDate = new System.Windows.Forms.TextBox();
            this.TC = new System.Windows.Forms.TabControl();
            this.tabCQNews = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnCQNewsClearGarbage = new System.Windows.Forms.Button();
            this.btnCQNewsWrite = new System.Windows.Forms.Button();
            this.btnCQNewsMoveDown = new System.Windows.Forms.Button();
            this.btnCQNewsMoveUp = new System.Windows.Forms.Button();
            this.btnCQNewsShowImage = new System.Windows.Forms.Button();
            this.btnCQNewsExit = new System.Windows.Forms.Button();
            this.btnCQNewsUploadImage = new System.Windows.Forms.Button();
            this.btnCQNewsDelete = new System.Windows.Forms.Button();
            this.btnCQNewsAdd = new System.Windows.Forms.Button();
            this.btnCQNewsUpdate = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.TVCQNews = new System.Windows.Forms.TreeView();
            this.label5 = new System.Windows.Forms.Label();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.CalCQNews = new System.Windows.Forms.MonthCalendar();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCQNewsDate = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCQNewsDescription = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCQNewsTitle = new System.Windows.Forms.TextBox();
            this.tabPlacedStudent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer40)).BeginInit();
            this.splitContainer40.Panel1.SuspendLayout();
            this.splitContainer40.Panel2.SuspendLayout();
            this.splitContainer40.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer41)).BeginInit();
            this.splitContainer41.Panel1.SuspendLayout();
            this.splitContainer41.Panel2.SuspendLayout();
            this.splitContainer41.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer42)).BeginInit();
            this.splitContainer42.Panel1.SuspendLayout();
            this.splitContainer42.SuspendLayout();
            this.tabTrainingProgram.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer38)).BeginInit();
            this.splitContainer38.Panel1.SuspendLayout();
            this.splitContainer38.Panel2.SuspendLayout();
            this.splitContainer38.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer39)).BeginInit();
            this.splitContainer39.Panel1.SuspendLayout();
            this.splitContainer39.Panel2.SuspendLayout();
            this.splitContainer39.SuspendLayout();
            this.tabPlacement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer30)).BeginInit();
            this.splitContainer30.Panel1.SuspendLayout();
            this.splitContainer30.Panel2.SuspendLayout();
            this.splitContainer30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer31)).BeginInit();
            this.splitContainer31.Panel1.SuspendLayout();
            this.splitContainer31.Panel2.SuspendLayout();
            this.splitContainer31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer32)).BeginInit();
            this.splitContainer32.Panel1.SuspendLayout();
            this.splitContainer32.Panel2.SuspendLayout();
            this.splitContainer32.SuspendLayout();
            this.tabJobVaccancys.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).BeginInit();
            this.splitContainer15.Panel1.SuspendLayout();
            this.splitContainer15.Panel2.SuspendLayout();
            this.splitContainer15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer19)).BeginInit();
            this.splitContainer19.Panel1.SuspendLayout();
            this.splitContainer19.Panel2.SuspendLayout();
            this.splitContainer19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer20)).BeginInit();
            this.splitContainer20.Panel1.SuspendLayout();
            this.splitContainer20.SuspendLayout();
            this.TC.SuspendLayout();
            this.tabCQNews.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.SuspendLayout();
            // 
            // mOpenFile
            // 
            this.mOpenFile.FileName = "mOpenFile";
            // 
            // tabPlacedStudent
            // 
            this.tabPlacedStudent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPlacedStudent.Controls.Add(this.splitContainer40);
            this.tabPlacedStudent.Location = new System.Drawing.Point(4, 22);
            this.tabPlacedStudent.Name = "tabPlacedStudent";
            this.tabPlacedStudent.Padding = new System.Windows.Forms.Padding(3);
            this.tabPlacedStudent.Size = new System.Drawing.Size(1099, 550);
            this.tabPlacedStudent.TabIndex = 16;
            this.tabPlacedStudent.Text = "PlacedStudent";
            this.tabPlacedStudent.UseVisualStyleBackColor = true;
            // 
            // splitContainer40
            // 
            this.splitContainer40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer40.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer40.IsSplitterFixed = true;
            this.splitContainer40.Location = new System.Drawing.Point(3, 3);
            this.splitContainer40.Name = "splitContainer40";
            this.splitContainer40.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer40.Panel1
            // 
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentWrite);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentMoveDown);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentMoveUp);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentShowImage);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentExit);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentUploadImage);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentDelete);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentAdd);
            this.splitContainer40.Panel1.Controls.Add(this.btnPlacedStudentUpdate);
            // 
            // splitContainer40.Panel2
            // 
            this.splitContainer40.Panel2.Controls.Add(this.splitContainer41);
            this.splitContainer40.Size = new System.Drawing.Size(1091, 542);
            this.splitContainer40.SplitterDistance = 60;
            this.splitContainer40.TabIndex = 2;
            // 
            // btnPlacedStudentWrite
            // 
            this.btnPlacedStudentWrite.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentWrite.Location = new System.Drawing.Point(662, 20);
            this.btnPlacedStudentWrite.Name = "btnPlacedStudentWrite";
            this.btnPlacedStudentWrite.Size = new System.Drawing.Size(100, 25);
            this.btnPlacedStudentWrite.TabIndex = 41;
            this.btnPlacedStudentWrite.Text = "Write";
            this.btnPlacedStudentWrite.UseVisualStyleBackColor = true;
            this.btnPlacedStudentWrite.Click += new System.EventHandler(this.btnPlacedStudentWrite_Click);
            // 
            // btnPlacedStudentMoveDown
            // 
            this.btnPlacedStudentMoveDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentMoveDown.Location = new System.Drawing.Point(606, 20);
            this.btnPlacedStudentMoveDown.Name = "btnPlacedStudentMoveDown";
            this.btnPlacedStudentMoveDown.Size = new System.Drawing.Size(50, 25);
            this.btnPlacedStudentMoveDown.TabIndex = 40;
            this.btnPlacedStudentMoveDown.Text = "\\/";
            this.btnPlacedStudentMoveDown.UseVisualStyleBackColor = true;
            this.btnPlacedStudentMoveDown.Click += new System.EventHandler(this.btnPlacedStudentMoveDown_Click);
            // 
            // btnPlacedStudentMoveUp
            // 
            this.btnPlacedStudentMoveUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentMoveUp.Location = new System.Drawing.Point(550, 20);
            this.btnPlacedStudentMoveUp.Name = "btnPlacedStudentMoveUp";
            this.btnPlacedStudentMoveUp.Size = new System.Drawing.Size(50, 25);
            this.btnPlacedStudentMoveUp.TabIndex = 39;
            this.btnPlacedStudentMoveUp.Text = "/\\";
            this.btnPlacedStudentMoveUp.UseVisualStyleBackColor = true;
            this.btnPlacedStudentMoveUp.Click += new System.EventHandler(this.btnPlacedStudentMoveUp_Click);
            // 
            // btnPlacedStudentShowImage
            // 
            this.btnPlacedStudentShowImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentShowImage.Location = new System.Drawing.Point(444, 20);
            this.btnPlacedStudentShowImage.Name = "btnPlacedStudentShowImage";
            this.btnPlacedStudentShowImage.Size = new System.Drawing.Size(100, 25);
            this.btnPlacedStudentShowImage.TabIndex = 37;
            this.btnPlacedStudentShowImage.Text = "Show Image";
            this.btnPlacedStudentShowImage.UseVisualStyleBackColor = true;
            this.btnPlacedStudentShowImage.Click += new System.EventHandler(this.btnPlacedStudentShowImage_Click);
            // 
            // btnPlacedStudentExit
            // 
            this.btnPlacedStudentExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentExit.Location = new System.Drawing.Point(946, 20);
            this.btnPlacedStudentExit.Name = "btnPlacedStudentExit";
            this.btnPlacedStudentExit.Size = new System.Drawing.Size(100, 25);
            this.btnPlacedStudentExit.TabIndex = 35;
            this.btnPlacedStudentExit.Text = "    ";
            this.btnPlacedStudentExit.UseVisualStyleBackColor = true;
            this.btnPlacedStudentExit.Click += new System.EventHandler(this.btnPlacedStudentExit_Click);
            // 
            // btnPlacedStudentUploadImage
            // 
            this.btnPlacedStudentUploadImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentUploadImage.Location = new System.Drawing.Point(338, 20);
            this.btnPlacedStudentUploadImage.Name = "btnPlacedStudentUploadImage";
            this.btnPlacedStudentUploadImage.Size = new System.Drawing.Size(100, 25);
            this.btnPlacedStudentUploadImage.TabIndex = 31;
            this.btnPlacedStudentUploadImage.Text = "Upload Image";
            this.btnPlacedStudentUploadImage.UseVisualStyleBackColor = true;
            this.btnPlacedStudentUploadImage.Click += new System.EventHandler(this.btnPlacedStudentUploadImage_Click);
            // 
            // btnPlacedStudentDelete
            // 
            this.btnPlacedStudentDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentDelete.Location = new System.Drawing.Point(232, 20);
            this.btnPlacedStudentDelete.Name = "btnPlacedStudentDelete";
            this.btnPlacedStudentDelete.Size = new System.Drawing.Size(100, 25);
            this.btnPlacedStudentDelete.TabIndex = 28;
            this.btnPlacedStudentDelete.Text = "Delete";
            this.btnPlacedStudentDelete.UseVisualStyleBackColor = true;
            this.btnPlacedStudentDelete.Click += new System.EventHandler(this.btnPlacedStudentDelete_Click);
            // 
            // btnPlacedStudentAdd
            // 
            this.btnPlacedStudentAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentAdd.Location = new System.Drawing.Point(20, 20);
            this.btnPlacedStudentAdd.Name = "btnPlacedStudentAdd";
            this.btnPlacedStudentAdd.Size = new System.Drawing.Size(100, 25);
            this.btnPlacedStudentAdd.TabIndex = 29;
            this.btnPlacedStudentAdd.Text = "Add";
            this.btnPlacedStudentAdd.UseVisualStyleBackColor = true;
            this.btnPlacedStudentAdd.Click += new System.EventHandler(this.btnPlacedStudentAdd_Click);
            // 
            // btnPlacedStudentUpdate
            // 
            this.btnPlacedStudentUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacedStudentUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnPlacedStudentUpdate.Name = "btnPlacedStudentUpdate";
            this.btnPlacedStudentUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnPlacedStudentUpdate.TabIndex = 27;
            this.btnPlacedStudentUpdate.Text = "Update";
            this.btnPlacedStudentUpdate.UseVisualStyleBackColor = true;
            this.btnPlacedStudentUpdate.Click += new System.EventHandler(this.btnPlacedStudentUpdate_Click);
            // 
            // splitContainer41
            // 
            this.splitContainer41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer41.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer41.IsSplitterFixed = true;
            this.splitContainer41.Location = new System.Drawing.Point(0, 0);
            this.splitContainer41.Name = "splitContainer41";
            // 
            // splitContainer41.Panel1
            // 
            this.splitContainer41.Panel1.Controls.Add(this.TVPlacedStudent);
            this.splitContainer41.Panel1.Controls.Add(this.label4);
            // 
            // splitContainer41.Panel2
            // 
            this.splitContainer41.Panel2.Controls.Add(this.splitContainer42);
            this.splitContainer41.Size = new System.Drawing.Size(1091, 478);
            this.splitContainer41.SplitterDistance = 300;
            this.splitContainer41.TabIndex = 0;
            // 
            // TVPlacedStudent
            // 
            this.TVPlacedStudent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVPlacedStudent.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVPlacedStudent.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVPlacedStudent.FullRowSelect = true;
            this.TVPlacedStudent.HideSelection = false;
            this.TVPlacedStudent.Location = new System.Drawing.Point(0, 25);
            this.TVPlacedStudent.Name = "TVPlacedStudent";
            this.TVPlacedStudent.Size = new System.Drawing.Size(298, 451);
            this.TVPlacedStudent.TabIndex = 28;
            this.TVPlacedStudent.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVPlacedStudent.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVPlacedStudent_MouseDoubleClick);
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(298, 25);
            this.label4.TabIndex = 42;
            this.label4.Text = "Placed Students";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer42
            // 
            this.splitContainer42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer42.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer42.IsSplitterFixed = true;
            this.splitContainer42.Location = new System.Drawing.Point(0, 0);
            this.splitContainer42.Name = "splitContainer42";
            this.splitContainer42.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer42.Panel1
            // 
            this.splitContainer42.Panel1.Controls.Add(this.label73);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentExperience);
            this.splitContainer42.Panel1.Controls.Add(this.label74);
            this.splitContainer42.Panel1.Controls.Add(this.label68);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentDepartment);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentEmail);
            this.splitContainer42.Panel1.Controls.Add(this.label67);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentPlacedCompany);
            this.splitContainer42.Panel1.Controls.Add(this.label69);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentQualification);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentContactNumber);
            this.splitContainer42.Panel1.Controls.Add(this.label70);
            this.splitContainer42.Panel1.Controls.Add(this.label71);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentDescription);
            this.splitContainer42.Panel1.Controls.Add(this.label72);
            this.splitContainer42.Panel1.Controls.Add(this.txtPlacedStudentName);
            this.splitContainer42.Size = new System.Drawing.Size(787, 478);
            this.splitContainer42.SplitterDistance = 300;
            this.splitContainer42.TabIndex = 34;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(569, 61);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(72, 16);
            this.label73.TabIndex = 233;
            this.label73.Text = "Experience";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacedStudentExperience
            // 
            this.txtPlacedStudentExperience.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentExperience.Location = new System.Drawing.Point(565, 80);
            this.txtPlacedStudentExperience.Name = "txtPlacedStudentExperience";
            this.txtPlacedStudentExperience.Size = new System.Drawing.Size(187, 22);
            this.txtPlacedStudentExperience.TabIndex = 234;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(569, 118);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(74, 16);
            this.label74.TabIndex = 229;
            this.label74.Text = "Department";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(299, 61);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(40, 16);
            this.label68.TabIndex = 227;
            this.label68.Text = "Email";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacedStudentDepartment
            // 
            this.txtPlacedStudentDepartment.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentDepartment.Location = new System.Drawing.Point(565, 136);
            this.txtPlacedStudentDepartment.Name = "txtPlacedStudentDepartment";
            this.txtPlacedStudentDepartment.Size = new System.Drawing.Size(187, 22);
            this.txtPlacedStudentDepartment.TabIndex = 226;
            // 
            // txtPlacedStudentEmail
            // 
            this.txtPlacedStudentEmail.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentEmail.Location = new System.Drawing.Point(295, 80);
            this.txtPlacedStudentEmail.Name = "txtPlacedStudentEmail";
            this.txtPlacedStudentEmail.Size = new System.Drawing.Size(264, 22);
            this.txtPlacedStudentEmail.TabIndex = 224;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(299, 118);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(106, 16);
            this.label67.TabIndex = 222;
            this.label67.Text = "Placed Company";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacedStudentPlacedCompany
            // 
            this.txtPlacedStudentPlacedCompany.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentPlacedCompany.Location = new System.Drawing.Point(295, 136);
            this.txtPlacedStudentPlacedCompany.Name = "txtPlacedStudentPlacedCompany";
            this.txtPlacedStudentPlacedCompany.Size = new System.Drawing.Size(264, 22);
            this.txtPlacedStudentPlacedCompany.TabIndex = 223;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(28, 62);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(78, 16);
            this.label69.TabIndex = 38;
            this.label69.Text = "Qualification";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacedStudentQualification
            // 
            this.txtPlacedStudentQualification.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentQualification.Location = new System.Drawing.Point(25, 80);
            this.txtPlacedStudentQualification.Name = "txtPlacedStudentQualification";
            this.txtPlacedStudentQualification.Size = new System.Drawing.Size(264, 22);
            this.txtPlacedStudentQualification.TabIndex = 39;
            // 
            // txtPlacedStudentContactNumber
            // 
            this.txtPlacedStudentContactNumber.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentContactNumber.Location = new System.Drawing.Point(25, 136);
            this.txtPlacedStudentContactNumber.Name = "txtPlacedStudentContactNumber";
            this.txtPlacedStudentContactNumber.Size = new System.Drawing.Size(264, 22);
            this.txtPlacedStudentContactNumber.TabIndex = 35;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(29, 168);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(72, 16);
            this.label70.TabIndex = 36;
            this.label70.Text = "Description";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(28, 117);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(101, 16);
            this.label71.TabIndex = 34;
            this.label71.Text = "Contact Number";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacedStudentDescription
            // 
            this.txtPlacedStudentDescription.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentDescription.Location = new System.Drawing.Point(25, 187);
            this.txtPlacedStudentDescription.Multiline = true;
            this.txtPlacedStudentDescription.Name = "txtPlacedStudentDescription";
            this.txtPlacedStudentDescription.Size = new System.Drawing.Size(727, 53);
            this.txtPlacedStudentDescription.TabIndex = 37;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(28, 14);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(90, 16);
            this.label72.TabIndex = 28;
            this.label72.Text = "Student Name";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacedStudentName
            // 
            this.txtPlacedStudentName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacedStudentName.Location = new System.Drawing.Point(25, 33);
            this.txtPlacedStudentName.Name = "txtPlacedStudentName";
            this.txtPlacedStudentName.Size = new System.Drawing.Size(727, 22);
            this.txtPlacedStudentName.TabIndex = 29;
            // 
            // tabTrainingProgram
            // 
            this.tabTrainingProgram.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabTrainingProgram.Controls.Add(this.splitContainer38);
            this.tabTrainingProgram.Location = new System.Drawing.Point(4, 22);
            this.tabTrainingProgram.Name = "tabTrainingProgram";
            this.tabTrainingProgram.Padding = new System.Windows.Forms.Padding(3);
            this.tabTrainingProgram.Size = new System.Drawing.Size(1099, 550);
            this.tabTrainingProgram.TabIndex = 15;
            this.tabTrainingProgram.Text = "Training Program";
            this.tabTrainingProgram.UseVisualStyleBackColor = true;
            // 
            // splitContainer38
            // 
            this.splitContainer38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer38.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer38.IsSplitterFixed = true;
            this.splitContainer38.Location = new System.Drawing.Point(3, 3);
            this.splitContainer38.Name = "splitContainer38";
            this.splitContainer38.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer38.Panel1
            // 
            this.splitContainer38.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer38.Panel1.Controls.Add(this.btnTrainingProgramMoveUp);
            this.splitContainer38.Panel1.Controls.Add(this.btnTrainingProgramMoveDown);
            this.splitContainer38.Panel1.Controls.Add(this.btnTrainingProgramExit);
            this.splitContainer38.Panel1.Controls.Add(this.btnTrainingProgramDelete);
            this.splitContainer38.Panel1.Controls.Add(this.btnTrainingProgramAdd);
            this.splitContainer38.Panel1.Controls.Add(this.btnTrainingProgramUpdate);
            this.splitContainer38.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitContainer38.Panel2
            // 
            this.splitContainer38.Panel2.Controls.Add(this.splitContainer39);
            this.splitContainer38.Size = new System.Drawing.Size(1091, 542);
            this.splitContainer38.SplitterDistance = 60;
            this.splitContainer38.TabIndex = 5;
            // 
            // btnTrainingProgramMoveUp
            // 
            this.btnTrainingProgramMoveUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainingProgramMoveUp.Location = new System.Drawing.Point(338, 20);
            this.btnTrainingProgramMoveUp.Name = "btnTrainingProgramMoveUp";
            this.btnTrainingProgramMoveUp.Size = new System.Drawing.Size(50, 25);
            this.btnTrainingProgramMoveUp.TabIndex = 40;
            this.btnTrainingProgramMoveUp.Text = "/\\";
            this.btnTrainingProgramMoveUp.UseVisualStyleBackColor = true;
            this.btnTrainingProgramMoveUp.Click += new System.EventHandler(this.btnTrainingProgramMoveUp_Click);
            // 
            // btnTrainingProgramMoveDown
            // 
            this.btnTrainingProgramMoveDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainingProgramMoveDown.Location = new System.Drawing.Point(394, 20);
            this.btnTrainingProgramMoveDown.Name = "btnTrainingProgramMoveDown";
            this.btnTrainingProgramMoveDown.Size = new System.Drawing.Size(50, 25);
            this.btnTrainingProgramMoveDown.TabIndex = 41;
            this.btnTrainingProgramMoveDown.Text = "\\/";
            this.btnTrainingProgramMoveDown.UseVisualStyleBackColor = true;
            this.btnTrainingProgramMoveDown.Click += new System.EventHandler(this.btnTrainingProgramMoveDown_Click);
            // 
            // btnTrainingProgramExit
            // 
            this.btnTrainingProgramExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainingProgramExit.Location = new System.Drawing.Point(946, 20);
            this.btnTrainingProgramExit.Name = "btnTrainingProgramExit";
            this.btnTrainingProgramExit.Size = new System.Drawing.Size(100, 25);
            this.btnTrainingProgramExit.TabIndex = 30;
            this.btnTrainingProgramExit.Text = "Exit";
            this.btnTrainingProgramExit.UseVisualStyleBackColor = true;
            this.btnTrainingProgramExit.Click += new System.EventHandler(this.btnTrainingProgramExit_Click);
            // 
            // btnTrainingProgramDelete
            // 
            this.btnTrainingProgramDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainingProgramDelete.Location = new System.Drawing.Point(232, 20);
            this.btnTrainingProgramDelete.Name = "btnTrainingProgramDelete";
            this.btnTrainingProgramDelete.Size = new System.Drawing.Size(100, 25);
            this.btnTrainingProgramDelete.TabIndex = 28;
            this.btnTrainingProgramDelete.Text = "Delete";
            this.btnTrainingProgramDelete.UseVisualStyleBackColor = true;
            this.btnTrainingProgramDelete.Click += new System.EventHandler(this.btnTrainingProgramDelete_Click);
            // 
            // btnTrainingProgramAdd
            // 
            this.btnTrainingProgramAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainingProgramAdd.Location = new System.Drawing.Point(20, 20);
            this.btnTrainingProgramAdd.Name = "btnTrainingProgramAdd";
            this.btnTrainingProgramAdd.Size = new System.Drawing.Size(100, 25);
            this.btnTrainingProgramAdd.TabIndex = 29;
            this.btnTrainingProgramAdd.Text = "Add";
            this.btnTrainingProgramAdd.UseVisualStyleBackColor = true;
            this.btnTrainingProgramAdd.Click += new System.EventHandler(this.btnTrainingProgramAdd_Click);
            // 
            // btnTrainingProgramUpdate
            // 
            this.btnTrainingProgramUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainingProgramUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnTrainingProgramUpdate.Name = "btnTrainingProgramUpdate";
            this.btnTrainingProgramUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnTrainingProgramUpdate.TabIndex = 27;
            this.btnTrainingProgramUpdate.Text = "Update";
            this.btnTrainingProgramUpdate.UseVisualStyleBackColor = true;
            this.btnTrainingProgramUpdate.Click += new System.EventHandler(this.btnTrainingProgramUpdate_Click);
            // 
            // splitContainer39
            // 
            this.splitContainer39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer39.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer39.IsSplitterFixed = true;
            this.splitContainer39.Location = new System.Drawing.Point(0, 0);
            this.splitContainer39.Name = "splitContainer39";
            // 
            // splitContainer39.Panel1
            // 
            this.splitContainer39.Panel1.Controls.Add(this.TVTrainingProgram);
            this.splitContainer39.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer39.Panel2
            // 
            this.splitContainer39.Panel2.Controls.Add(this.CalTrainingProgram);
            this.splitContainer39.Panel2.Controls.Add(this.label65);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramShortDesc);
            this.splitContainer39.Panel2.Controls.Add(this.label64);
            this.splitContainer39.Panel2.Controls.Add(this.label56);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramCity);
            this.splitContainer39.Panel2.Controls.Add(this.label53);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramContactNo);
            this.splitContainer39.Panel2.Controls.Add(this.label52);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramTiming);
            this.splitContainer39.Panel2.Controls.Add(this.label63);
            this.splitContainer39.Panel2.Controls.Add(this.label62);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramLocation);
            this.splitContainer39.Panel2.Controls.Add(this.label61);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramDuration);
            this.splitContainer39.Panel2.Controls.Add(this.label60);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramDescription);
            this.splitContainer39.Panel2.Controls.Add(this.label58);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramStartDate);
            this.splitContainer39.Panel2.Controls.Add(this.txtTrainingProgramTitle);
            this.splitContainer39.Size = new System.Drawing.Size(1091, 478);
            this.splitContainer39.SplitterDistance = 300;
            this.splitContainer39.TabIndex = 0;
            // 
            // TVTrainingProgram
            // 
            this.TVTrainingProgram.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVTrainingProgram.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVTrainingProgram.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVTrainingProgram.FullRowSelect = true;
            this.TVTrainingProgram.HideSelection = false;
            this.TVTrainingProgram.Location = new System.Drawing.Point(0, 25);
            this.TVTrainingProgram.Name = "TVTrainingProgram";
            this.TVTrainingProgram.Size = new System.Drawing.Size(298, 451);
            this.TVTrainingProgram.TabIndex = 28;
            this.TVTrainingProgram.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVTrainingProgram.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVTrainingProgram_MouseDoubleClick);
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(298, 25);
            this.label3.TabIndex = 41;
            this.label3.Text = "Training Program";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CalTrainingProgram
            // 
            this.CalTrainingProgram.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalTrainingProgram.Location = new System.Drawing.Point(112, 33);
            this.CalTrainingProgram.Name = "CalTrainingProgram";
            this.CalTrainingProgram.TabIndex = 223;
            this.CalTrainingProgram.Visible = false;
            this.CalTrainingProgram.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.CalTrainingProgram_DateSelected);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(386, 61);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(103, 16);
            this.label65.TabIndex = 240;
            this.label65.Text = "Short Desciption";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramShortDesc
            // 
            this.txtTrainingProgramShortDesc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramShortDesc.Location = new System.Drawing.Point(383, 80);
            this.txtTrainingProgramShortDesc.Name = "txtTrainingProgramShortDesc";
            this.txtTrainingProgramShortDesc.Size = new System.Drawing.Size(380, 22);
            this.txtTrainingProgramShortDesc.TabIndex = 239;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(30, 62);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(31, 16);
            this.label64.TabIndex = 238;
            this.label64.Text = "Title";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(28, 330);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(30, 16);
            this.label56.TabIndex = 235;
            this.label56.Text = "City";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramCity
            // 
            this.txtTrainingProgramCity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramCity.Location = new System.Drawing.Point(25, 348);
            this.txtTrainingProgramCity.Name = "txtTrainingProgramCity";
            this.txtTrainingProgramCity.Size = new System.Drawing.Size(352, 22);
            this.txtTrainingProgramCity.TabIndex = 236;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(386, 278);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(72, 16);
            this.label53.TabIndex = 233;
            this.label53.Text = "Contact No";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramContactNo
            // 
            this.txtTrainingProgramContactNo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramContactNo.Location = new System.Drawing.Point(383, 297);
            this.txtTrainingProgramContactNo.Name = "txtTrainingProgramContactNo";
            this.txtTrainingProgramContactNo.Size = new System.Drawing.Size(380, 22);
            this.txtTrainingProgramContactNo.TabIndex = 234;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(28, 278);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(45, 16);
            this.label52.TabIndex = 231;
            this.label52.Text = "Timing";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramTiming
            // 
            this.txtTrainingProgramTiming.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramTiming.Location = new System.Drawing.Point(25, 297);
            this.txtTrainingProgramTiming.Name = "txtTrainingProgramTiming";
            this.txtTrainingProgramTiming.Size = new System.Drawing.Size(352, 22);
            this.txtTrainingProgramTiming.TabIndex = 232;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(386, 228);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(55, 16);
            this.label63.TabIndex = 230;
            this.label63.Text = "Duration";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(28, 225);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(56, 16);
            this.label62.TabIndex = 228;
            this.label62.Text = "Location";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramLocation
            // 
            this.txtTrainingProgramLocation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramLocation.Location = new System.Drawing.Point(25, 245);
            this.txtTrainingProgramLocation.Name = "txtTrainingProgramLocation";
            this.txtTrainingProgramLocation.Size = new System.Drawing.Size(352, 22);
            this.txtTrainingProgramLocation.TabIndex = 229;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(20, 136);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(0, 16);
            this.label61.TabIndex = 226;
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramDuration
            // 
            this.txtTrainingProgramDuration.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramDuration.Location = new System.Drawing.Point(383, 245);
            this.txtTrainingProgramDuration.Name = "txtTrainingProgramDuration";
            this.txtTrainingProgramDuration.Size = new System.Drawing.Size(380, 22);
            this.txtTrainingProgramDuration.TabIndex = 227;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(28, 117);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(72, 16);
            this.label60.TabIndex = 224;
            this.label60.Text = "Description";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramDescription
            // 
            this.txtTrainingProgramDescription.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramDescription.Location = new System.Drawing.Point(25, 136);
            this.txtTrainingProgramDescription.Multiline = true;
            this.txtTrainingProgramDescription.Name = "txtTrainingProgramDescription";
            this.txtTrainingProgramDescription.Size = new System.Drawing.Size(738, 84);
            this.txtTrainingProgramDescription.TabIndex = 225;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(28, 14);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(62, 16);
            this.label58.TabIndex = 221;
            this.label58.Text = "StartDate";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTrainingProgramStartDate
            // 
            this.txtTrainingProgramStartDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramStartDate.Location = new System.Drawing.Point(25, 33);
            this.txtTrainingProgramStartDate.Name = "txtTrainingProgramStartDate";
            this.txtTrainingProgramStartDate.Size = new System.Drawing.Size(109, 22);
            this.txtTrainingProgramStartDate.TabIndex = 222;
            this.txtTrainingProgramStartDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtTrainingProgramStartDate_MouseDoubleClick);
            // 
            // txtTrainingProgramTitle
            // 
            this.txtTrainingProgramTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrainingProgramTitle.Location = new System.Drawing.Point(25, 80);
            this.txtTrainingProgramTitle.Name = "txtTrainingProgramTitle";
            this.txtTrainingProgramTitle.Size = new System.Drawing.Size(352, 22);
            this.txtTrainingProgramTitle.TabIndex = 237;
            // 
            // tabPlacement
            // 
            this.tabPlacement.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPlacement.Controls.Add(this.splitContainer30);
            this.tabPlacement.Location = new System.Drawing.Point(4, 22);
            this.tabPlacement.Name = "tabPlacement";
            this.tabPlacement.Padding = new System.Windows.Forms.Padding(3);
            this.tabPlacement.Size = new System.Drawing.Size(1099, 550);
            this.tabPlacement.TabIndex = 12;
            this.tabPlacement.Text = "Placement";
            this.tabPlacement.UseVisualStyleBackColor = true;
            // 
            // splitContainer30
            // 
            this.splitContainer30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer30.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer30.IsSplitterFixed = true;
            this.splitContainer30.Location = new System.Drawing.Point(3, 3);
            this.splitContainer30.Name = "splitContainer30";
            this.splitContainer30.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer30.Panel1
            // 
            this.splitContainer30.Panel1.Controls.Add(this.btnPlacementShowPdf);
            this.splitContainer30.Panel1.Controls.Add(this.btnPlacementShowImage);
            this.splitContainer30.Panel1.Controls.Add(this.btnPlacementRefresh);
            this.splitContainer30.Panel1.Controls.Add(this.btnPlacementExit);
            // 
            // splitContainer30.Panel2
            // 
            this.splitContainer30.Panel2.Controls.Add(this.splitContainer31);
            this.splitContainer30.Size = new System.Drawing.Size(1091, 542);
            this.splitContainer30.SplitterDistance = 60;
            this.splitContainer30.TabIndex = 4;
            // 
            // btnPlacementShowPdf
            // 
            this.btnPlacementShowPdf.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacementShowPdf.Location = new System.Drawing.Point(232, 20);
            this.btnPlacementShowPdf.Name = "btnPlacementShowPdf";
            this.btnPlacementShowPdf.Size = new System.Drawing.Size(100, 25);
            this.btnPlacementShowPdf.TabIndex = 35;
            this.btnPlacementShowPdf.Text = "Show Pdf";
            this.btnPlacementShowPdf.UseVisualStyleBackColor = true;
            this.btnPlacementShowPdf.Click += new System.EventHandler(this.btnPlacementShowPdf_Click);
            // 
            // btnPlacementShowImage
            // 
            this.btnPlacementShowImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacementShowImage.Location = new System.Drawing.Point(126, 20);
            this.btnPlacementShowImage.Name = "btnPlacementShowImage";
            this.btnPlacementShowImage.Size = new System.Drawing.Size(100, 25);
            this.btnPlacementShowImage.TabIndex = 32;
            this.btnPlacementShowImage.Text = "Show Image";
            this.btnPlacementShowImage.UseVisualStyleBackColor = true;
            this.btnPlacementShowImage.Click += new System.EventHandler(this.btnPlacementShowImage_Click);
            // 
            // btnPlacementRefresh
            // 
            this.btnPlacementRefresh.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacementRefresh.Location = new System.Drawing.Point(20, 20);
            this.btnPlacementRefresh.Name = "btnPlacementRefresh";
            this.btnPlacementRefresh.Size = new System.Drawing.Size(100, 25);
            this.btnPlacementRefresh.TabIndex = 31;
            this.btnPlacementRefresh.Text = "Refresh";
            this.btnPlacementRefresh.UseVisualStyleBackColor = true;
            this.btnPlacementRefresh.Click += new System.EventHandler(this.btnPlacementRefresh_Click);
            // 
            // btnPlacementExit
            // 
            this.btnPlacementExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlacementExit.Location = new System.Drawing.Point(946, 20);
            this.btnPlacementExit.Name = "btnPlacementExit";
            this.btnPlacementExit.Size = new System.Drawing.Size(100, 25);
            this.btnPlacementExit.TabIndex = 30;
            this.btnPlacementExit.Text = "Exit";
            this.btnPlacementExit.UseVisualStyleBackColor = true;
            this.btnPlacementExit.Click += new System.EventHandler(this.btnPlacementExit_Click);
            // 
            // splitContainer31
            // 
            this.splitContainer31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer31.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer31.IsSplitterFixed = true;
            this.splitContainer31.Location = new System.Drawing.Point(0, 0);
            this.splitContainer31.Name = "splitContainer31";
            // 
            // splitContainer31.Panel1
            // 
            this.splitContainer31.Panel1.Controls.Add(this.TVPlacement);
            this.splitContainer31.Panel1.Controls.Add(this.label38);
            // 
            // splitContainer31.Panel2
            // 
            this.splitContainer31.Panel2.Controls.Add(this.splitContainer32);
            this.splitContainer31.Size = new System.Drawing.Size(1091, 478);
            this.splitContainer31.SplitterDistance = 300;
            this.splitContainer31.TabIndex = 0;
            // 
            // TVPlacement
            // 
            this.TVPlacement.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVPlacement.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVPlacement.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVPlacement.FullRowSelect = true;
            this.TVPlacement.HideSelection = false;
            this.TVPlacement.Location = new System.Drawing.Point(0, 25);
            this.TVPlacement.Name = "TVPlacement";
            this.TVPlacement.Size = new System.Drawing.Size(298, 451);
            this.TVPlacement.TabIndex = 28;
            this.TVPlacement.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVPlacement.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVPlacement_MouseDoubleClick);
            // 
            // label38
            // 
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Dock = System.Windows.Forms.DockStyle.Top;
            this.label38.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(0, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(298, 25);
            this.label38.TabIndex = 39;
            this.label38.Text = "Placement Inquiries";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer32
            // 
            this.splitContainer32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer32.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer32.IsSplitterFixed = true;
            this.splitContainer32.Location = new System.Drawing.Point(0, 0);
            this.splitContainer32.Name = "splitContainer32";
            this.splitContainer32.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer32.Panel1
            // 
            this.splitContainer32.Panel1.Controls.Add(this.label44);
            this.splitContainer32.Panel1.Controls.Add(this.rbtPlacementPdf);
            this.splitContainer32.Panel1.Controls.Add(this.txtPlacementEmail);
            this.splitContainer32.Panel1.Controls.Add(this.txtPlacementFileName);
            this.splitContainer32.Panel1.Controls.Add(this.label48);
            this.splitContainer32.Panel1.Controls.Add(this.rbtPlacementImage);
            this.splitContainer32.Panel1.Controls.Add(this.label47);
            this.splitContainer32.Panel1.Controls.Add(this.label49);
            this.splitContainer32.Panel1.Controls.Add(this.txtPlacementExperience);
            this.splitContainer32.Panel1.Controls.Add(this.txtPlacementEducation);
            this.splitContainer32.Panel1.Controls.Add(this.label45);
            this.splitContainer32.Panel1.Controls.Add(this.label40);
            this.splitContainer32.Panel1.Controls.Add(this.txtPlacementName);
            this.splitContainer32.Panel1.Controls.Add(this.label46);
            this.splitContainer32.Panel1.Controls.Add(this.txtPlacementPhoneNo);
            this.splitContainer32.Panel1.Controls.Add(this.txtPlacementAge);
            // 
            // splitContainer32.Panel2
            // 
            this.splitContainer32.Panel2.Controls.Add(this.txtPlacementMessage);
            this.splitContainer32.Panel2.Controls.Add(this.label43);
            this.splitContainer32.Size = new System.Drawing.Size(787, 478);
            this.splitContainer32.SplitterDistance = 275;
            this.splitContainer32.TabIndex = 300;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(28, 15);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(41, 16);
            this.label44.TabIndex = 28;
            this.label44.Text = "Name";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rbtPlacementPdf
            // 
            this.rbtPlacementPdf.AutoSize = true;
            this.rbtPlacementPdf.Location = new System.Drawing.Point(478, 234);
            this.rbtPlacementPdf.Name = "rbtPlacementPdf";
            this.rbtPlacementPdf.Size = new System.Drawing.Size(41, 17);
            this.rbtPlacementPdf.TabIndex = 33;
            this.rbtPlacementPdf.TabStop = true;
            this.rbtPlacementPdf.Text = "Pdf";
            this.rbtPlacementPdf.UseVisualStyleBackColor = true;
            // 
            // txtPlacementEmail
            // 
            this.txtPlacementEmail.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementEmail.Location = new System.Drawing.Point(25, 84);
            this.txtPlacementEmail.Name = "txtPlacementEmail";
            this.txtPlacementEmail.Size = new System.Drawing.Size(363, 22);
            this.txtPlacementEmail.TabIndex = 35;
            // 
            // txtPlacementFileName
            // 
            this.txtPlacementFileName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementFileName.Location = new System.Drawing.Point(25, 234);
            this.txtPlacementFileName.Name = "txtPlacementFileName";
            this.txtPlacementFileName.Size = new System.Drawing.Size(373, 22);
            this.txtPlacementFileName.TabIndex = 231;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(28, 169);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(72, 16);
            this.label48.TabIndex = 36;
            this.label48.Text = "Experience";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rbtPlacementImage
            // 
            this.rbtPlacementImage.AutoSize = true;
            this.rbtPlacementImage.Location = new System.Drawing.Point(419, 234);
            this.rbtPlacementImage.Name = "rbtPlacementImage";
            this.rbtPlacementImage.Size = new System.Drawing.Size(54, 17);
            this.rbtPlacementImage.TabIndex = 32;
            this.rbtPlacementImage.TabStop = true;
            this.rbtPlacementImage.Text = "Image";
            this.rbtPlacementImage.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(28, 67);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(40, 16);
            this.label47.TabIndex = 34;
            this.label47.Text = "Email";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(28, 216);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(62, 16);
            this.label49.TabIndex = 230;
            this.label49.Text = "FileName";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacementExperience
            // 
            this.txtPlacementExperience.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementExperience.Location = new System.Drawing.Point(25, 187);
            this.txtPlacementExperience.Name = "txtPlacementExperience";
            this.txtPlacementExperience.Size = new System.Drawing.Size(737, 22);
            this.txtPlacementExperience.TabIndex = 37;
            // 
            // txtPlacementEducation
            // 
            this.txtPlacementEducation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementEducation.Location = new System.Drawing.Point(394, 136);
            this.txtPlacementEducation.Name = "txtPlacementEducation";
            this.txtPlacementEducation.Size = new System.Drawing.Size(368, 22);
            this.txtPlacementEducation.TabIndex = 229;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(397, 67);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(64, 16);
            this.label45.TabIndex = 222;
            this.label45.Text = "Phone No";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(397, 117);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 16);
            this.label40.TabIndex = 228;
            this.label40.Text = "Education";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacementName
            // 
            this.txtPlacementName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementName.Location = new System.Drawing.Point(25, 33);
            this.txtPlacementName.Name = "txtPlacementName";
            this.txtPlacementName.Size = new System.Drawing.Size(737, 22);
            this.txtPlacementName.TabIndex = 29;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(28, 117);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(30, 16);
            this.label46.TabIndex = 226;
            this.label46.Text = "Age";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPlacementPhoneNo
            // 
            this.txtPlacementPhoneNo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementPhoneNo.Location = new System.Drawing.Point(394, 84);
            this.txtPlacementPhoneNo.Name = "txtPlacementPhoneNo";
            this.txtPlacementPhoneNo.Size = new System.Drawing.Size(368, 22);
            this.txtPlacementPhoneNo.TabIndex = 223;
            // 
            // txtPlacementAge
            // 
            this.txtPlacementAge.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementAge.Location = new System.Drawing.Point(25, 136);
            this.txtPlacementAge.Name = "txtPlacementAge";
            this.txtPlacementAge.Size = new System.Drawing.Size(363, 22);
            this.txtPlacementAge.TabIndex = 227;
            // 
            // txtPlacementMessage
            // 
            this.txtPlacementMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPlacementMessage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlacementMessage.Location = new System.Drawing.Point(0, 25);
            this.txtPlacementMessage.Multiline = true;
            this.txtPlacementMessage.Name = "txtPlacementMessage";
            this.txtPlacementMessage.Size = new System.Drawing.Size(785, 172);
            this.txtPlacementMessage.TabIndex = 225;
            // 
            // label43
            // 
            this.label43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label43.Dock = System.Windows.Forms.DockStyle.Top;
            this.label43.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(0, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(785, 25);
            this.label43.TabIndex = 233;
            this.label43.Text = "Message";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabJobVaccancys
            // 
            this.tabJobVaccancys.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabJobVaccancys.Controls.Add(this.splitContainer15);
            this.tabJobVaccancys.Location = new System.Drawing.Point(4, 22);
            this.tabJobVaccancys.Name = "tabJobVaccancys";
            this.tabJobVaccancys.Padding = new System.Windows.Forms.Padding(3);
            this.tabJobVaccancys.Size = new System.Drawing.Size(1099, 550);
            this.tabJobVaccancys.TabIndex = 8;
            this.tabJobVaccancys.Text = "Job Vacancies";
            this.tabJobVaccancys.UseVisualStyleBackColor = true;
            // 
            // splitContainer15
            // 
            this.splitContainer15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer15.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer15.IsSplitterFixed = true;
            this.splitContainer15.Location = new System.Drawing.Point(3, 3);
            this.splitContainer15.Name = "splitContainer15";
            this.splitContainer15.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer15.Panel1
            // 
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacDown);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacUp);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacShowImage);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacDefault);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacULImage);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacExit);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacDelete);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacAdd);
            this.splitContainer15.Panel1.Controls.Add(this.btnJobVacUpdate);
            // 
            // splitContainer15.Panel2
            // 
            this.splitContainer15.Panel2.Controls.Add(this.splitContainer19);
            this.splitContainer15.Size = new System.Drawing.Size(1091, 542);
            this.splitContainer15.SplitterDistance = 60;
            this.splitContainer15.TabIndex = 2;
            // 
            // btnJobVacDown
            // 
            this.btnJobVacDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacDown.Location = new System.Drawing.Point(606, 20);
            this.btnJobVacDown.Name = "btnJobVacDown";
            this.btnJobVacDown.Size = new System.Drawing.Size(50, 25);
            this.btnJobVacDown.TabIndex = 40;
            this.btnJobVacDown.Text = "\\/";
            this.btnJobVacDown.UseVisualStyleBackColor = true;
            this.btnJobVacDown.Click += new System.EventHandler(this.btnJobVacDown_Click);
            // 
            // btnJobVacUp
            // 
            this.btnJobVacUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacUp.Location = new System.Drawing.Point(550, 20);
            this.btnJobVacUp.Name = "btnJobVacUp";
            this.btnJobVacUp.Size = new System.Drawing.Size(50, 25);
            this.btnJobVacUp.TabIndex = 39;
            this.btnJobVacUp.Text = "/\\";
            this.btnJobVacUp.UseVisualStyleBackColor = true;
            this.btnJobVacUp.Click += new System.EventHandler(this.btnJobVacUp_Click);
            // 
            // btnJobVacShowImage
            // 
            this.btnJobVacShowImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacShowImage.Location = new System.Drawing.Point(444, 20);
            this.btnJobVacShowImage.Name = "btnJobVacShowImage";
            this.btnJobVacShowImage.Size = new System.Drawing.Size(100, 25);
            this.btnJobVacShowImage.TabIndex = 37;
            this.btnJobVacShowImage.Text = "Show Image";
            this.btnJobVacShowImage.UseVisualStyleBackColor = true;
            this.btnJobVacShowImage.Click += new System.EventHandler(this.btnJobVacShowImage_Click);
            // 
            // btnJobVacDefault
            // 
            this.btnJobVacDefault.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacDefault.Location = new System.Drawing.Point(840, 20);
            this.btnJobVacDefault.Name = "btnJobVacDefault";
            this.btnJobVacDefault.Size = new System.Drawing.Size(100, 25);
            this.btnJobVacDefault.TabIndex = 35;
            this.btnJobVacDefault.Text = "Default";
            this.btnJobVacDefault.UseVisualStyleBackColor = true;
            this.btnJobVacDefault.Click += new System.EventHandler(this.btnJobVacDefault_Click);
            // 
            // btnJobVacULImage
            // 
            this.btnJobVacULImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacULImage.Location = new System.Drawing.Point(338, 20);
            this.btnJobVacULImage.Name = "btnJobVacULImage";
            this.btnJobVacULImage.Size = new System.Drawing.Size(100, 25);
            this.btnJobVacULImage.TabIndex = 31;
            this.btnJobVacULImage.Text = "Upload Image";
            this.btnJobVacULImage.UseVisualStyleBackColor = true;
            this.btnJobVacULImage.Click += new System.EventHandler(this.btnJobVacULImage_Click);
            // 
            // btnJobVacExit
            // 
            this.btnJobVacExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacExit.Location = new System.Drawing.Point(946, 20);
            this.btnJobVacExit.Name = "btnJobVacExit";
            this.btnJobVacExit.Size = new System.Drawing.Size(100, 25);
            this.btnJobVacExit.TabIndex = 30;
            this.btnJobVacExit.Text = "Exit";
            this.btnJobVacExit.UseVisualStyleBackColor = true;
            this.btnJobVacExit.Click += new System.EventHandler(this.btnJobVacExit_Click);
            // 
            // btnJobVacDelete
            // 
            this.btnJobVacDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacDelete.Location = new System.Drawing.Point(232, 20);
            this.btnJobVacDelete.Name = "btnJobVacDelete";
            this.btnJobVacDelete.Size = new System.Drawing.Size(100, 25);
            this.btnJobVacDelete.TabIndex = 28;
            this.btnJobVacDelete.Text = "Delete";
            this.btnJobVacDelete.UseVisualStyleBackColor = true;
            this.btnJobVacDelete.Click += new System.EventHandler(this.btnJobVacDelete_Click);
            // 
            // btnJobVacAdd
            // 
            this.btnJobVacAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacAdd.Location = new System.Drawing.Point(20, 20);
            this.btnJobVacAdd.Name = "btnJobVacAdd";
            this.btnJobVacAdd.Size = new System.Drawing.Size(100, 25);
            this.btnJobVacAdd.TabIndex = 29;
            this.btnJobVacAdd.Text = "Add";
            this.btnJobVacAdd.UseVisualStyleBackColor = true;
            this.btnJobVacAdd.Click += new System.EventHandler(this.btnJobVacAdd_Click);
            // 
            // btnJobVacUpdate
            // 
            this.btnJobVacUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobVacUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnJobVacUpdate.Name = "btnJobVacUpdate";
            this.btnJobVacUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnJobVacUpdate.TabIndex = 27;
            this.btnJobVacUpdate.Text = "Update";
            this.btnJobVacUpdate.UseVisualStyleBackColor = true;
            this.btnJobVacUpdate.Click += new System.EventHandler(this.btnJobVacUpdate_Click);
            // 
            // splitContainer19
            // 
            this.splitContainer19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer19.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer19.IsSplitterFixed = true;
            this.splitContainer19.Location = new System.Drawing.Point(0, 0);
            this.splitContainer19.Name = "splitContainer19";
            // 
            // splitContainer19.Panel1
            // 
            this.splitContainer19.Panel1.Controls.Add(this.TVJobVaccancys);
            this.splitContainer19.Panel1.Controls.Add(this.label2);
            // 
            // splitContainer19.Panel2
            // 
            this.splitContainer19.Panel2.Controls.Add(this.splitContainer20);
            this.splitContainer19.Size = new System.Drawing.Size(1091, 478);
            this.splitContainer19.SplitterDistance = 300;
            this.splitContainer19.TabIndex = 0;
            // 
            // TVJobVaccancys
            // 
            this.TVJobVaccancys.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVJobVaccancys.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVJobVaccancys.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVJobVaccancys.FullRowSelect = true;
            this.TVJobVaccancys.HideSelection = false;
            this.TVJobVaccancys.Location = new System.Drawing.Point(0, 25);
            this.TVJobVaccancys.Name = "TVJobVaccancys";
            this.TVJobVaccancys.Size = new System.Drawing.Size(298, 451);
            this.TVJobVaccancys.TabIndex = 28;
            this.TVJobVaccancys.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVJobVaccancys.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVJobVaccancys_MouseDoubleClick);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(298, 25);
            this.label2.TabIndex = 40;
            this.label2.Text = "Job Vacancies";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer20
            // 
            this.splitContainer20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer20.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer20.IsSplitterFixed = true;
            this.splitContainer20.Location = new System.Drawing.Point(0, 0);
            this.splitContainer20.Name = "splitContainer20";
            this.splitContainer20.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer20.Panel1
            // 
            this.splitContainer20.Panel1.Controls.Add(this.chkJobVacFlag);
            this.splitContainer20.Panel1.Controls.Add(this.xCalJobVaccancys);
            this.splitContainer20.Panel1.Controls.Add(this.label18);
            this.splitContainer20.Panel1.Controls.Add(this.txtJobVacTitle);
            this.splitContainer20.Panel1.Controls.Add(this.txtJobVacDesc);
            this.splitContainer20.Panel1.Controls.Add(this.label19);
            this.splitContainer20.Panel1.Controls.Add(this.label21);
            this.splitContainer20.Panel1.Controls.Add(this.txtJobVacLinkAdd);
            this.splitContainer20.Panel1.Controls.Add(this.label22);
            this.splitContainer20.Panel1.Controls.Add(this.txtJobVacDate);
            this.splitContainer20.Size = new System.Drawing.Size(787, 478);
            this.splitContainer20.SplitterDistance = 275;
            this.splitContainer20.TabIndex = 34;
            // 
            // chkJobVacFlag
            // 
            this.chkJobVacFlag.AutoSize = true;
            this.chkJobVacFlag.Location = new System.Drawing.Point(715, 189);
            this.chkJobVacFlag.Name = "chkJobVacFlag";
            this.chkJobVacFlag.Size = new System.Drawing.Size(66, 17);
            this.chkJobVacFlag.TabIndex = 222;
            this.chkJobVacFlag.Text = "LinkFlag";
            this.chkJobVacFlag.UseVisualStyleBackColor = true;
            // 
            // xCalJobVaccancys
            // 
            this.xCalJobVaccancys.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xCalJobVaccancys.Location = new System.Drawing.Point(236, 23);
            this.xCalJobVaccancys.Name = "xCalJobVaccancys";
            this.xCalJobVaccancys.TabIndex = 218;
            this.xCalJobVaccancys.Visible = false;
            this.xCalJobVaccancys.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.xCalJobVaccancys_DateSelected);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(28, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 16);
            this.label18.TabIndex = 38;
            this.label18.Text = "Title";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtJobVacTitle
            // 
            this.txtJobVacTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobVacTitle.Location = new System.Drawing.Point(25, 84);
            this.txtJobVacTitle.Name = "txtJobVacTitle";
            this.txtJobVacTitle.Size = new System.Drawing.Size(742, 22);
            this.txtJobVacTitle.TabIndex = 39;
            // 
            // txtJobVacDesc
            // 
            this.txtJobVacDesc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobVacDesc.Location = new System.Drawing.Point(25, 136);
            this.txtJobVacDesc.Name = "txtJobVacDesc";
            this.txtJobVacDesc.Size = new System.Drawing.Size(742, 22);
            this.txtJobVacDesc.TabIndex = 35;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(28, 169);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 16);
            this.label19.TabIndex = 36;
            this.label19.Text = "Link Address";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(28, 118);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 16);
            this.label21.TabIndex = 34;
            this.label21.Text = "Desc";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtJobVacLinkAdd
            // 
            this.txtJobVacLinkAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobVacLinkAdd.Location = new System.Drawing.Point(25, 187);
            this.txtJobVacLinkAdd.Name = "txtJobVacLinkAdd";
            this.txtJobVacLinkAdd.Size = new System.Drawing.Size(680, 22);
            this.txtJobVacLinkAdd.TabIndex = 37;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(28, 15);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 16);
            this.label22.TabIndex = 28;
            this.label22.Text = "Date";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtJobVacDate
            // 
            this.txtJobVacDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobVacDate.Location = new System.Drawing.Point(25, 33);
            this.txtJobVacDate.Name = "txtJobVacDate";
            this.txtJobVacDate.Size = new System.Drawing.Size(182, 22);
            this.txtJobVacDate.TabIndex = 29;
            this.txtJobVacDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtJobVacDate_MouseDoubleClick);
            // 
            // TC
            // 
            this.TC.Controls.Add(this.tabJobVaccancys);
            this.TC.Controls.Add(this.tabPlacement);
            this.TC.Controls.Add(this.tabTrainingProgram);
            this.TC.Controls.Add(this.tabPlacedStudent);
            this.TC.Controls.Add(this.tabCQNews);
            this.TC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TC.Location = new System.Drawing.Point(0, 0);
            this.TC.Name = "TC";
            this.TC.SelectedIndex = 0;
            this.TC.Size = new System.Drawing.Size(1107, 576);
            this.TC.TabIndex = 0;
            this.TC.SelectedIndexChanged += new System.EventHandler(this.TC_SelectedIndexChanged);
            // 
            // tabCQNews
            // 
            this.tabCQNews.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabCQNews.Controls.Add(this.splitContainer1);
            this.tabCQNews.Location = new System.Drawing.Point(4, 22);
            this.tabCQNews.Name = "tabCQNews";
            this.tabCQNews.Padding = new System.Windows.Forms.Padding(3);
            this.tabCQNews.Size = new System.Drawing.Size(1099, 550);
            this.tabCQNews.TabIndex = 17;
            this.tabCQNews.Text = "CQNews";
            this.tabCQNews.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsClearGarbage);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsWrite);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsMoveDown);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsMoveUp);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsShowImage);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsExit);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsUploadImage);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsDelete);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsAdd);
            this.splitContainer1.Panel1.Controls.Add(this.btnCQNewsUpdate);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1091, 542);
            this.splitContainer1.SplitterDistance = 60;
            this.splitContainer1.TabIndex = 3;
            // 
            // btnCQNewsClearGarbage
            // 
            this.btnCQNewsClearGarbage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsClearGarbage.Location = new System.Drawing.Point(840, 20);
            this.btnCQNewsClearGarbage.Name = "btnCQNewsClearGarbage";
            this.btnCQNewsClearGarbage.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsClearGarbage.TabIndex = 42;
            this.btnCQNewsClearGarbage.Text = "Clear Garbage";
            this.btnCQNewsClearGarbage.UseVisualStyleBackColor = true;
            this.btnCQNewsClearGarbage.Click += new System.EventHandler(this.btnCQNewsClearGarbage_Click);
            // 
            // btnCQNewsWrite
            // 
            this.btnCQNewsWrite.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsWrite.Location = new System.Drawing.Point(662, 20);
            this.btnCQNewsWrite.Name = "btnCQNewsWrite";
            this.btnCQNewsWrite.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsWrite.TabIndex = 41;
            this.btnCQNewsWrite.Text = "Write";
            this.btnCQNewsWrite.UseVisualStyleBackColor = true;
            this.btnCQNewsWrite.Click += new System.EventHandler(this.btnCQNewsWrite_Click);
            // 
            // btnCQNewsMoveDown
            // 
            this.btnCQNewsMoveDown.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsMoveDown.Location = new System.Drawing.Point(606, 20);
            this.btnCQNewsMoveDown.Name = "btnCQNewsMoveDown";
            this.btnCQNewsMoveDown.Size = new System.Drawing.Size(50, 25);
            this.btnCQNewsMoveDown.TabIndex = 40;
            this.btnCQNewsMoveDown.Text = "\\/";
            this.btnCQNewsMoveDown.UseVisualStyleBackColor = true;
            this.btnCQNewsMoveDown.Click += new System.EventHandler(this.btnCQNewsMoveDown_Click);
            // 
            // btnCQNewsMoveUp
            // 
            this.btnCQNewsMoveUp.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsMoveUp.Location = new System.Drawing.Point(550, 20);
            this.btnCQNewsMoveUp.Name = "btnCQNewsMoveUp";
            this.btnCQNewsMoveUp.Size = new System.Drawing.Size(50, 25);
            this.btnCQNewsMoveUp.TabIndex = 39;
            this.btnCQNewsMoveUp.Text = "/\\";
            this.btnCQNewsMoveUp.UseVisualStyleBackColor = true;
            this.btnCQNewsMoveUp.Click += new System.EventHandler(this.btnCQNewsMoveUp_Click);
            // 
            // btnCQNewsShowImage
            // 
            this.btnCQNewsShowImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsShowImage.Location = new System.Drawing.Point(444, 20);
            this.btnCQNewsShowImage.Name = "btnCQNewsShowImage";
            this.btnCQNewsShowImage.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsShowImage.TabIndex = 37;
            this.btnCQNewsShowImage.Text = "Show Image";
            this.btnCQNewsShowImage.UseVisualStyleBackColor = true;
            this.btnCQNewsShowImage.Click += new System.EventHandler(this.btnCQNewsShowImage_Click);
            // 
            // btnCQNewsExit
            // 
            this.btnCQNewsExit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsExit.Location = new System.Drawing.Point(946, 20);
            this.btnCQNewsExit.Name = "btnCQNewsExit";
            this.btnCQNewsExit.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsExit.TabIndex = 35;
            this.btnCQNewsExit.Text = "Exit";
            this.btnCQNewsExit.UseVisualStyleBackColor = true;
            this.btnCQNewsExit.Click += new System.EventHandler(this.btnCQNewsExit_Click);
            // 
            // btnCQNewsUploadImage
            // 
            this.btnCQNewsUploadImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsUploadImage.Location = new System.Drawing.Point(338, 20);
            this.btnCQNewsUploadImage.Name = "btnCQNewsUploadImage";
            this.btnCQNewsUploadImage.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsUploadImage.TabIndex = 31;
            this.btnCQNewsUploadImage.Text = "Upload Image";
            this.btnCQNewsUploadImage.UseVisualStyleBackColor = true;
            this.btnCQNewsUploadImage.Click += new System.EventHandler(this.btnCQNewsUploadImage_Click);
            // 
            // btnCQNewsDelete
            // 
            this.btnCQNewsDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsDelete.Location = new System.Drawing.Point(232, 20);
            this.btnCQNewsDelete.Name = "btnCQNewsDelete";
            this.btnCQNewsDelete.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsDelete.TabIndex = 28;
            this.btnCQNewsDelete.Text = "Delete";
            this.btnCQNewsDelete.UseVisualStyleBackColor = true;
            this.btnCQNewsDelete.Click += new System.EventHandler(this.btnCQNewsDelete_Click);
            // 
            // btnCQNewsAdd
            // 
            this.btnCQNewsAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsAdd.Location = new System.Drawing.Point(20, 20);
            this.btnCQNewsAdd.Name = "btnCQNewsAdd";
            this.btnCQNewsAdd.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsAdd.TabIndex = 29;
            this.btnCQNewsAdd.Text = "Add";
            this.btnCQNewsAdd.UseVisualStyleBackColor = true;
            this.btnCQNewsAdd.Click += new System.EventHandler(this.btnCQNewsAdd_Click);
            // 
            // btnCQNewsUpdate
            // 
            this.btnCQNewsUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCQNewsUpdate.Location = new System.Drawing.Point(126, 20);
            this.btnCQNewsUpdate.Name = "btnCQNewsUpdate";
            this.btnCQNewsUpdate.Size = new System.Drawing.Size(100, 25);
            this.btnCQNewsUpdate.TabIndex = 27;
            this.btnCQNewsUpdate.Text = "Update";
            this.btnCQNewsUpdate.UseVisualStyleBackColor = true;
            this.btnCQNewsUpdate.Click += new System.EventHandler(this.btnCQNewsUpdate_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.TVCQNews);
            this.splitContainer2.Panel1.Controls.Add(this.label5);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Size = new System.Drawing.Size(1091, 478);
            this.splitContainer2.SplitterDistance = 300;
            this.splitContainer2.TabIndex = 0;
            // 
            // TVCQNews
            // 
            this.TVCQNews.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TVCQNews.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawText;
            this.TVCQNews.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TVCQNews.FullRowSelect = true;
            this.TVCQNews.HideSelection = false;
            this.TVCQNews.Location = new System.Drawing.Point(0, 25);
            this.TVCQNews.Name = "TVCQNews";
            this.TVCQNews.Size = new System.Drawing.Size(298, 451);
            this.TVCQNews.TabIndex = 28;
            this.TVCQNews.DrawNode += new System.Windows.Forms.DrawTreeNodeEventHandler(this.TV_DrawNode);
            this.TVCQNews.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TVCQNews_MouseDoubleClick);
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(298, 25);
            this.label5.TabIndex = 43;
            this.label5.Text = "CQ News";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.CalCQNews);
            this.splitContainer3.Panel1.Controls.Add(this.label1);
            this.splitContainer3.Panel1.Controls.Add(this.txtCQNewsDate);
            this.splitContainer3.Panel1.Controls.Add(this.label6);
            this.splitContainer3.Panel1.Controls.Add(this.txtCQNewsDescription);
            this.splitContainer3.Panel1.Controls.Add(this.label8);
            this.splitContainer3.Panel1.Controls.Add(this.txtCQNewsTitle);
            this.splitContainer3.Size = new System.Drawing.Size(787, 478);
            this.splitContainer3.SplitterDistance = 300;
            this.splitContainer3.TabIndex = 34;
            // 
            // CalCQNews
            // 
            this.CalCQNews.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalCQNews.Location = new System.Drawing.Point(449, 67);
            this.CalCQNews.Name = "CalCQNews";
            this.CalCQNews.TabIndex = 226;
            this.CalCQNews.Visible = false;
            this.CalCQNews.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.CalCQNews_DateSelected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(571, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 16);
            this.label1.TabIndex = 224;
            this.label1.Text = "Date";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCQNewsDate
            // 
            this.txtCQNewsDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCQNewsDate.Location = new System.Drawing.Point(567, 33);
            this.txtCQNewsDate.Name = "txtCQNewsDate";
            this.txtCQNewsDate.Size = new System.Drawing.Size(109, 22);
            this.txtCQNewsDate.TabIndex = 225;
            this.txtCQNewsDate.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtCQNewsDate_MouseDoubleClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 16);
            this.label6.TabIndex = 36;
            this.label6.Text = "Description";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCQNewsDescription
            // 
            this.txtCQNewsDescription.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCQNewsDescription.Location = new System.Drawing.Point(25, 80);
            this.txtCQNewsDescription.Multiline = true;
            this.txtCQNewsDescription.Name = "txtCQNewsDescription";
            this.txtCQNewsDescription.Size = new System.Drawing.Size(651, 202);
            this.txtCQNewsDescription.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(29, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 16);
            this.label8.TabIndex = 28;
            this.label8.Text = "Title";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCQNewsTitle
            // 
            this.txtCQNewsTitle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCQNewsTitle.Location = new System.Drawing.Point(25, 33);
            this.txtCQNewsTitle.Name = "txtCQNewsTitle";
            this.txtCQNewsTitle.Size = new System.Drawing.Size(536, 22);
            this.txtCQNewsTitle.TabIndex = 29;
            // 
            // frmJobs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1107, 576);
            this.Controls.Add(this.TC);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmJobs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "     ";
            this.Load += new System.EventHandler(this.frmJobs_Load);
            this.tabPlacedStudent.ResumeLayout(false);
            this.splitContainer40.Panel1.ResumeLayout(false);
            this.splitContainer40.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer40)).EndInit();
            this.splitContainer40.ResumeLayout(false);
            this.splitContainer41.Panel1.ResumeLayout(false);
            this.splitContainer41.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer41)).EndInit();
            this.splitContainer41.ResumeLayout(false);
            this.splitContainer42.Panel1.ResumeLayout(false);
            this.splitContainer42.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer42)).EndInit();
            this.splitContainer42.ResumeLayout(false);
            this.tabTrainingProgram.ResumeLayout(false);
            this.splitContainer38.Panel1.ResumeLayout(false);
            this.splitContainer38.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer38)).EndInit();
            this.splitContainer38.ResumeLayout(false);
            this.splitContainer39.Panel1.ResumeLayout(false);
            this.splitContainer39.Panel2.ResumeLayout(false);
            this.splitContainer39.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer39)).EndInit();
            this.splitContainer39.ResumeLayout(false);
            this.tabPlacement.ResumeLayout(false);
            this.splitContainer30.Panel1.ResumeLayout(false);
            this.splitContainer30.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer30)).EndInit();
            this.splitContainer30.ResumeLayout(false);
            this.splitContainer31.Panel1.ResumeLayout(false);
            this.splitContainer31.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer31)).EndInit();
            this.splitContainer31.ResumeLayout(false);
            this.splitContainer32.Panel1.ResumeLayout(false);
            this.splitContainer32.Panel1.PerformLayout();
            this.splitContainer32.Panel2.ResumeLayout(false);
            this.splitContainer32.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer32)).EndInit();
            this.splitContainer32.ResumeLayout(false);
            this.tabJobVaccancys.ResumeLayout(false);
            this.splitContainer15.Panel1.ResumeLayout(false);
            this.splitContainer15.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).EndInit();
            this.splitContainer15.ResumeLayout(false);
            this.splitContainer19.Panel1.ResumeLayout(false);
            this.splitContainer19.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer19)).EndInit();
            this.splitContainer19.ResumeLayout(false);
            this.splitContainer20.Panel1.ResumeLayout(false);
            this.splitContainer20.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer20)).EndInit();
            this.splitContainer20.ResumeLayout(false);
            this.TC.ResumeLayout(false);
            this.tabCQNews.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog mOpenFile;
        private System.Windows.Forms.TabPage tabPlacedStudent;
        private System.Windows.Forms.SplitContainer splitContainer40;
        private System.Windows.Forms.Button btnPlacedStudentMoveDown;
        private System.Windows.Forms.Button btnPlacedStudentMoveUp;
        private System.Windows.Forms.Button btnPlacedStudentShowImage;
        private System.Windows.Forms.Button btnPlacedStudentExit;
        private System.Windows.Forms.Button btnPlacedStudentUploadImage;
        private System.Windows.Forms.Button btnPlacedStudentDelete;
        private System.Windows.Forms.Button btnPlacedStudentAdd;
        private System.Windows.Forms.Button btnPlacedStudentUpdate;
        private System.Windows.Forms.SplitContainer splitContainer41;
        private System.Windows.Forms.TreeView TVPlacedStudent;
        private System.Windows.Forms.SplitContainer splitContainer42;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox txtPlacedStudentExperience;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox txtPlacedStudentDepartment;
        private System.Windows.Forms.TextBox txtPlacedStudentEmail;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtPlacedStudentPlacedCompany;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox txtPlacedStudentQualification;
        private System.Windows.Forms.TextBox txtPlacedStudentContactNumber;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtPlacedStudentDescription;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox txtPlacedStudentName;
        private System.Windows.Forms.TabPage tabTrainingProgram;
        private System.Windows.Forms.SplitContainer splitContainer38;
        private System.Windows.Forms.Button btnTrainingProgramMoveDown;
        private System.Windows.Forms.Button btnTrainingProgramMoveUp;
        private System.Windows.Forms.Button btnTrainingProgramExit;
        private System.Windows.Forms.Button btnTrainingProgramDelete;
        private System.Windows.Forms.Button btnTrainingProgramAdd;
        private System.Windows.Forms.Button btnTrainingProgramUpdate;
        private System.Windows.Forms.SplitContainer splitContainer39;
        private System.Windows.Forms.TreeView TVTrainingProgram;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtTrainingProgramShortDesc;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.MonthCalendar CalTrainingProgram;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtTrainingProgramCity;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtTrainingProgramContactNo;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtTrainingProgramTiming;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtTrainingProgramLocation;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtTrainingProgramDuration;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtTrainingProgramDescription;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtTrainingProgramStartDate;
        private System.Windows.Forms.TextBox txtTrainingProgramTitle;
        private System.Windows.Forms.TabPage tabPlacement;
        private System.Windows.Forms.SplitContainer splitContainer30;
        private System.Windows.Forms.Button btnPlacementShowPdf;
        private System.Windows.Forms.Button btnPlacementShowImage;
        private System.Windows.Forms.Button btnPlacementRefresh;
        private System.Windows.Forms.Button btnPlacementExit;
        private System.Windows.Forms.SplitContainer splitContainer31;
        private System.Windows.Forms.TreeView TVPlacement;
        private System.Windows.Forms.SplitContainer splitContainer32;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.RadioButton rbtPlacementPdf;
        private System.Windows.Forms.TextBox txtPlacementEmail;
        private System.Windows.Forms.TextBox txtPlacementFileName;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.RadioButton rbtPlacementImage;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtPlacementExperience;
        private System.Windows.Forms.TextBox txtPlacementEducation;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtPlacementName;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtPlacementPhoneNo;
        private System.Windows.Forms.TextBox txtPlacementAge;
        private System.Windows.Forms.TabPage tabJobVaccancys;
        private System.Windows.Forms.SplitContainer splitContainer15;
        private System.Windows.Forms.Button btnJobVacDown;
        private System.Windows.Forms.Button btnJobVacUp;
        private System.Windows.Forms.Button btnJobVacShowImage;
        private System.Windows.Forms.Button btnJobVacDefault;
        private System.Windows.Forms.Button btnJobVacULImage;
        private System.Windows.Forms.Button btnJobVacExit;
        private System.Windows.Forms.Button btnJobVacDelete;
        private System.Windows.Forms.Button btnJobVacAdd;
        private System.Windows.Forms.Button btnJobVacUpdate;
        private System.Windows.Forms.SplitContainer splitContainer19;
        private System.Windows.Forms.TreeView TVJobVaccancys;
        private System.Windows.Forms.SplitContainer splitContainer20;
        private System.Windows.Forms.MonthCalendar xCalJobVaccancys;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtJobVacTitle;
        private System.Windows.Forms.TextBox txtJobVacDesc;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtJobVacLinkAdd;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtJobVacDate;
        private System.Windows.Forms.TabControl TC;
        private System.Windows.Forms.Button btnPlacedStudentWrite;
        private System.Windows.Forms.TabPage tabCQNews;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnCQNewsWrite;
        private System.Windows.Forms.Button btnCQNewsMoveDown;
        private System.Windows.Forms.Button btnCQNewsMoveUp;
        private System.Windows.Forms.Button btnCQNewsShowImage;
        private System.Windows.Forms.Button btnCQNewsExit;
        private System.Windows.Forms.Button btnCQNewsUploadImage;
        private System.Windows.Forms.Button btnCQNewsDelete;
        private System.Windows.Forms.Button btnCQNewsAdd;
        private System.Windows.Forms.Button btnCQNewsUpdate;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.TreeView TVCQNews;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.MonthCalendar CalCQNews;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCQNewsDate;      
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCQNewsDescription;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCQNewsTitle;
        private System.Windows.Forms.CheckBox chkJobVacFlag;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtPlacementMessage;
        private System.Windows.Forms.Button btnCQNewsClearGarbage;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
    }
}

