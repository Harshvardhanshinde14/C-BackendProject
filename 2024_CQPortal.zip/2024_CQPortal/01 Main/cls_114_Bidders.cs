﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics.Contracts;

namespace CQPortal
{
    public static class Bidders
    {
        public static List<Bidder> mLst = new List<Bidder>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<Bidder> xLst)
        {
            //xID,xDate,xCompanyID,xBidValue,xPerVariation,xSeqNo
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xDate + "','" + xLst[n].xCompanyID + "','" + xLst[n].xBidValue + "','" + xLst[n].xPerVariation + "'," + xLst[n].xSeqNo + ",'" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)//xSeqNo,xDateTimeStamp
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_Bidder (xID,xDate,xCompanyID,xBidValue,xPerVariation,xSeqNo,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Bidder WHERE xID = '" + xID + "' ") == false) return;
                Bidder xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<Bidder> { xT });
            }
            catch { }
        }
        public static void UpLoadList(SqlConnection DBConn, List<Bidder> xLst)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Bidder") == false) return;
                mLst = xLst;
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static List<Bidder> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<Bidder> xRetLst = new List<Bidder>();
                while (oReader.Read())
                {
                    //xID,xDate,xCompanyID,xBidValue,xPerVariation,xSeqNo
                    Bidder xT = new Bidder();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xDate = oReader["xDate"].ToString().Trim();
                    xT.xCompanyID = oReader["xCompanyID"].ToString().Trim();
                    xT.xBidValue = oReader["xBidValue"].ToString().Trim();
                    xT.xPerVariation = oReader["xPerVariation"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<Bidder>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<Bidder>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_Bidder";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Bidder WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID.Substring(0, 9));
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID12(string xID9)
        {
            try
            {
                List<Bidder> xLst = mLst.FindAll(p => p.xID.Length == 12 && p.xID.Substring(0, 9) == xID9).OrderByDescending(p => Convert.ToInt64(p.xID)).ToList(); ;
                if (xLst.Count == 0) return xID9 + "101";
                return Convert.ToString((Convert.ToInt64(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo12(string xID9)
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<Bidder> xLst = mLst.FindAll(p => p.xID.Length == 12 && p.xID.Substring(0, 9) == xID9).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static Bidder xGetByID(string xID)
        {
            try
            {
                Bidder xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new Bidder();
                return xT;
            }
            catch { return new Bidder(); }
        }
        #endregion

        #region Add Update
        public static void xAdd(SqlConnection DBConn, TreeView TV, string xCompanyID, string xDate, TextBox txtBidValue, TextBox txtPerVariation)
        {
            try
            {
                //xTenderID,xID,xDate,xCompanyID,xBidValue,xPerVariation,xSeqNo
                if (TV.SelectedNode == null || TV.SelectedNode.Level < 2) return;
                string xTenderID = TV.SelectedNode.Name;
                if (TV.SelectedNode.Level == 3) xTenderID = TV.SelectedNode.Parent.Name;
                Bidder xxT = mLst.Find(p => p.xID.Substring(0, 9) == xTenderID && p.xCompanyID == xCompanyID);
                if (xxT != null)
                { MessageBox.Show("Company is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                Bidder xT = new Bidder();
                xT.xID = xGetNewID12(xTenderID);
                xT.xDate = xDate;
                xT.xSeqNo = xGetNewSeqNo12(xTenderID);
                xT.xCompanyID = xCompanyID;
                xT.xBidValue = txtBidValue.Text.Trim();
                xT.xPerVariation = txtPerVariation.Text.Trim();
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xT.xID);
            }
            catch { }
        }
        public static void xUpdate(SqlConnection DBConn, string xID, TreeView TV, string xCompanyID, string xDate, TextBox txtBidValue, TextBox txtPerVariation)
        {
            try
            {
                Bidder xT = xGetByID(xID);
                List<Bidder> xLst = mLst.FindAll(p => p.xID.Substring(0, 9) == xT.xID.Substring(0, 9) && p.xID != xT.xID);
                if (xLst.Exists(p => p.xCompanyID == xCompanyID) == true)
                { MessageBox.Show("Company is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                if (xT == null) { return; }
                xT.xDate = xDate;
                xT.xCompanyID = xCompanyID;
                xT.xBidValue = txtBidValue.Text.Trim();
                xT.xPerVariation = txtPerVariation.Text.Trim();
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xT.xID);
            }
            catch { }
        }
        public static void xAddDefault(SqlConnection DBConn)
        {
            try
            {
                List<Bidder> xLst = new List<Bidder>();
                xLst.Add(new Bidder("101101101101", "20240424", "101101", "13,500 crore", "10", 1));
                xLst.Add(new Bidder("101101101102", "20240422", "101102", "11,500 crore", "20", 2));
                xLst.Add(new Bidder("101101102101", "20240423", "101103", "900,00crore", "9", 1));
                xLst.Add(new Bidder("101101102102", "20240424", "102101", "09,000 crore", "15", 2));
                xLst.Add(new Bidder("101101102103", "20240424", "102102", "09,500 crore", "11", 3));
                UpLoadList(DBConn, xLst);
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<Tender> xLstTender = Tenders.xGetList();
                List<Tender> xLst3 = xLstTender.FindAll(p => p.xID.Length == 3).OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst3.Count; i++)
                {
                    TreeNode xNode3 = TV.Nodes.Add(xLst3[i].xID, xLst3[i].xPrjNameName);
                    List<Tender> xLst6 = xLstTender.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xLst3[i].xID).OrderBy(p => p.xSeqNo).ToList();
                    for (int j = 0; j < xLst6.Count; j++)
                    {
                        TreeNode xNode6 = xNode3.Nodes.Add(xLst6[j].xID, xLst6[j].xPrjNameName);
                        List<Tender> xLst9 = xLstTender.FindAll(p => p.xID.Length == 9 && p.xID.Substring(0, 6) == xLst6[j].xID).OrderBy(p => p.xSeqNo).ToList();
                        for (int k = 0; k < xLst9.Count; k++)
                        {
                            TreeNode xNode9 = xNode6.Nodes.Add(xLst9[k].xID, xLst9[k].xPrjNameName);
                            List<Bidder> xLstBidder = mLst.FindAll(p => p.xID.Substring(0, 9) == xLst9[k].xID);
                            for (int n = 0; n < xLstBidder.Count; n++)
                            {
                                xNode9.Nodes.Add(xLstBidder[n].xID, Companys.xGetNameByID(xLstBidder[n].xCompanyID));
                            }
                        }
                    }
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopInRev(string xID, TreeView TVCompany, TextBox txtDate, TextBox txtBidValue, TextBox txtPerVariation)
        {
            try
            {
                Bidder xT = xGetByID(xID);
                txtDate.Text = Functions.DBToDotDate(xT.xDate);
                txtBidValue.Text = xT.xBidValue;
                txtPerVariation.Text = xT.xPerVariation;
                TVCompany.SelectedNode = TVCompany.Nodes[xT.xCompanyID.Substring(0, 3)].Nodes[xT.xCompanyID];
            }
            catch { }
        }
        #endregion
    }
}
