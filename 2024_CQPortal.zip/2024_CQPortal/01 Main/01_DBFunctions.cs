﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPortal
{
    using System;
    using System.Windows.Forms;
    using System.Data.SqlClient;
    using System.Data;

    public class DBFunctions
    {
        public static bool ExeNonQuery(SqlConnection DBConn, string xSQL, bool xShowError = false)
        {
            try
            {
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                xCmd.ExecuteNonQuery();
                xCmd.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + xSQL);
                return false;
            }
        }
    }
    public class CQSQL
    {
        public static bool ExeNonQuery(SqlConnection DBConn, string xSQL, bool xShowError = false)
        {
            try
            {
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                xCmd.ExecuteNonQuery();
                xCmd.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + xSQL);
                return false;
            }
        }
    }
}


