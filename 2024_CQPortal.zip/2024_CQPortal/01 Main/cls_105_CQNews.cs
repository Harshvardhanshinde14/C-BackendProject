﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using System.Net.Http;
using System.Security.Policy;


namespace CQPortal
{
    public static class CQNewss
    {
        public static List<CQNews> mLst = new List<CQNews>();
      
        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<CQNews> xLst)
        {
            // xID,xTitle,xDate,xDesc,xDateTimeStamp,xSeqNo
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xTitle + "','" + xLst[n].xDate + "','" + xLst[n].xDesc + "','" + xLst[n].xSeqNo + "','"+xDateTimeStamp+"')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_CQNews (xID,xTitle,xDate,xDesc,xSeqNo,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_CQNews");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_CQNews WHERE xID = '" + xID + "' ") == false) return;
                CQNews xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<CQNews> { xT });
            }
            catch { }
        }
        public static List<CQNews> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<CQNews> xRetLst = new List<CQNews>();
                while (oReader.Read())
                {
                    //xID,xTitle,xDesc,xDateTimeStamp,xSeqNo
                    CQNews xT = new CQNews();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xTitle = oReader["xTitle"].ToString().Trim();
                    xT.xDate = oReader["xDate"].ToString().Trim();
                    xT.xDesc = oReader["xDesc"].ToString().Trim();
                    xT.xSeqNo = Convert.ToInt32(oReader["xSeqNo"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<CQNews>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<CQNews>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_CQNews";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void xDelete(SqlConnection DBConn, TreeView TV, string xID)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM CQ_Portal_CQNews WHERE xID ='" + xID + "' ");
                mLst.RemoveAll(p => p.xID == xID);
                xPopTV(TV);
            }
            catch { }
        }
        #endregion

        #region Get
        private static string xGetNewID()
        {
            try
            {
                List<CQNews> xLst = mLst.FindAll(p => p.xID.Length == 6).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<CQNews> xLst = mLst.OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static CQNews xGetByID(string xID)
        {
            try
            {
                CQNews xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new CQNews();
                return xT;
            }
            catch { return new CQNews(); }
        }
        public static List<CQNews> xGetListAll()
        {
            try
            {
               return mLst.ToList();
            }
            catch { return new List<CQNews>(); }
        }
        #endregion

        #region Add Update
        public static void xAdd(SqlConnection DBConn, TreeView TV, TextBox txtTitle, string xDate, TextBox txtDesc)
        {
            try
            {                      //xID,xTitle,xDesc,xDateTimeStamp,xSeqNo
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                CQNews xxT = mLst.Find(p => p.xTitle.ToLower() == txtTitle.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Name is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

                CQNews xT = new CQNews();
                xT.xID = xGetNewID();
                xT.xTitle = txtTitle.Text.Trim();
                xT.xDate = xDate;
                xT.xDesc = txtDesc.Text.Trim();
                xT.xSeqNo = xGetNewSeqNo();

                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }

        public static void xUpdate(SqlConnection DBConn, TreeView TV, string xID, TextBox txtTitle, string xDate, TextBox txtDesc)
        {
            try
            {
                if (txtTitle.Text.Trim() == "" || txtTitle.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                CQNews xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xTitle = txtTitle.Text.Trim();
                xT.xDate = xDate;
                xT.xDesc = txtDesc.Text.Trim();
                //xT.xSeqNo = xGetNewSeqNo();
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<CQNews> xLst = mLst.OrderBy(p => p.xSeqNo).ToList();
                for (int i = 0; i < xLst.Count; i++)
                {
                   TreeNode xNode6= TV.Nodes.Add(xLst[i].xID, xLst[i].xTitle);
                    NewsPhotoNames.xPopTVNode(xNode6);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }

        public static void xPopInRev(string xID, TextBox txtTitle, TextBox txtDate, TextBox txtDesc)
        {
            try
            {
                CQNews xT = xGetByID(xID);
                txtTitle.Text = xT.xTitle;
                txtDate.Text = xT.xDate;
                txtDesc.Text = xT.xDesc;
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown(SqlConnection DBConn, TreeView TV, bool MoveUp)
        {
            try
            {
                if (TV.SelectedNode == null) return;
                string xID = TV.SelectedNode.Name;
                List<CQNews> xLst = new List<CQNews>();
                xLst = mLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xID];
            }
            catch { }
        }
        #endregion


        #region writeFile
        public static bool xNewsTbWriteTableToFile(SqlConnection DBConn)
        {
            try
            {
                // Construct the file name with a timestamp
                string xFileName = CQBVar.xPath + "\\" + "101_NewsTbFromTable_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";

                // SQL query to join the two tables and retrieve necessary columns
                string xSQL = @"
        SELECT 
            news.xID, 
            news.xTitle, 
            news.xDate, 
            news.xDesc, 
            news.xSeqNo, 
            STRING_AGG(photo.xPhotoFileName, ', ') AS xPhotoFileNames
        FROM 
            dbo.CQ_Portal_CQNews news
        LEFT JOIN 
            dbo.CQ_Portal_NewsPhotoName photo
        ON 
            news.xID = photo.xNewsID
        GROUP BY 
            news.xID, 
            news.xTitle, 
            news.xDate, 
            news.xDesc, 
            news.xSeqNo";

                // Initialize SQL command
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;

                // Initialize StringBuilder for constructing CSV file content
                StringBuilder SB = new StringBuilder();
                // Adding the CSV header
                string xLine = "xID,xTitle,xDate,xDesc,xSeqNo,xPhotoFileNames";
                SB.AppendLine(xLine);

                // Execute the query and read the results
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        // Combine the values into a single line for each row
                        xLine = oReader["xID"].ToString().Trim() + ","
                              + oReader["xTitle"].ToString().Trim() + ","
                              + oReader["xDate"].ToString().Trim() + ","
                              + oReader["xDesc"].ToString().Trim() + ","
                              + oReader["xSeqNo"].ToString().Trim() + ","
                              + oReader["xPhotoFileNames"].ToString().Trim();
                        SB.AppendLine(xLine);
                    }
                }

                // Write the content to the CSV file
                StreamWriter xWriter = new StreamWriter(xFileName);
                xWriter.Write(SB.ToString());
                xWriter.Close();

                // Open the file after writing (optional)
                System.Diagnostics.Process.Start(xFileName);

                return true;
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion


    }
}
