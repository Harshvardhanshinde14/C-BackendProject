﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Globalization;
using static System.Windows.Forms.AxHost;


namespace CQPortal
{
    public static class Professionalss
    {

        public static List<Professionals> mLst = new List<Professionals>();

        #region ULDL
        public static void ActualDBUpLoad(SqlConnection DBConn, List<Professionals> xLst)
        {
            //xID,xName,xPhotoName,xDescription,xCompanyId,xDesignation
            try
            {
                string xDateTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                int n = 0;
                int i = 0;
                do
                {
                    bool xRowAdded = false;
                    StringBuilder SB = new StringBuilder();
                    for (int j = 0; j < 1000; j++)
                    {
                        n = i * 1000 + j;
                        if (n < xLst.Count)
                        {
                            SB.Append(",('" + xLst[n].xID + "','" + xLst[n].xName + "','" + xLst[n].xPhotoName + "','" + xLst[n].xDescription + "','" + xLst[n].xCompanyId + "','" + xLst[n].xDescription + "'," + xLst[n].xSeqNo + ",'" + xDateTimeStamp + "')");
                            xRowAdded = true;
                        }
                    }
                    i++;
                    if (xRowAdded == true)
                    {
                        string xSQL = @"INSERT INTO dbo.CQ_Portal_Professionals (xID,xName,xPhotoName,xDescription,xCompanyId,xDesignation,xSeqNo,xDateTimeStamp) VALUES"
                               + SB.ToString().Substring(1);
                        CQSQL.ExeNonQuery(DBConn, xSQL);
                    }
                } while (n < xLst.Count);
            }
            catch { }
        }
        public static void UpLoad(SqlConnection DBConn)
        {
            try
            {
                CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Professionals");
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void UpLoadSingle(SqlConnection DBConn, string xID)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Professionals WHERE xID = '" + xID + "' ") == false) return;
                Professionals xT = mLst.Find(p => p.xID == xID);
                ActualDBUpLoad(DBConn, new List<Professionals> { xT });
            }
            catch { }
        }
        public static List<Professionals> ActualDBDownLoad(SqlDataReader oReader)
        {
            try
            {
                List<Professionals> xRetLst = new List<Professionals>();
                while (oReader.Read())
                {
                    //xID,xName,xPhotoName,xDescription,xCompanyId,xDesignation
                    Professionals xT = new Professionals();
                    xT.xID = oReader["xID"].ToString().Trim();
                    xT.xName = oReader["xName"].ToString().Trim();
                    xT.xPhotoName = oReader["xPhotoName"].ToString().Trim();
                    xT.xDescription = oReader["xDescription"].ToString().Trim();
                    xT.xCompanyId = oReader["xCompanyId"].ToString().Trim();
                    xT.xDesignation = oReader["xDesignation"].ToString().Trim();
                    xT.xSeqNo =Convert.ToInt32( oReader["xSeqNo"].ToString().Trim());
                    xRetLst.Add(xT);
                }
                return xRetLst;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return new List<Professionals>(); }
        }
        public static void DownLoad(SqlConnection DBConn)
        {
            try
            {
                mLst = new List<Professionals>();
                string xSQL = @"SELECT * FROM dbo.CQ_Portal_Professionals";
                SqlCommand xCmd = new SqlCommand(xSQL, DBConn);
                xCmd.CommandType = CommandType.Text;
                using (SqlDataReader oReader = xCmd.ExecuteReader())
                {
                    mLst = ActualDBDownLoad(oReader);
                }
            }
            catch
            {
            }
        }
        public static void UpLoadList(SqlConnection DBConn, List<Professionals> xLst)
        {
            try
            {
                if (CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Professionals") == false) return;
                mLst = xLst;
                ActualDBUpLoad(DBConn, mLst);
            }
            catch { }
        }
        public static void xUpdateReviewerPhoto(SqlConnection DBConn, string xID, string xPhotoName)
        {
            try
            {
                Professionals xT = xGetByID(xID);
                if (CQSQL.ExeNonQuery(DBConn, "UPDATE dbo.CQ_Portal_Professionals SET xPhotoName = '" + xPhotoName + "' WHERE xID = '" + xID + "' ") == true)
                {
                    xT.xPhotoName = xPhotoName;
                }

            }
            catch { }
        }
        public static void xDelete(SqlConnection DBConn, string xID,TreeView TV)
        {
            try
            {
                if (MessageBox.Show("Are You Sure ? Do You Want To Delete?", "CalQuan", MessageBoxButtons.YesNo) == DialogResult.No) return;
                if (xID.Length == 3)
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Professionals WHERE LEFT(xID,3) ='" + xID + "' ");
                    mLst.RemoveAll(p => p.xID.Substring(0, 3) == xID);
                    xPopTV(TV);
                }
                else
                {
                    CQSQL.ExeNonQuery(DBConn, "DELETE FROM dbo.CQ_Portal_Professionals WHERE xID ='" + xID + "' ");
                    mLst.RemoveAll(p => p.xID == xID);
                    xPopTV(TV);
                    TV.SelectedNode = TV.Nodes[xID.Substring(0, 3)];
                    TV.SelectedNode.ExpandAll();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion

        #region Get
        public static List<Professionals> xGetList()
        {
            try
            {
                return mLst.ToList();
            }
            catch { return new List<Professionals>(); }
        }
        private static string xGetNewID3()
        {
            try
            {
                List<Professionals> xLst = mLst.FindAll(p => p.xID.Length == 3).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static string xGetNewID6(string xID)
        {
            try
            {
                List<Professionals> xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID).OrderByDescending(p => Convert.ToInt32(p.xID)).ToList(); ;
                if (xLst.Count == 0) return xID + "101";
                return Convert.ToString((Convert.ToInt32(xLst[0].xID) + 1));
            }
            catch { return ""; }
        }
        private static Int32 xGetNewSeqNo3()
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<Professionals> xLst = mLst.FindAll(p => p.xID.Length == 3).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        private static Int32 xGetNewSeqNo6(string xID3)
        {
            try
            {
                Int32 xxSeqNo;
                if (mLst.Count == 0) return 1;
                List<Professionals> xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID3).OrderByDescending(p => p.xSeqNo).ToList(); ;
                if (xLst.Count == 0) return 1;
                xxSeqNo = xLst[0].xSeqNo + 1;
                return xxSeqNo;
            }
            catch { return -1; }
        }
        public static Professionals xGetByID(string xID)
        {
            try
            {
                Professionals xT = mLst.Find(p => p.xID == xID);
                if (xT == null) return new Professionals();
                return xT;
            }
            catch { return new Professionals(); }
        }
        #endregion

        #region Add Update
        public static void xAdd3(SqlConnection DBConn, TreeView TV, TextBox txtName, TextBox txtDesc)
        {
            try
            { 
                //xID,xName,xPhotoName,xDescription,xCompanyId,xDesignation
                if (txtName.Text.Trim() == "" || txtName.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                Professionals xxT = mLst.Find(p => p.xName.ToLower() == txtName.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Name is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

                Professionals xT = new Professionals();
                xT.xID = xGetNewID3();
                xT.xSeqNo = xGetNewSeqNo3();
                xT.xName = txtName.Text.Trim();
                xT.xPhotoName = "-";
                xT.xDescription = txtDesc.Text.Trim();
                xT.xCompanyId = "-";
                xT.xDesignation = "-";
                mLst.Add(xT);
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID];
            }
            catch { }
        }
        public static void xAdd6(SqlConnection DBConn, TreeView TV,TextBox txtName, TextBox txtDesc,string xCompanyID,TextBox txtDesignation)
        {
            try
            { //xID,xName,xPhotoName,xDescription,xCompanyId,xDesignation
                if (TV.SelectedNode == null) return;
                string xID3 = "";
                if (TV.SelectedNode.Level == 0) xID3 = TV.SelectedNode.Name;
                else
                {
                    xID3 = TV.SelectedNode.Parent.Name;
                }
                if (txtName.Text.Trim() == ""|| txtName.Text.Trim()==null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }
                Professionals xxT = mLst.Find(p => p.xName.ToLower() == txtName.Text.Trim().ToLower());
                if (xxT != null)
                { MessageBox.Show("Name is already exists", CQBVar.Portal.Prj.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error); return ; }
               
                Professionals xT = new Professionals();
                xT.xID = xGetNewID6(xID3);
                xT.xSeqNo = xGetNewSeqNo6(xID3);
                xT.xName = txtName.Text.Trim();
                xT.xPhotoName = "-";
                xT.xDescription = txtDesc.Text.Trim();
                xT.xCompanyId = xCompanyID;
                xT.xDesignation=txtDesignation.Text.Trim();
                mLst.Add(xT);
                UpLoadSingle(DBConn,xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xUpdate6(SqlConnection DBConn,string xID, TreeView TV, TextBox txtName, TextBox txtDesc, string xCompanyID, TextBox txtDesignation)
        {
            try
            {
                if (txtName.Text.Trim() == "" || txtName.Text.Trim() == null)
                {
                    MessageBox.Show("Invalid Name");
                    return;
                }

                Professionals xT = xGetByID(xID);
                if (xT == null) { return; }
                xT.xName = txtName.Text.Trim();
                xT.xDescription = txtDesc.Text.Trim();
                xT.xCompanyId = xCompanyID;
                xT.xDesignation = txtDesignation.Text.Trim();
                UpLoadSingle(DBConn, xT.xID);
                xPopTV(TV);
                TV.SelectedNode = TV.Nodes[xT.xID.Substring(0, 3)].Nodes[xT.xID];
            }
            catch { }
        }
        public static void xAddDefault(SqlConnection DBConn)
        {
            try
            {
                List<Professionals> xLstRet = new List<Professionals>();
                xLstRet.Add(new Professionals("101", "Grp1", "", "", "-", "",1));
                xLstRet.Add(new Professionals("101101", "Mr.RohitJain","","", "101101","",1));
                xLstRet.Add(new Professionals("101102", "Mr.Raj", "HCC",  "", "102102", "",2));
                xLstRet.Add(new Professionals("102", "Grp2", "", "", "-", "", 2));
                xLstRet.Add(new Professionals("102101", "Mr.Tanmay", "Ashoka","", "102102", "", 1)); 
                xLstRet.Add(new Professionals("102102", "Mr.Pradeep", "MCL", "", "102101", "",2 ));
                UpLoadList(DBConn, xLstRet);
            }
            catch { }
        }
        #endregion

        #region Pop
        public static void xPopTV(TreeView TV)
        {
            try
            {
                TV.BeginUpdate();
                TV.Nodes.Clear();
                List<Professionals> xLst3 = mLst.FindAll(p => p.xID.Length == 3).OrderBy(p => p.xSeqNo).ToList(); ;
                for (int i = 0; i < xLst3.Count; i++)
                {
                    TreeNode xNode3 = TV.Nodes.Add(xLst3[i].xID, xLst3[i].xName);
                    xPopTVNodes(xNode3);
                }
            }
            catch { }
            finally { TV.EndUpdate(); }
        }
        public static void xPopTVNodes(TreeNode xNode)
        {
            try
            {
                xNode.Nodes.Clear();
                List<Professionals> xLst6 = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xNode.Name).OrderBy(p => p.xSeqNo).ToList();

                for (int j = 0; j < xLst6.Count; j++)
                {
                    xNode.Nodes.Add(xLst6[j].xID, xLst6[j].xName);
                }
            }
            catch { }
        }
        public static void xPopInRev(string xID, TextBox txtName, TextBox txtDesc, TreeView TVCompany, TextBox txtDesignation)
        {
            try
            {
                Professionals xT = xGetByID(xID);
                txtName.Text = xT.xName;
                txtDesc.Text = xT.xDescription;
                TVCompany.SelectedNode = TVCompany.Nodes[xT.xCompanyId.Substring(0,3)].Nodes[xT.xCompanyId];
                txtDesignation.Text = xT.xDesignation;
            }
            catch { }
        }
        #endregion

        #region MoveupDown
        public static void UpOrDown3(SqlConnection DBConn, TreeView TV, bool MoveUp)
        {
            try
            {
                if (TV.SelectedNode == null || TV.SelectedNode.Level != 0) return;
                string xID3 = TV.SelectedNode.Name;
                List<Professionals> xLst = mLst.FindAll(p => p.xID.Length == 3);
                if (xID3.Length != 3) return;
              
                if (xLst.Count < 2) return;
                xLst = xLst.OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();

                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID3) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID3)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID3);
            }
            catch { }
        }
        public static void UpOrDown6(SqlConnection DBConn, TreeView TV, bool MoveUp) //xSeqNo
        {
            try
            {
                if (TV.SelectedNode == null) return;
                if (TV.SelectedNode.Level != 1) return;
                string xID = TV.SelectedNode.Name;
                List<Professionals> xLst = new List<Professionals>();
                if (xID.Length != 6) return;
                xLst = mLst.FindAll(p => p.xID.Length == 6 && p.xID.Substring(0, 3) == xID.Substring(0, 3)).OrderBy(p => Convert.ToInt32(p.xSeqNo)).ToList();
                if (xLst.Count < 2) return;
                if (xLst.Count() != xLst.Select(p => p.xSeqNo).Distinct().Count())
                {
                    for (int i = 0; i < xLst.Count; i++) xLst[i].xSeqNo = i;
                }
                if (MoveUp == false) xLst.Reverse();
                if (xLst[0].xID == xID) return;
                for (int i = 1; i < xLst.Count; i++)
                {
                    if (xLst[i].xID == xID)
                    {
                        Int32 xTemp = xLst[i].xSeqNo;
                        xLst[i].xSeqNo = xLst[i - 1].xSeqNo;
                        xLst[i - 1].xSeqNo = xTemp;
                    }
                }
                UpLoad(DBConn);
                xPopTV(TV);
                Functions.xSelectTVNode(TV, xID);
            }
            catch { }
        }
        #endregion

    }
}
