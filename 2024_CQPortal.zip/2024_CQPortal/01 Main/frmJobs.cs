﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.AxHost;

namespace CQPortal
{

    public partial class frmJobs : Form
    {
        public DateTime mDate = DateTime.Now;
        public DateTime mShowDate = DateTime.Now;
        string mCaller = "1";

        #region Form
        public frmJobs()
        {
            InitializeComponent();
        }
        private void frmJobs_Load(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.UseWaitCursor = true;
            try
            {
                DBConn.Open();
                Download(DBConn);
                JobVaccancys.xPopTV(TVJobVaccancys);
                txtJobVacDate.Text = mDate.ToString("dd.MM.yyyy");
                this.Text = "CQ_Portal_" + CQBVar.Version;
                btnPlacementShowImage.Enabled = false;
                btnPlacementShowPdf.Enabled = false;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { this.UseWaitCursor = false; DBConn.Close(); }
        }
        private void Download(SqlConnection DBConn)
        {
            try
            {
                Companys.DownLoad(DBConn);
                JobVaccancys.DownLoad(DBConn);
                Placements.DownLoad(DBConn);
                PlacedStudents.DownLoad(DBConn);
                TrainingPrograms.DownLoad(DBConn);
                CQNewss.DownLoad(DBConn);
                NewsPhotoNames.DownLoad(DBConn);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            finally { }
        }
        #endregion

        #region Other
        private void TV_DrawNode(object sender, DrawTreeNodeEventArgs e)
        {
            try
            {
                Functions.TVDrawNode(sender, e);
            }
            catch { }
        }
        private void TC_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection dbCQPrjConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TC.SelectedTab == tabJobVaccancys)
                {
                    JobVaccancys.xPopTV(TVJobVaccancys);
                }
                else if (TC.SelectedTab == tabPlacement)
                {
                    dbCQPrjConn.Open();
                    Placements.xPopTV(dbCQPrjConn, TVPlacement);
                    dbCQPrjConn.Close();
                }
                else if (TC.SelectedTab == tabTrainingProgram)
                {
                    TrainingPrograms.xPopTV(TVTrainingProgram);
                }
                else if (TC.SelectedTab == tabPlacedStudent)
                {
                    PlacedStudents.xPopTV(TVPlacedStudent);
                }
                else if (TC.SelectedTab == tabCQNews)
                {
                    CQNewss.xPopTV(TVCQNews);
                }
            }
            catch { }
            finally { }
        }
        #endregion

        #region jobvaccancy
        private void txtJobVacDate_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                mDate = xCalJobVaccancys.SelectionStart;
                xCalJobVaccancys.Visible = true;
                mCaller = "1";
            }
            catch { }
        }
        private void xCalJobVaccancys_DateSelected(object sender, DateRangeEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                xCalJobVaccancys.Visible = false;
                mDate = xCalJobVaccancys.SelectionStart;

                string xDate = "";
                if (mCaller == "1")
                {
                    mDate = xCalJobVaccancys.SelectionStart;
                    txtJobVacDate.Text = mDate.ToString("dd.MM.yyyy");
                    xDate = mDate.ToString("yyyyMMdd");
                }

            }
            catch { }
            finally
            {
                this.Cursor = Cursors.Default; DBConn.Close();
            }
        }
        private void btnJobVacAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level == 0) return;
                JobVaccancys.xAdd6(DBConn, TVJobVaccancys, mDate.ToString("yyyyMMdd"), txtJobVacTitle, txtJobVacDesc, txtJobVacLinkAdd, chkJobVacFlag);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnJobVacUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level != 2) return;
                string xID = TVJobVaccancys.SelectedNode.Name;
                JobVaccancys.xUpdate6(DBConn, TVJobVaccancys, xID, mDate.ToString("yyyyMMdd"), txtJobVacTitle, txtJobVacDesc, txtJobVacLinkAdd, chkJobVacFlag);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnJobVacDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level != 2) return;
                string xID = TVJobVaccancys.SelectedNode.Name;
                JobVaccancys.xDelete(DBConn, TVJobVaccancys, xID);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        async private void btnJobVacULImage_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level != 2) return;
                string xID = TVJobVaccancys.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoadImageWithNAme("JobVaccancyPhoto", xID, xFileName);

            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnJobVacShowImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level != 2) return;

                string xImage = TVJobVaccancys.SelectedNode.Name;
                if (xImage.ToLower().EndsWith(".JPEG")) xImage = xImage.Substring(0, xImage.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/JobVaccancyPhoto/" + xImage;
                UpDLLoadImage.DownloadImage(xImage, MyURL);

            }
            catch
            {

            }
        }
        private void btnJobVacUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level != 2) return;
                DBCQConn.Open();

                JobVaccancys.UpOrDown9(DBCQConn, TVJobVaccancys, true);
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnJobVacDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level != 2) return;
                DBCQConn.Open();

                JobVaccancys.UpOrDown9(DBCQConn, TVJobVaccancys, false);
            }
            catch { }
            finally
            {
                DBCQConn.Close();
                this.Cursor = Cursors.Default;
            }
        }
        private void btnJobVacDefault_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string xIn1 = "Data Will Be moved , Do You Wish To move";
                string xIn2 = "";
                frmSel_Confirmation frm = new frmSel_Confirmation(xIn1, out xIn2);
                frm.ShowDialog();
                frm.Dispose();
                if (xIn2 != CQBVar.Portal.Sel.Confirmation)
                {
                    MessageBox.Show("InValid Key.");
                    return;
                }
                DBConn.Open();
                JobVaccancys.xAddDefault(DBConn);
                JobVaccancys.xPopTV(TVJobVaccancys);
            }
            catch { }
            finally { DBConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void btnJobVacExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        private void TVJobVaccancys_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBConn.Open();
                if (TVJobVaccancys.SelectedNode == null || TVJobVaccancys.SelectedNode.Level != 2) return;
                string xID = TVJobVaccancys.SelectedNode.Name;
                JobVaccancys.xPopInRev(xID, txtJobVacDate, txtJobVacTitle, txtJobVacDesc, txtJobVacLinkAdd, chkJobVacFlag);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        #endregion

        #region Placement
        async private void btnPlacementRefresh_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                DBConn.Open();
                Placements.xPopTV(DBConn, TVPlacement);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void TVPlacement_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                string xID = TVPlacement.SelectedNode.Name;
                Placements.xPopInRev(xID, txtPlacementName, txtPlacementEmail, txtPlacementPhoneNo, txtPlacementAge, txtPlacementEducation, txtPlacementExperience, txtPlacementMessage, rbtPlacementImage, rbtPlacementPdf, txtPlacementFileName,btnPlacementShowImage,btnPlacementShowPdf);
            }
            catch { }
        }
        private void btnPlacementShowImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVPlacement.SelectedNode == null) return;
                string xID = TVPlacement.SelectedNode.Name;
                Placement xT = Placements.xGetByID(xID);
                if (xT == null || xT.xCVPdfORImage != "1") return;
                string xImage = xT.xFileName;
                if (xImage.ToLower().EndsWith(".JPEG")) xImage = xImage.Substring(0, xImage.Length - 5);
                string MyURL = CQBVar.MyURL + @"/api/Image/DownLoadCVImage/" + xImage;
                UpDLLoadImage.DownloadImage(xImage, MyURL);
            }
            catch
            {

            }

        }
        private void btnPlacementShowPdf_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVPlacement.SelectedNode == null) return;
                string xID = TVPlacement.SelectedNode.Name;
                Placement xT = Placements.xGetByID(xID);
                if (xT == null || xT.xCVPdfORImage != "0") return;
                string xFileName = xT.xFileName;
                UpDLLoadImage.DownloadPdf(xFileName);
            }
            catch { }
        }
        private void btnPlacementExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch { }
        }
        #endregion

        #region training program
        private void btnTrainingProgramExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {
            }
        }
        private void btnTrainingProgramAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                string errorMessage;
                bool isValid = TrainingPrograms.xValidate(DBConn, TVTrainingProgram, txtTrainingProgramTitle, txtTrainingProgramShortDesc, mDate.ToString("yyyyMMdd"), txtTrainingProgramDescription, txtTrainingProgramDuration, txtTrainingProgramLocation, txtTrainingProgramTiming, txtTrainingProgramContactNo, txtTrainingProgramCity, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                DBConn.Open();
                TrainingPrograms.xAdd(DBConn, TVTrainingProgram, txtTrainingProgramTitle, txtTrainingProgramShortDesc, mDate.ToString("yyyyMMdd"), txtTrainingProgramDescription, txtTrainingProgramDuration, txtTrainingProgramLocation, txtTrainingProgramTiming, txtTrainingProgramContactNo, txtTrainingProgramCity);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBConn.Close();
                UseWaitCursor = false;
            }
        }
        private void txtTrainingProgramStartDate_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                mDate = CalTrainingProgram.SelectionStart;
                CalTrainingProgram.Visible = true;
                mCaller = "1";
            }
            catch { }
        }
        private void CalTrainingProgram_DateSelected(object sender, DateRangeEventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                CalTrainingProgram.Visible = false;
                mDate = CalTrainingProgram.SelectionStart;

                string xStartDate = "";
                if (mCaller == "1")
                {
                    mDate = CalTrainingProgram.SelectionStart;
                    txtTrainingProgramStartDate.Text = mDate.ToString("dd.MM.yyyy");
                    xStartDate = mDate.ToString("yyyyMMdd");
                }
            }
            catch { }
            finally { this.Cursor = Cursors.Default; }
        }
        private void btnTrainingProgramUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVTrainingProgram.SelectedNode == null)
                {
                    MessageBox.Show("Please select  title");
                    return;
                }
                string xID = TVTrainingProgram.SelectedNode.Name;
                DBConn.Open();
                TrainingPrograms.xUpdate(DBConn, TVTrainingProgram, xID, txtTrainingProgramTitle, txtTrainingProgramShortDesc, mDate.ToString("yyyyMMdd"), txtTrainingProgramDescription, txtTrainingProgramDuration, txtTrainingProgramLocation, txtTrainingProgramTiming, txtTrainingProgramContactNo, txtTrainingProgramCity);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnTrainingProgramDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVTrainingProgram.SelectedNode == null)
                {
                    MessageBox.Show("Please select Date");
                    return;
                }
                string xID = TVTrainingProgram.SelectedNode.Name;
                DBConn.Open();
                TrainingPrograms.xDelete(DBConn, TVTrainingProgram, xID);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnTrainingProgramMoveUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                TrainingPrograms.UpOrDown(DBConn, TVTrainingProgram, true);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnTrainingProgramMoveDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                TrainingPrograms.UpOrDown(DBConn, TVTrainingProgram, false);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void TVTrainingProgram_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVTrainingProgram.SelectedNode == null) return;
                string xID = TVTrainingProgram.SelectedNode.Name;
                TrainingPrograms.xPopInRev(xID, txtTrainingProgramTitle, txtTrainingProgramShortDesc, txtTrainingProgramStartDate, txtTrainingProgramDescription, txtTrainingProgramDuration, txtTrainingProgramLocation, txtTrainingProgramTiming, txtTrainingProgramContactNo, txtTrainingProgramCity);
            }
            catch { }
        }
        #endregion

        #region placed student
        private void TVPlacedStudent_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVPlacedStudent.SelectedNode == null) return;
                string xID = TVPlacedStudent.SelectedNode.Name;
                PlacedStudents.xPopInRev(xID, txtPlacedStudentName, txtPlacedStudentEmail, txtPlacedStudentDepartment, txtPlacedStudentExperience, txtPlacedStudentQualification, txtPlacedStudentPlacedCompany, txtPlacedStudentContactNumber, txtPlacedStudentDescription);
            }
            catch { }
        }
        private void btnPlacedStudentAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                string errorMessage;
                bool isValid = PlacedStudents.xValidate(DBConn, TVPlacedStudent, txtPlacedStudentName, txtPlacedStudentEmail, txtPlacedStudentDepartment, txtPlacedStudentExperience, txtPlacedStudentQualification, txtPlacedStudentPlacedCompany, txtPlacedStudentContactNumber, txtPlacedStudentDescription, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                DBConn.Open();
                PlacedStudents.xAdd(DBConn, TVPlacedStudent, txtPlacedStudentName, txtPlacedStudentEmail, txtPlacedStudentDepartment, txtPlacedStudentExperience, txtPlacedStudentQualification, txtPlacedStudentPlacedCompany, txtPlacedStudentContactNumber, txtPlacedStudentDescription);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBConn.Close();
                UseWaitCursor = false;
            }
        }
        private void btnPlacedStudentUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVPlacedStudent.SelectedNode == null)
                {
                    MessageBox.Show("Please select  title");
                    return;
                }
                string errorMessage;
                bool isValid = PlacedStudents.xValidate(DBConn, TVPlacedStudent, txtPlacedStudentName, txtPlacedStudentEmail, txtPlacedStudentDepartment, txtPlacedStudentExperience, txtPlacedStudentQualification, txtPlacedStudentPlacedCompany, txtPlacedStudentContactNumber, txtPlacedStudentDescription, out errorMessage);
                if (!isValid)
                {
                    MessageBox.Show(errorMessage);
                    return;
                }
                string xID = TVPlacedStudent.SelectedNode.Name;
                DBConn.Open();
                PlacedStudents.xUpdate(DBConn, TVPlacedStudent, xID, txtPlacedStudentName, txtPlacedStudentEmail, txtPlacedStudentDepartment, txtPlacedStudentExperience, txtPlacedStudentQualification, txtPlacedStudentPlacedCompany, txtPlacedStudentContactNumber, txtPlacedStudentDescription);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnPlacedStudentDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVPlacedStudent.SelectedNode == null)
                {
                    MessageBox.Show("Please select Name");
                    return;
                }
                string xID = TVPlacedStudent.SelectedNode.Name;
                DBConn.Open();
                PlacedStudents.xDelete(DBConn, TVPlacedStudent, xID);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        async private void btnPlacedStudentUploadImage_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVPlacedStudent.SelectedNode == null) return;
                string xID = TVPlacedStudent.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "png Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("PlacedStudentPhotos", xFileName);
                DBConn.Open();
                PlacedStudents.xUpdatePSPhotoName(DBConn, xID, Path.GetFileNameWithoutExtension(xFileName));
                PlacedStudents.xPopInRev(xID, txtPlacedStudentName, txtPlacedStudentEmail, txtPlacedStudentDepartment, txtPlacedStudentExperience, txtPlacedStudentQualification, txtPlacedStudentPlacedCompany, txtPlacedStudentContactNumber, txtPlacedStudentDescription);
            }
            catch { }
            finally { this.Cursor = Cursors.Default; DBConn.Close(); }
        }
        private void btnPlacedStudentMoveUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                PlacedStudents.UpOrDown(DBConn, TVPlacedStudent, true);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnPlacedStudentMoveDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                PlacedStudents.UpOrDown(DBConn, TVPlacedStudent, false);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnPlacedStudentExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {

            }
        }
        private void btnPlacedStudentShowImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (TVPlacedStudent.SelectedNode == null) return;
                string xID = TVPlacedStudent.SelectedNode.Name;
                PlacedStudent xT = PlacedStudents.xGetByID(xID);
                string xStudentPhoto = xT.xPSPhotoName;
                if (xStudentPhoto.ToLower().EndsWith(".JPEG")) xStudentPhoto = xStudentPhoto.Substring(0, xStudentPhoto.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/PlacedStudentPhotos/" + xStudentPhoto;
                UpDLLoadImage.DownloadImage(xStudentPhoto, MyURL);
            }
            catch
            {
            }
        }
        private void btnPlacedStudentWrite_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBCQConn.Open();
                PlacedStudents.xCompanysWriteTableToFile(DBCQConn);

            }
            catch { }
            finally { DBCQConn.Close(); this.Cursor = Cursors.Default; }
        }
        #endregion

        #region CQNews
        private void txtCQNewsDate_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                mDate = CalCQNews.SelectionStart;
                CalCQNews.Visible = true;
                mCaller = "1";
            }
            catch { }
        }
        private void CalCQNews_DateSelected(object sender, DateRangeEventArgs e)
        {
            try
            {
                CalCQNews.Visible = false;
                mDate = CalCQNews.SelectionStart;
                string xStartDate = "";
                if (mCaller == "1")
                {
                    mDate = CalCQNews.SelectionStart;
                    txtCQNewsDate.Text = mDate.ToString("dd.MM.yyyy");
                    xStartDate = mDate.ToString("yyyyMMdd");
                }
            }
            catch { }
        }
        private void btnCQNewsAdd_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                DBConn.Open();
                CQNewss.xAdd(DBConn, TVCQNews, txtCQNewsTitle, mDate.ToString("yyyyMMdd"), txtCQNewsDescription);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnCQNewsUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVCQNews.SelectedNode == null || TVCQNews.SelectedNode.Level != 0)
                {
                    MessageBox.Show("Please select Information name");
                    return;
                }
                string xID = TVCQNews.SelectedNode.Name;
                DBConn.Open();
                CQNewss.xUpdate(DBConn, TVCQNews, xID, txtCQNewsTitle, mDate.ToString("yyyyMMdd"), txtCQNewsDescription);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnCQNewsDelete_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVCQNews.SelectedNode == null || TVCQNews.SelectedNode.Level != 0)
                {
                    MessageBox.Show("Please select Information name");
                    return;
                }
                string xID = TVCQNews.SelectedNode.Name;
                DBConn.Open();
                CQNewss.xDelete(DBConn, TVCQNews, xID);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void TVCQNews_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (TVCQNews.SelectedNode == null || TVCQNews.SelectedNode.Level != 0)
                {
                    MessageBox.Show("Please select Information name");
                    return;
                }
                string xID = TVCQNews.SelectedNode.Name;
                CQNewss.xPopInRev(xID, txtCQNewsTitle, txtCQNewsDate, txtCQNewsDescription);
            }
            catch { }
        }
        private void btnCQNewsMoveUp_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVCQNews.SelectedNode == null || TVCQNews.SelectedNode.Level != 0)
                {
                    MessageBox.Show("Please select Information name");
                    return;
                }
                DBConn.Open();
                CQNewss.UpOrDown(DBConn, TVCQNews, true);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        private void btnCQNewsMoveDown_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            UseWaitCursor = true;
            try
            {
                if (TVCQNews.SelectedNode == null || TVCQNews.SelectedNode.Level != 0)
                {
                    MessageBox.Show("Please select Information name");
                    return;
                }
                DBConn.Open();
                CQNewss.UpOrDown(DBConn, TVCQNews, false);
            }
            catch { }
            finally { DBConn.Close(); UseWaitCursor = false; }
        }
        async private void btnCQNewsUploadImage_Click(object sender, EventArgs e)
        {
            SqlConnection DBConn = new SqlConnection(CQBVar.ConnString.CQ);
            try
            {
                if (TVCQNews.SelectedNode == null) return;
                string xNewsID = TVCQNews.SelectedNode.Name;
                mOpenFile.InitialDirectory = CQBVar.xPath;
                mOpenFile.Filter = "JPEG Files (*.jpg) | *.jpg";
                if (mOpenFile.ShowDialog() == DialogResult.Cancel) return;
                string xFileName = mOpenFile.FileName;
                string xPhotoFileName = Path.GetFileNameWithoutExtension(xFileName);
                this.Cursor = Cursors.WaitCursor;
                await UpDLLoadImage.UpLoad("NewsPhotos", xFileName);
                DBConn.Open();
                CQNewss.xPopInRev(xNewsID, txtCQNewsTitle, txtCQNewsDate, txtCQNewsDescription);
                NewsPhotoNames.xAddImage(DBConn, TVCQNews, xPhotoFileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
                DBConn.Close();
            }
        }
        private async void btnCQNewsShowImage_Click(object sender, EventArgs e)
        {

            try
            {
                if (TVCQNews.SelectedNode == null || TVCQNews.SelectedNode.Level == 0) return;
                string xImage = TVCQNews.SelectedNode.Text;
                if (xImage.ToLower().EndsWith(".JPEG")) xImage = xImage.Substring(0, xImage.Length - 5);
                String MyURL = CQBVar.MyURL + "/api/Image/DownLoadImage/NewsPhotos/" + xImage;
                UpDLLoadImage.DownloadImage(xImage, MyURL);
            }
            catch
            {

            }
        }
        private void btnCQNewsWrite_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBCQConn.Open();
                CQNewss.xNewsTbWriteTableToFile(DBCQConn);
            }
            catch { }
            finally { DBCQConn.Close(); this.Cursor = Cursors.Default; }

        }
        async private void btnCQNewsClearGarbage_Click(object sender, EventArgs e)
        {
            SqlConnection DBCQConn = new SqlConnection(CQBVar.ConnString.CQ);
            this.Cursor = Cursors.WaitCursor;
            try
            {
                DBCQConn.Open();
                await NewsPhotoNames.GetPhotoNames();
                NewsPhotoNames.xClearGarbageEntries(DBCQConn);
                NewsPhotoNames.xClearGarbageEntriesByNewsID(DBCQConn);
                CQNewss.xPopTV(TVCQNews);
            }
            catch { }
            finally { DBCQConn.Close(); this.Cursor = Cursors.Default; }
        }
        private void btnCQNewsExit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {

            }
        }
        #endregion


    }
}






